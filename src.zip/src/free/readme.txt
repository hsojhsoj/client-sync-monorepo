=== Client Sync ===
Contributors: hsojhsoj
Donate link: https://dependentmedia.com/
Tags: appointment, booking, calendar, scheduling, woocommerce
Requires at least: 5.8
Tested up to: 6.9
Stable tag: 3.2.1
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Manage client registrations, appointments, payments, and appointment notes from a single, integrated system.

== Description ==

Client Sync transforms your WordPress site into a complete client and appointment management powerhouse. Designed for service-based businesses, clinics, consultants, and professionals, this plugin provides a robust, scalable, and flexible system to handle the entire client journey.

Whether you need simple one-on-one appointment booking, multi-day resource rentals, or complex group classes, Client Sync's unique "Dimension" architecture and a single, powerful `[clisyc_booking_form]` shortcode can handle it all intelligently. The system automatically detects whether to show a time-slot calendar, a multi-day rental search, or a single property's booking calendar based on the context of the page.

Built on a high-performance architecture using custom database tables, Client Sync ensures your site remains fast and responsive, even with complex schedules and high appointment volumes.

= Core Features =

*   **Flexible Booking Modes:**
    *   **Time Slots:** Perfect for standard appointments, coaching calls, and consultations.
    *   **Group Bookings (Multi-Capacity):** Easily manage classes, workshops, or tours by setting a capacity for any service. The system automatically tracks spots left.
    *   **Multi-Day Bookings:** Ideal for rentals (equipment, rooms, vehicles) where clients select a start and end date. Features an intuitive drag-to-select date range picker.

*   **Powerful & Intersecting Schedules:**
    *   **Availability Dimensions:** Create schedules based on service type, location, or practitioner for dynamic booking systems.
    *   **Resource Scheduling (Pro):** Designate dimensions like "Rooms" or "Equipment" as Resources. A time slot is only bookable if the service, practitioner, AND the required resource are all available at the same time.
    *   **Visual Availability Management:** "Paint" available or blocked time on an admin calendar for one-off changes and overrides.

*   **Availability Search Tool:**
    *   Add a powerful search form to your site with the `[clisyc_availability_search]` shortcode.
    *   Allows users to search for available items (rooms, boats, properties) across a specific date range, ensuring they only see results that are open for their entire trip.

*   **Dynamic Conditional Fields:** Show or hide appointment fields based on the service selected. If a "House Rental" service is chosen, show "Bedrooms". If "Car Rental" is chosen, show "Vehicle Type". This creates a clean, relevant booking experience for any service.

*   **Deep WooCommerce Integration:**
    *   **Per-Service Products:** Link each of your services directly to a unique WooCommerce product for accurate pricing and reporting.
    *   **Dynamic Pricing Engine:** Set custom pricing rules on WooCommerce products for multi-day bookings, such as weekend surcharges or weekly discounts.
    *   **Automatic Totals:** Seamlessly handles pricing for group bookings (price × quantity) and multi-day bookings (price × nights).

*   **Extensible Custom Fields:**
    *   Unlimited fields for clients and appointments, including text, dropdowns, checkboxes, and a unique **Image Map** field (Pro).

*   **Client & Manager Dashboards:**
    *   Clients view appointment history and update details via a dedicated account page.
    *   Manager shortcodes create frontend dashboards for staff to view/edit appointments without full admin access.

*   **Automation & Reminders:**
    *   Auto-generate future availability from templates.
    *   Reduce no-shows with configurable email reminders.

*   **iCal Export:** One-click `.ics` file downloads for adding appointments to Google Calendar, Outlook, or Apple Calendar.

== Installation ==

1. Navigate to **Plugins > Add New** in your WordPress dashboard.
2. Search for **Client Sync**.
3. Click **Install Now**, then **Activate**.
4. Follow the Setup Wizard to choose a business template, create essential pages, and configure settings.

== Frequently Asked Questions ==

= How do I add a booking form to my site? =
Simply add the universal shortcode to any page:
`[clisyc_booking_form]`

The plugin is smart and will automatically display the correct interface:
*   **On a standard page:** It will show the filterable calendar for time-slot appointments, or an availability search form if you primarily offer multi-day rentals.
*   **On an individual property/rental page:** It will automatically detect the context and show the booking calendar for that specific item.

= How do I set up a multi-day rental like a hotel room or vacation property? =
1.  In `Client Sync > Dimensions`, create a "Properties" dimension and set it as your **Primary Dimension**.
2.  Create your individual properties (e.g., "The Beach House") as posts within that dimension.
3.  On the edit screen for each property, find the "Primary Attributes" box and change the **Booking Mode** to **"Date Range"**.
4.  Set the **Capacity** to `1` for unique rentals, or more if you have multiple identical items (like "Standard Queen Room").
5.  Link the property to a **WooCommerce Product** to enable payments.
6.  Add the `[clisyc_booking_form]` shortcode to a general "Search" page, and also to the content of each individual property page. The shortcode will automatically show the right view in each location.

= How do I set up a group class like a yoga workshop? =
1.  When you create or edit your "Class" service (as a Primary Dimension item), find the **Capacity** field in the "Primary Attributes" box.
2.  Set the capacity to the number of students you can accommodate (e.g., `15`).
3.  That's it! The booking form will now show a "Number of Attendees" field for that service.

= How does Resource Scheduling work? (Pro) =
This powerful feature allows you to create intersecting schedules. A time is only bookable if all required people, places, and things are available.

1.  In `Client Sync > Dimensions > System Setup`, create your dimensions (e.g., "Practitioners", "Services", "Rooms").
2.  Check the **"Is Resource"** box for any dimension that has its own limited availability, like "Rooms". (This is a Pro feature).
3.  Edit a specific Room (e.g., "X-Ray Suite") and set its availability in its "Resource Availability Schedule" meta box (e.g., only available Tuesday mornings).
4.  Edit a "Service" (your Primary Dimension) and set its general availability (e.g., available all week).
5.  Link the service to the room in the Relationship Graph.

Now, a time slot for that service will only appear on the frontend calendar if it falls within **both** the Service's schedule AND the X-Ray Suite's schedule.

= How do I create different forms for different services? =
Client Sync uses **Conditional Logic**. Instead of creating separate forms, you create all the fields you might need in the **Appointment Custom Fields** tab. Then, for each field, you enable Conditional Logic and set rules like "Show this field ONLY IF Service Type is House Rental". The booking form will dynamically show the correct fields as the user makes their selection.

== External Services ==

This plugin includes an optional integration with Google reCAPTCHA v3 to protect the public booking and registration forms from spam and abuse.

= Google reCAPTCHA v3 =

*   **Purpose:** This service analyzes user interactions to distinguish between human users and automated bots, helping to prevent spam submissions. This feature is **disabled by default** and must be explicitly enabled and configured by the site administrator in the plugin's settings (Client Sync > Settings > Style & Behavior > Spam Protection).

*   **Data Sent:**
    *   **Frontend (User's Browser):** When reCAPTCHA is enabled, a JavaScript file is loaded from Google's servers. The user's browser sends hardware and software information, including device and application data and the results of integrity checks, to Google for analysis. The user's IP address is also collected.
    *   **Backend (Your Server):** When a user submits a form, a verification token generated on the frontend is sent from your server to Google's API for validation. This request includes the user's IP address.

*   **Service Policies:**
    *   Use of Google reCAPTCHA is subject to the Google Privacy Policy and Terms of Use.
    *   **Privacy Policy:** https://policies.google.com/privacy
    *   **Terms of Use:** https://policies.google.com/terms

== Changelog ==

= 3.2.1 =
*   Version bump.

= 3.1.0 =
*   **New Feature: Appointment Duration & Padding.** Admins can now set a specific duration (in minutes) for a service. The system will automatically subdivide large availability blocks (e.g., 9am-5pm) into precise, bookable slots of that duration.
*   **New Feature: Padding / Cleanup Time.** A "Padding" time (in minutes) can be set for each service. This automatically creates an unbookable gap after each appointment, perfect for cleanup, travel, or note-taking, without affecting the client-facing appointment duration.
*   **Enhancement:** The "Export Database" tool on the Testing page now exports all plugin options for a more complete debugging snapshot.

= 3.0.0 =
*   **Major Refactor: Monorepo Architecture.** Plugin restructured to support a Free and Pro version from a single codebase.
*   **Major Feature: Group Bookings (Multi-Capacity).** Admins can now set a "Capacity" for any service, allowing multiple clients to book the same time slot (e.g., for classes, workshops, or tours). The frontend calendar automatically displays the number of spots remaining.
*   **Major Feature: Multi-Day Bookings.** A new "Date Range" booking mode can be enabled for services, ideal for multi-day rentals of rooms, equipment, or vehicles. The frontend displays a date-range picker instead of a time-slot calendar for these services.
*   **Pro Feature: Resource Scheduling (Intersecting Availability).** Dimensions (like "Rooms" or "Equipment") can be designated as "Resources," each with its own independent weekly schedule. A time slot is only considered available if it exists in the schedule of the Primary Dimension AND any linked Resource Dimensions, allowing for complex constraint-based booking.
*   **Enhancement: WooCommerce Direct Product Linking.** The old global WooCommerce product ID has been replaced. Admins can now link each individual service directly to its own unique WooCommerce product. This provides accurate, per-service pricing, better reporting, and native support for quantity-based pricing for group bookings.
*   **Enhancement: Setup Wizard Templates.** Added new templates to the Setup Wizard to demonstrate the new Group Booking and Resource Rental features, providing users with powerful starting points.
*   **Enhancement (Admin UI):** The "Base Weekly Schedule" editor now includes visual dot indicators on the day-of-the-week tabs to show which days have availability configured, improving administrative workflow.
*   **Fix:** Resolved numerous JavaScript timing issues in the admin area, particularly on the Gutenberg post edit screen, to ensure UI elements like the schedule editor and its toggles load reliably.
*   **Dev:** Full audit and hardening of all code to resolve PHP 8.1+ deprecation notices.

= 2.2.0 =
* **Security & Stability:** Major refactor to meet WordPress.org plugin repository standards.
* **Prefixing:** All functions, classes, constants, options, hooks, CPTs, and asset handles have been prefixed with `clisyc_` or `DependentMedia\ClientSync` for uniqueness and to prevent conflicts with other plugins.
* **Security:** Added and verified nonce checks for all state-changing actions. Refactored form handlers to separate processing logic from rendering logic.
* **Security:** Improved data sanitization on input and escaping on output across the entire plugin.
* **Performance:** Refactored asset (CSS/JS) loading to only enqueue files on pages where they are needed, improving site-wide performance.

= 2.1.0 =
* **Feature:** Added Conditional Logic for Appointment Custom Fields.
* **Feature:** New dedicated "Service & Availability Dimensions" admin page.
* **Enhancement:** Streamlined admin menu structure.
* **Enhancement:** Added AJAX functionality to the new Dimensions admin page.

= 2.0.0 =
* Major refactor: Migrated availability slots to custom database tables.
* Added Setup Wizard for streamlined onboarding.

= 1.5.0 =
* Added iCal export functionality.
* Implemented appointment reminder system.

= 1.4.0 =
* Added "Pay on Day" WooCommerce functionality.

= 1.3.0 =
* Introduced "Availability Dimensions" for multi-faceted scheduling.

= 1.0.0 =
* Initial release.

== Copyright ==

Client Sync uses the following third-party libraries:

*   **FullCalendar Scheduler**
    *   Source: https://fullcalendar.io/scheduler
    *   License: GNU General Public License v3 (GPLv3)
    *   Copyright: 2023 Adam Shaw