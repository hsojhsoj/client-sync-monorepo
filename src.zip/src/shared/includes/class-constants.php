<?php
/**
 * File: src/shared/includes/class-constants.php
 *
 * Centralised registry of every option name, meta key, post-type slug,
 * status value and cron hook used by Client Sync.
 *
 * Usage:  use DependentMedia\ClientSync\Constants;
 *         get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
 *
 * @package    ClientSync
 * @subpackage ClientSync/Constants
 */

namespace DependentMedia\ClientSync;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Immutable value-object that holds every magic string in one place.
 */
final class Constants {

	// ── Post Types ─────────────────────────────────────────────────────
	const POST_TYPE_APPOINTMENT = 'clisyc_appointment';
	const POST_TYPE_SERVICE     = 'clisyc_service';

	// ── Dimension Registry ─────────────────────────────────────────────
	const OPTION_DIMENSION_REGISTRY     = 'clisyc_dimension_registry';
	const OPTION_CUSTOM_DIMENSION_TYPES = 'clisyc_custom_dimension_types';
	const OPTION_DIMENSION_FIELDS       = 'clisyc_dimension_fields';
	const OPTION_AVAILABILITY_DIM_FIELDS = 'clisyc_availability_dimensions_fields';
	const OPTION_PRIMARY_SERVICE_DIM    = 'clisyc_primary_service_dimension_key';
	const OPTION_PERSONNEL_DIM_SLUG     = 'clisyc_personnel_dimension_slug';

	// ── Calendar Options ───────────────────────────────────────────────
	const OPTION_CALENDAR_SLOT_DURATION  = 'clisyc_calendar_slot_duration';
	const OPTION_CALENDAR_SLOT_HEIGHT    = 'clisyc_calendar_slot_height';
	const OPTION_CALENDAR_START_TIME     = 'clisyc_calendar_start_time';
	const OPTION_CALENDAR_END_TIME       = 'clisyc_calendar_end_time';
	const OPTION_CALENDAR_ENABLED_VIEWS  = 'clisyc_calendar_enabled_views';
	const OPTION_CALENDAR_WEEK_STARTS    = 'clisyc_calendar_week_starts_on';
	const OPTION_CALENDAR_COLOR_SETTINGS = 'clisyc_calendar_color_settings';
	const OPTION_CALENDAR_SMART_START    = 'clisyc_calendar_smart_start_date';
	const OPTION_CALENDAR_SMART_START_NA = 'clisyc_calendar_smart_start_date_next_available';
	const OPTION_FRONTEND_CALENDAR_STYLE = 'clisyc_frontend_calendar_style';

	// ── Page IDs ───────────────────────────────────────────────────────
	const OPTION_BOOKING_PAGE_ID       = 'clisyc_booking_page_id';
	const OPTION_BOOKING_SUCCESS_PAGE  = 'clisyc_booking_success_page_id';
	const OPTION_APPOINTMENT_VIEW_PAGE = 'clisyc_appointment_view_page_id';
	const OPTION_MY_APPOINTMENTS_PAGE  = 'clisyc_my_appointments_page_id';
	const OPTION_MANAGER_EDIT_PAGE     = 'clisyc_manager_edit_page_id';
	const OPTION_CONTACT_PAGE          = 'clisyc_contact_page_id';
	const OPTION_SEARCH_RESULTS_PAGE   = 'clisyc_search_results_page_id';
	const OPTION_APPOINTMENT_VIEW_SLUG = 'clisyc_appointment_view_page_slug';

	// ── Scheduling Options ─────────────────────────────────────────────
	const OPTION_AUTO_GEN_ENABLED    = 'clisyc_auto_generate_enabled';
	const OPTION_AUTO_GEN_LOOKAHEAD  = 'clisyc_auto_generate_lookahead';
	const OPTION_AUTO_GEN_DAYS       = 'clisyc_auto_generate_days_of_week';
	const OPTION_MIN_BOOKING_NOTICE  = 'clisyc_min_booking_notice_minutes';
	const OPTION_DEFAULT_BUFFER_DAYS = 'clisyc_default_buffer_days';
	const OPTION_DEFAULT_BOOKING_MODE = 'clisyc_default_booking_mode';
	const OPTION_GLOBAL_BUFFER_BEFORE = 'clisyc_global_buffer_before';
	const OPTION_GLOBAL_BUFFER_AFTER  = 'clisyc_global_buffer_after';
	const OPTION_SLOT_GEN_STATE       = 'clisyc_slot_gen_state';

	// ── WooCommerce Integration ────────────────────────────────────────
	const OPTION_WC_ENABLED    = 'clisyc_wc_integration_enabled';
	const OPTION_WC_PRODUCT_ID = 'clisyc_wc_appointment_product_id';

	// ── Appointment Meta Keys ──────────────────────────────────────────
	const META_TIME_SLOT        = '_clisyc_time_slot';
	const META_APPOINTMENT_DATE = '_clisyc_appointment_date';
	const META_SLOT_DIMENSIONS  = '_clisyc_slot_dimensions';
	const META_BOOKING_MODE     = '_clisyc_booking_mode';
	const META_START_DATE       = '_clisyc_start_date';
	const META_END_DATE         = '_clisyc_end_date';
	const META_STATUS           = '_clisyc_status';
	const META_CLIENT_ID        = '_clisyc_client_id';
	const META_SERVICE_NAME     = '_clisyc_service_name';
	const META_NOTES            = '_clisyc_notes';
	const META_REMINDER_SENT    = '_clisyc_appointment_reminder_sent';

	// ── Service / Dimension Meta Keys ──────────────────────────────────
	const META_DURATION_MINUTES  = '_clisyc_duration_minutes';
	const META_PADDING_MINUTES   = '_clisyc_padding_minutes';
	const META_PRICE             = '_clisyc_price';
	const META_CAPACITY          = '_clisyc_capacity';
	const META_BUFFER_BEFORE     = '_clisyc_buffer_before';
	const META_BUFFER_AFTER      = '_clisyc_buffer_after';
	const META_BUFFER_DAYS       = '_clisyc_buffer_days';
	const META_MIN_STAY          = '_clisyc_min_stay';
	const META_MAX_STAY          = '_clisyc_max_stay';
	const META_ALLOWED_CHECKIN   = '_clisyc_allowed_checkin_days';
	const META_ALLOWED_CHECKOUT  = '_clisyc_allowed_checkout_days';
	const META_SCHEDULE          = '_clisyc_schedule';
	const META_SCHEDULE_OVERRIDES = '_clisyc_schedule_overrides';
	const META_SCHEDULE_JSON     = '_clisyc_schedule_json';
	const META_COLOR             = '_clisyc_color';
	const META_EMPLOYEE_USER_ID  = '_clisyc_employee_user_id';
	const META_WC_PRODUCT_ID     = '_clisyc_wc_product_id';
	const META_ADDITIONAL_PRODUCTS = '_clisyc_additional_products';
	const META_ADDON_CALC_TYPE   = '_clisyc_addon_calc_type';
	const META_PRICING_RULES     = '_clisyc_pricing_rules';

	// ── Payment Meta Keys ──────────────────────────────────────────────
	const META_WC_ORDER_ID      = '_clisyc_wc_order_id';
	const META_WC_ORDER_LINK    = '_clisyc_wc_order_link';
	const META_PAYMENT_STATUS   = '_clisyc_payment_status';
	const META_PAYMENT_DUE_DATE = '_clisyc_payment_due_date';
	const META_WC_TOKEN_ID      = '_clisyc_wc_token_id';

	// ── Appointment Statuses ───────────────────────────────────────────
	const STATUS_PENDING   = 'pending';
	const STATUS_CONFIRMED = 'confirmed';
	const STATUS_CANCELLED = 'cancelled';
	const STATUS_COMPLETED = 'completed';
	const STATUS_NO_SHOW   = 'no-show';

	// ── Email / Notifications ──────────────────────────────────────────
	const OPTION_EMAIL_FROM_NAME       = 'clisyc_email_from_name';
	const OPTION_EMAIL_FROM_ADDRESS    = 'clisyc_email_from_address';
	const OPTION_NOTIFICATION_SETTINGS = 'clisyc_notification_settings';
	const OPTION_NOTIFICATION_ADMINS   = 'clisyc_notification_admin_recipients';
	const OPTION_REMINDER_SETTINGS     = 'clisyc_reminder_settings';
	const OPTION_SMS_CREDENTIALS       = 'clisyc_sms_credentials';
	const OPTION_WEBHOOKS              = 'clisyc_webhooks';

	// ── HIPAA / Audit ──────────────────────────────────────────────────
	const OPTION_HIPAA_MODE          = 'clisyc_hipaa_mode_enabled';
	const OPTION_AUDIT_LOG_ENABLED   = 'clisyc_audit_logging_enabled';
	const OPTION_AUDIT_LOG_RETENTION = 'clisyc_audit_log_retention_days';

	// ── Cancellation ───────────────────────────────────────────────────
	const OPTION_CANCEL_CUTOFF_VALUE  = 'clisyc_cancellation_cutoff_value';
	const OPTION_CANCEL_CUTOFF_UNIT   = 'clisyc_cancellation_cutoff_unit';
	const OPTION_CANCEL_REFUND_POLICY = 'clisyc_cancellation_refund_policy';

	// ── Antispam ───────────────────────────────────────────────────────
	const OPTION_ANTISPAM_HONEYPOT   = 'clisyc_antispam_honeypot_enabled';
	const OPTION_ANTISPAM_TIME_CHECK = 'clisyc_antispam_time_check_enabled';

	// ── Misc Options ───────────────────────────────────────────────────
	const OPTION_LOGIN_PAGE_URL      = 'clisyc_login_page_url';
	const OPTION_ENABLE_SELF_SERVICE = 'clisyc_enable_self_service';
	const OPTION_SETUP_MILESTONES    = 'clisyc_setup_milestones_completed';
	const OPTION_DELETE_ON_UNINSTALL = 'clisyc_delete_user_data_on_uninstall';
	const OPTION_APPOINTMENT_FIELDS  = 'clisyc_appointment_custom_fields';
	const OPTION_CUSTOM_FIELDS       = 'clisyc_custom_fields';
	const OPTION_CUSTOM_FIELDS_ORDER = 'clisyc_custom_fields_order';
	const OPTION_GRAPH_VISUAL_STATE  = 'clisyc_graph_visual_state';
	const OPTION_UNIVERSAL_SHORTCODE_MODE = 'clisyc_universal_shortcode_default_mode';
	const OPTION_INITIAL_VIEW        = 'initial_view';
	const OPTION_ANONYMIZE_EXTERNAL_SYNC = 'clisyc_anonymize_external_sync';
	const OPTION_GLOBAL_BLOCKED_PERIODS  = 'clisyc_global_blocked_periods';
	const OPTION_CLIENT_LIST_CF_COLUMN   = 'clisyc_client_list_custom_field_column';

	// ── Cron / Maintenance ─────────────────────────────────────────────
	const ACTION_FREQUENT_MAINTENANCE = 'clisyc_frequent_maintenance_tasks';
	const OPTION_LAST_MAINTENANCE_TS  = 'clisyc_last_frequent_maintenance_run_timestamp';
	const OPTION_LAST_SUCCESS_TS      = 'clisyc_last_successful_maintenance_run_timestamp';
	const OPTION_MYSQL_CONVERT_TZ     = 'clisyc_mysql_convert_tz_status';
	const OPTION_MYSQL_CONVERT_TZ_OR  = 'clisyc_mysql_convert_tz_override';

	// ── Admin Page Slugs ───────────────────────────────────────────────
	const PAYMENTS_PAGE_SLUG = 'clisyc-payments';

	// Not instantiable.
	private function __construct() {}
}
