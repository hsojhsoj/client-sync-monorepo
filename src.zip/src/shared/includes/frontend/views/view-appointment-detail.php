<?php
/**
 * File: src/shared/includes/frontend/views/view-appointment-detail.php
 * View template for the redesigned [clisyc_appointment_detail] shortcode.
 *
 * UPDATED: Added HIPAA compliance features:
 * - Audit logging for appointment views
 * - Encryption/decryption support for sensitive fields
 *
 * @package    ClientSync
 * @subpackage ClientSync/Frontend/Views
 */

if (!defined('ABSPATH')) {
    exit;
}

use DependentMedia\ClientSync\Constants;

/**
 * Variables passed from Shortcodes::render_appointment_detail():
 * @var \WP_Post $appointment_post
 * @var string   $formatted_date
 * @var string   $formatted_time
 * @var string   $title
 * @var \WP_Post_Status $status_obj
 * @var array    $all_custom_fields
 * @var array    $field_order
 * @var string   $notes
 * @var string   $export_url
 * @var \DependentMedia\ClientSync\Services\FormRenderer $form_renderer
 */

// =========================================================================
// HIPAA COMPLIANCE: Log appointment view
// =========================================================================
/**
 * Fires before the appointment detail is rendered.
 * The Audit_Logger class listens for this hook to log the view action.
 *
 * @param int $appointment_id The ID of the appointment being viewed.
 */
do_action( 'clisyc_before_appointment_detail_render', $appointment_post->ID );

// =========================================================================
// HIPAA COMPLIANCE: Initialize encryption service for field decryption
// =========================================================================
$clisyc_encryption_available = class_exists( '\DependentMedia\ClientSync\Services\Encryption_Service' );
$clisyc_encryption = $clisyc_encryption_available 
    ? \DependentMedia\ClientSync\Services\Encryption_Service::get_instance() 
    : null;

// Helper function to get a friendly status class
function clisyc_get_status_class($status) {
    switch ($status) {
        case 'publish':
        case Constants::STATUS_CONFIRMED:
        case 'clisyc_paid_on_day':
        case 'wc-processing':
        case 'wc-completed':
            return 'clisyc-status-confirmed';
        case Constants::STATUS_PENDING:
        case 'clisyc_pending_payment':
            return 'clisyc-status-pending';
        case 'trash':
        case Constants::STATUS_CANCELLED:
            return 'clisyc-status-cancelled';
        case 'draft':
            return 'clisyc-status-completed';
        default:
            return 'clisyc-status-pending';
    }
}
$clisyc_status_class = clisyc_get_status_class($appointment_post->post_status);

// Cancellation manager for action buttons
$clisyc_cancellation_manager = new \DependentMedia\ClientSync\Core\Cancellation_Manager($appointment_post->ID);
$clisyc_can_manage = $clisyc_cancellation_manager->can_be_managed();
?>

<div class="clisyc-appointment-detail-card">

    <div class="clisyc-detail-header">
        <div class="clisyc-detail-status-badge <?php echo esc_attr($clisyc_status_class); ?>">
            <?php echo $status_obj ? esc_html($status_obj->label) : esc_html(get_post_status($appointment_post->ID)); ?>
        </div>
        <h2><?php echo esc_html($title); ?></h2>
    </div>

    <div class="clisyc-core-info">
        <div class="clisyc-info-item">
            <div class="clisyc-info-icon"><span class="dashicons dashicons-calendar-alt"></span></div>
            <div class="clisyc-info-text">
                <strong><?php esc_html_e('Date', 'client-sync'); ?></strong>
                <span><?php echo esc_html($formatted_date); ?></span>
            </div>
        </div>
        <div class="clisyc-info-item">
            <div class="clisyc-info-icon"><span class="dashicons dashicons-clock"></span></div>
            <div class="clisyc-info-text">
                <strong><?php esc_html_e('Time', 'client-sync'); ?></strong>
                <span><?php echo esc_html($formatted_time); ?></span>
            </div>
        </div>
    </div>

    <?php
    $clisyc_dimensions = get_post_meta($appointment_post->ID, Constants::META_SLOT_DIMENSIONS, true);
    if (!empty($clisyc_dimensions) && is_array($clisyc_dimensions)) :
        $clisyc_custom_types = get_option(Constants::OPTION_CUSTOM_DIMENSION_TYPES, []);
    ?>
        <div class="clisyc-detail-section">
            <h3><?php esc_html_e('Appointment Details', 'client-sync'); ?></h3>
            <ul class="clisyc-details-list">
                <?php foreach ($clisyc_dimensions as $clisyc_slug => $post_id) : ?>
                    <?php
                    $clisyc_cpt_label = $clisyc_custom_types[$clisyc_slug]['singular'] ?? ucfirst(str_replace(['clisyc_', '_'], ['', ' '], $clisyc_slug));
                    $clisyc_item_title = get_the_title($post_id);
                    ?>
                    <li>
                        <span class="label"><?php echo esc_html($clisyc_cpt_label); ?></span>
                        <span class="value"><?php echo $clisyc_item_title ? esc_html($clisyc_item_title) : '<em>' . esc_html__('N/A', 'client-sync') . '</em>'; ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if (!empty($field_order) && !empty($all_custom_fields)) : ?>
        <div class="clisyc-detail-section">
            <h3><?php esc_html_e('Additional Information', 'client-sync'); ?></h3>
            <ul class="clisyc-details-list">
                <?php
                foreach ($field_order as $clisyc_field_key) {
                    if (!isset($all_custom_fields[$clisyc_field_key])) continue;
                    $clisyc_field = $all_custom_fields[$clisyc_field_key];
                    if ('custom_html' === ($clisyc_field['type'] ?? '')) continue; // Skip HTML blocks in this list
                    
                    $clisyc_current_value = get_post_meta($appointment_post->ID, $clisyc_field_key, true);
                    
                    // =========================================================================
                    // HIPAA COMPLIANCE: Decrypt encrypted field values
                    // =========================================================================
                    if ( $clisyc_encryption && ! empty( $clisyc_current_value ) && is_string( $clisyc_current_value ) ) {
                        $clisyc_current_value = $clisyc_encryption->maybe_decrypt( $clisyc_current_value, $clisyc_field_key );
                    }
                    
                    $clisyc_display_value = '<em>' . esc_html__('Not Provided', 'client-sync') . '</em>';
                    
                    if (!empty($clisyc_current_value)) {
                        $clisyc_display_value = is_array($clisyc_current_value) ? implode(', ', $clisyc_current_value) : nl2br(esc_html($clisyc_current_value));
                    }
                    ?>
                    <li>
                        <span class="label"><?php echo esc_html($clisyc_field['label']); ?></span>
                        <span class="value"><?php echo wp_kses_post($clisyc_display_value); ?></span>
                    </li>
                <?php } ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="clisyc-detail-actions">
        <?php if (!empty($export_url)) : ?>
            <a href="<?php echo esc_url($export_url); ?>" class="button clisyc-button-ical" download>
                <span class="dashicons dashicons-calendar-alt"></span> <?php esc_html_e('Add to Calendar', 'client-sync'); ?>
            </a>
        <?php endif; ?>

        <?php if ($clisyc_can_manage) : ?>
            <a href="<?php echo esc_url(wp_nonce_url(add_query_arg(['clisyc_self_service_action' => 'cancel', 'appointment_id' => $appointment_post->ID]), 'clisyc_cancel_appt_' . $appointment_post->ID)); ?>" class="button clisyc-button-cancel" onclick="return confirm('<?php esc_attr_e('Are you sure you want to cancel this appointment?', 'client-sync'); ?>');">
                <span class="dashicons dashicons-no"></span> <?php esc_html_e('Cancel Appointment', 'client-sync'); ?>
            </a>
        <?php endif; ?>
    </div>
</div>