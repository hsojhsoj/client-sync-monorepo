<?php
/**
 * File: src/shared/includes/utility/class-security-helper.php
 * Provides security utilities like Rate Limiting for REST API endpoints.
 */

namespace DependentMedia\ClientSync\Utility;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Security_Helper {

    /**
     * Check if the current request has exceeded the rate limit.
     *
     * @param string $action  A unique identifier for the action (e.g., 'fetch_slots').
     * @param int    $limit   Max requests allowed.
     * @param int    $seconds Time window in seconds.
     * @return bool|\WP_Error True if allowed, WP_Error if limit exceeded.
     */
    public static function check_rate_limit( string $action, int $limit = 50, int $seconds = 60 ) {
        // Bypass for logged-in admins/managers
        if ( current_user_can( 'edit_posts' ) ) {
            return true;
        }

        // FIX: Sanitize and unslash the IP address
        $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
        
        if ( empty( $ip ) ) {
            return true; // Cannot limit without IP
        }

        // Anonymize IP slightly for privacy/GDPR compliance if needed, 
        // but raw IP is standard for security throttling.
        $ip_hash = md5( $ip . $action ); 
        $transient_key = 'clisyc_rate_limit_' . $ip_hash;

        $current_count = (int) get_transient( $transient_key );

        if ( $current_count >= $limit ) {
            return new \WP_Error( 
                'rate_limit_exceeded', 
                __( 'Too many requests. Please try again later.', 'client-sync' ), 
                [ 'status' => 429 ] 
            );
        }

        // Increment count
        if ( $current_count === 0 ) {
            set_transient( $transient_key, 1, $seconds );
        } else {
            // Update the value without resetting the timeout
            // Note: WordPress transients don't support "increment without reset" natively well,
            // so we simply re-set it. For strict precision, we'd use a dedicated table, 
            // but this is sufficient for basic protection.
            set_transient( $transient_key, $current_count + 1, $seconds );
        }

        return true;
    }
    
    /**
     * Validates that a request context is safe.
     *
     * @param string $context The context string passed from JS.
     * @return bool
     */
    public static function validate_admin_context( $context ) {
        if ( 'admin_editable' === $context || 'admin' === $context ) {
            return current_user_can( 'manage_options' ) || current_user_can( 'edit_posts' );
        }
        return false;
    }
}