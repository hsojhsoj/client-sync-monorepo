<?php
/**
 * File: src/shared/includes/services/class-encryption-service.php
 * Encryption service for HIPAA-compliant PHI protection.
 *
 * This service provides:
 * - AES-256-CBC encryption/decryption
 * - Automatic key derivation from CLISYC_ENCRYPTION_KEY constant
 * - Wrapper methods that respect HIPAA mode setting
 * - Support for both string and array data
 *
 * SECURITY NOTES:
 * - Encryption key MUST be defined in wp-config.php (not in database)
 * - Key should be at least 32 characters for AES-256
 * - Each encrypted value includes a unique IV for security
 * - Encrypted data is prefixed with a marker for identification
 *
 * @package    ClientSync
 * @subpackage ClientSync/Services
 * @since      3.3.0
 */

namespace DependentMedia\ClientSync\Services;

use DependentMedia\ClientSync\Constants;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Encryption_Service {

    /**
     * Encryption algorithm - AES-256-CBC is HIPAA-compliant.
     */
    const CIPHER_ALGO = 'aes-256-cbc';

    /**
     * Prefix marker to identify encrypted values in the database.
     * This allows us to distinguish encrypted data from plain text.
     */
    const ENCRYPTED_PREFIX = '$CLISYC_ENC$';

    /**
     * Version marker for future-proofing encryption format changes.
     */
    const ENCRYPTION_VERSION = '1';

    /**
     * Singleton instance.
     *
     * @var Encryption_Service|null
     */
    private static $instance = null;

    /**
     * Derived encryption key (cached).
     *
     * @var string|null
     */
    private $derived_key = null;

    /**
     * Get singleton instance.
     *
     * @return Encryption_Service
     */
    public static function get_instance(): Encryption_Service {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor (singleton pattern).
     */
    private function __construct() {
        // Derive the key on first use
        $this->derived_key = $this->derive_key();
    }

    /**
     * Check if encryption is available.
     *
     * @return bool True if encryption can be performed.
     */
    public function is_available(): bool {
        // Check if OpenSSL is available
        if ( ! function_exists( 'openssl_encrypt' ) ) {
            return false;
        }

        // Check if algorithm is supported
        if ( ! in_array( self::CIPHER_ALGO, openssl_get_cipher_methods(), true ) ) {
            return false;
        }

        // Check if key is configured
        if ( empty( $this->derived_key ) ) {
            return false;
        }

        return true;
    }

    /**
     * Derive a 256-bit key from the configured encryption key.
     *
     * Uses SHA-256 to ensure consistent key length regardless of input.
     *
     * @return string|null The derived key or null if not configured.
     */
    private function derive_key(): ?string {
        if ( ! defined( 'CLISYC_ENCRYPTION_KEY' ) || empty( CLISYC_ENCRYPTION_KEY ) ) {
            return null;
        }

        // Use SHA-256 to derive a consistent 256-bit (32-byte) key
        // This ensures the key is always the correct length for AES-256
        return hash( 'sha256', CLISYC_ENCRYPTION_KEY, true );
    }

    /**
     * Get the IV length for the cipher algorithm.
     *
     * @return int The IV length in bytes.
     */
    private function get_iv_length(): int {
        return openssl_cipher_iv_length( self::CIPHER_ALGO );
    }

    /**
     * Encrypt a string value.
     *
     * Format: $CLISYC_ENC$version:base64(iv):base64(ciphertext)
     *
     * @param string $plaintext The value to encrypt.
     * @return string|false The encrypted value or false on failure.
     */
    public function encrypt( string $plaintext ): string|false {
        if ( ! $this->is_available() ) {
            // Log warning but return original value to prevent data loss
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                error_log( '[ClientSync Encryption] Warning: Encryption not available, storing unencrypted.' );
            }
            return false;
        }

        // Don't double-encrypt
        if ( $this->is_encrypted( $plaintext ) ) {
            return $plaintext;
        }

        // Generate a random IV
        $iv_length = $this->get_iv_length();
        $iv = openssl_random_pseudo_bytes( $iv_length );

        if ( false === $iv ) {
            return false;
        }

        // Encrypt the data
        $ciphertext = openssl_encrypt(
            $plaintext,
            self::CIPHER_ALGO,
            $this->derived_key,
            OPENSSL_RAW_DATA,
            $iv
        );

        if ( false === $ciphertext ) {
            return false;
        }

        // Format: prefix + version : base64(iv) : base64(ciphertext)
        return self::ENCRYPTED_PREFIX . self::ENCRYPTION_VERSION . ':' 
            . base64_encode( $iv ) . ':' 
            . base64_encode( $ciphertext );
    }

    /**
     * Decrypt an encrypted string value.
     *
     * @param string $encrypted The encrypted value.
     * @return string|false The decrypted value or false on failure.
     */
    public function decrypt( string $encrypted ): string|false {
        if ( ! $this->is_available() ) {
            return false;
        }

        // Check if the value is actually encrypted
        if ( ! $this->is_encrypted( $encrypted ) ) {
            // Return as-is if not encrypted (backwards compatibility)
            return $encrypted;
        }

        // Remove prefix and parse components
        $data = substr( $encrypted, strlen( self::ENCRYPTED_PREFIX ) );
        $parts = explode( ':', $data, 3 );

        if ( count( $parts ) !== 3 ) {
            return false;
        }

        list( $version, $iv_b64, $ciphertext_b64 ) = $parts;

        // Currently only version 1 is supported
        if ( $version !== self::ENCRYPTION_VERSION ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                error_log( "[ClientSync Encryption] Unsupported encryption version: {$version}" );
            }
            return false;
        }

        // Decode components
        $iv = base64_decode( $iv_b64, true );
        $ciphertext = base64_decode( $ciphertext_b64, true );

        if ( false === $iv || false === $ciphertext ) {
            return false;
        }

        // Decrypt
        $plaintext = openssl_decrypt(
            $ciphertext,
            self::CIPHER_ALGO,
            $this->derived_key,
            OPENSSL_RAW_DATA,
            $iv
        );

        return $plaintext;
    }

    /**
     * Check if a value appears to be encrypted.
     *
     * @param mixed $value The value to check.
     * @return bool True if the value appears to be encrypted.
     */
    public function is_encrypted( $value ): bool {
        if ( ! is_string( $value ) ) {
            return false;
        }

        return str_starts_with( $value, self::ENCRYPTED_PREFIX );
    }

    // =========================================================================
    // HIPAA-AWARE WRAPPER METHODS
    // =========================================================================

    /**
     * Encrypt a value only if HIPAA mode is enabled.
     *
     * This is the primary method to use when saving sensitive data.
     * It automatically checks HIPAA mode and handles arrays.
     *
     * @param mixed  $value      The value to potentially encrypt.
     * @param string $field_key  The field key (for logging purposes).
     * @return mixed The encrypted value (if HIPAA mode) or original value.
     */
    public function maybe_encrypt( $value, string $field_key = '' ) {
        // Check if HIPAA mode is enabled and operational
        if ( ! function_exists( '\DependentMedia\ClientSync\Services\clisyc_is_hipaa_operational' ) ) {
            return $value;
        }

        if ( ! \DependentMedia\ClientSync\Services\clisyc_is_hipaa_operational() ) {
            return $value;
        }

        // Handle empty values
        if ( empty( $value ) && $value !== '0' && $value !== 0 ) {
            return $value;
        }

        // Handle arrays (serialize first, then encrypt)
        if ( is_array( $value ) ) {
            $serialized = maybe_serialize( $value );
            $encrypted = $this->encrypt( $serialized );
            return ( false !== $encrypted ) ? $encrypted : $value;
        }

        // Handle strings
        if ( is_string( $value ) ) {
            $encrypted = $this->encrypt( $value );
            return ( false !== $encrypted ) ? $encrypted : $value;
        }

        // Other scalar types - convert to string first
        if ( is_scalar( $value ) ) {
            $encrypted = $this->encrypt( (string) $value );
            return ( false !== $encrypted ) ? $encrypted : $value;
        }

        // Return original value for unsupported types
        return $value;
    }

    /**
     * Decrypt a value only if it appears to be encrypted.
     *
     * This is the primary method to use when retrieving sensitive data.
     * It automatically handles encrypted arrays and backwards compatibility.
     *
     * @param mixed  $value      The value to potentially decrypt.
     * @param string $field_key  The field key (for logging purposes).
     * @return mixed The decrypted value or original value.
     */
    public function maybe_decrypt( $value, string $field_key = '' ) {
        // Handle empty values
        if ( empty( $value ) && $value !== '0' ) {
            return $value;
        }

        // Only process strings
        if ( ! is_string( $value ) ) {
            return $value;
        }

        // Check if encrypted
        if ( ! $this->is_encrypted( $value ) ) {
            return $value;
        }

        // Decrypt
        $decrypted = $this->decrypt( $value );

        if ( false === $decrypted ) {
            // Decryption failed - log error and return empty
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                error_log( "[ClientSync Encryption] Failed to decrypt field: {$field_key}" );
            }
            return '';
        }

        // Check if the decrypted value was a serialized array
        $unserialized = maybe_unserialize( $decrypted );

        return $unserialized;
    }

    /**
     * Check if a field should be encrypted based on its key.
     *
     * This can be extended to add more sensitive field patterns.
     *
     * @param string $field_key The meta key of the field.
     * @return bool True if the field should be encrypted.
     */
    public function should_encrypt_field( string $field_key ): bool {
        // List of field patterns that should always be encrypted
        $sensitive_patterns = [
            Constants::META_NOTES,     // Appointment notes
            '_clisyc_medical_',        // Any medical-prefixed fields
            '_clisyc_health_',         // Health information fields
            '_clisyc_diagnosis_',      // Diagnosis fields
            '_clisyc_treatment_',      // Treatment fields
            '_clisyc_medication_',     // Medication fields
            '_clisyc_ssn',             // Social Security Number
            '_clisyc_insurance_',      // Insurance information
            '_clisyc_phi_',            // Explicitly marked PHI fields
        ];

        foreach ( $sensitive_patterns as $pattern ) {
            if ( str_starts_with( $field_key, $pattern ) ) {
                return true;
            }
        }

        // Check custom fields marked as sensitive
        $custom_fields = get_option( 'clisyc_appointment_custom_fields', [] );
        if ( isset( $custom_fields[ $field_key ] ) ) {
            // If field has 'sensitive' or 'encrypt' flag, encrypt it
            if ( ! empty( $custom_fields[ $field_key ]['sensitive'] ) || 
                 ! empty( $custom_fields[ $field_key ]['encrypt'] ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Bulk encrypt multiple fields.
     *
     * @param array $fields Array of field_key => value pairs.
     * @return array Array of field_key => encrypted_value pairs.
     */
    public function encrypt_fields( array $fields ): array {
        $result = [];
        foreach ( $fields as $key => $value ) {
            if ( $this->should_encrypt_field( $key ) ) {
                $result[ $key ] = $this->maybe_encrypt( $value, $key );
            } else {
                $result[ $key ] = $value;
            }
        }
        return $result;
    }

    /**
     * Bulk decrypt multiple fields.
     *
     * @param array $fields Array of field_key => value pairs.
     * @return array Array of field_key => decrypted_value pairs.
     */
    public function decrypt_fields( array $fields ): array {
        $result = [];
        foreach ( $fields as $key => $value ) {
            $result[ $key ] = $this->maybe_decrypt( $value, $key );
        }
        return $result;
    }

    // =========================================================================
    // UTILITY METHODS
    // =========================================================================

    /**
     * Generate a secure random encryption key.
     *
     * Helper method for administrators to generate a strong key.
     *
     * @param int $length The desired key length (default: 64 characters).
     * @return string A cryptographically secure random key.
     */
    public static function generate_key( int $length = 64 ): string {
        return bin2hex( random_bytes( $length / 2 ) );
    }

    /**
     * Test encryption/decryption functionality.
     *
     * @return array{success: bool, message: string, details: array}
     */
    public function test(): array {
        $details = [
            'openssl_available' => function_exists( 'openssl_encrypt' ),
            'cipher_supported'  => in_array( self::CIPHER_ALGO, openssl_get_cipher_methods(), true ),
            'key_configured'    => ! empty( $this->derived_key ),
            'hipaa_mode'        => function_exists( '\DependentMedia\ClientSync\Services\clisyc_is_hipaa_mode' ) 
                                  ? \DependentMedia\ClientSync\Services\clisyc_is_hipaa_mode() 
                                  : false,
        ];

        if ( ! $this->is_available() ) {
            return [
                'success' => false,
                'message' => __( 'Encryption is not available. Check OpenSSL and encryption key configuration.', 'client-sync' ),
                'details' => $details,
            ];
        }

        // Test encryption/decryption
        $test_value = 'ClientSync Encryption Test ' . wp_generate_password( 20 );
        $encrypted = $this->encrypt( $test_value );

        if ( false === $encrypted ) {
            return [
                'success' => false,
                'message' => __( 'Encryption failed.', 'client-sync' ),
                'details' => $details,
            ];
        }

        $decrypted = $this->decrypt( $encrypted );

        if ( $decrypted !== $test_value ) {
            return [
                'success' => false,
                'message' => __( 'Decryption produced incorrect result.', 'client-sync' ),
                'details' => $details,
            ];
        }

        $details['encryption_test'] = 'passed';
        $details['encrypted_length'] = strlen( $encrypted );
        $details['original_length'] = strlen( $test_value );

        return [
            'success' => true,
            'message' => __( 'Encryption is working correctly.', 'client-sync' ),
            'details' => $details,
        ];
    }
}

// =============================================================================
// GLOBAL HELPER FUNCTIONS
// =============================================================================

/**
 * Get the encryption service instance.
 *
 * @since 3.3.0
 * @return Encryption_Service
 */
function clisyc_encryption(): Encryption_Service {
    return Encryption_Service::get_instance();
}

/**
 * Encrypt a value if HIPAA mode is enabled.
 *
 * Convenience function for use throughout the plugin.
 *
 * @since 3.3.0
 * @param mixed  $value     The value to potentially encrypt.
 * @param string $field_key Optional field key for context.
 * @return mixed
 */
function clisyc_maybe_encrypt( $value, string $field_key = '' ) {
    return Encryption_Service::get_instance()->maybe_encrypt( $value, $field_key );
}

/**
 * Decrypt a value if it's encrypted.
 *
 * Convenience function for use throughout the plugin.
 *
 * @since 3.3.0
 * @param mixed  $value     The value to potentially decrypt.
 * @param string $field_key Optional field key for context.
 * @return mixed
 */
function clisyc_maybe_decrypt( $value, string $field_key = '' ) {
    return Encryption_Service::get_instance()->maybe_decrypt( $value, $field_key );
}