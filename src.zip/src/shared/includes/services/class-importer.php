<?php
/**
 * File: src/shared/includes/services/class-importer.php -> client-sync/includes/services/class-importer.php
 * The unified Importer service class.
 *
 * @package    ClientSync
 * @subpackage ClientSync/Services
 */

namespace DependentMedia\ClientSync\Services;

// *** REFACTORED ***: Updated use statements for new namespaces
use DependentMedia\ClientSync\Constants;
use DependentMedia\ClientSync\Core\Database_Manager;
use DependentMedia\ClientSync\Admin\Dimension_CPT_Manager;
use DependentMedia\ClientSync\Admin\Graph_Node_Manager;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Importer {

    private function log( $message ) {
        if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
            error_log( '[clisyc-IMPORTER] ' . $message );
        }
    }

    public function install_from_data( array $data ) {
        $this->log( '--- Starting Import Process ---' );
        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_print_r
        $this->log( 'Raw data received: ' . print_r( $data, true ) );

        $import_data = null;
        if ( isset( $data[0] ) && is_array( $data[0] ) ) {
            $import_data = $data[0];
            $this->log( 'Detected template file format (array with one object).' );
        } elseif ( isset( $data['options'] ) && isset( $data['cpts'] ) ) {
            $import_data = $data;
            $this->log( 'Detected direct export file format (single object).' );
        }

        if ( ! is_array( $import_data ) || ! isset( $import_data['options'], $import_data['cpts'] ) ) {
            $error_msg = 'Import data is invalid or missing required "options" or "cpts" keys.';
            $this->log( 'ERROR: ' . $error_msg );
            return new \WP_Error( 'invalid_format', $error_msg );
        }
        
        $this->log( 'Data format appears valid and has been processed.' );
        $this->_wipe_existing_data();

        // --- START: NEW PAGE CREATION LOGIC ---
        $page_id_map = $this->_import_pages( $import_data['pages'] ?? [] );
        // --- END: NEW PAGE CREATION LOGIC ---

        $options_to_import = $import_data['options'] ?? [];
        $visual_state_to_import = $options_to_import['clisyc_graph_visual_state'] ?? null;
        unset( $options_to_import['clisyc_graph_visual_state'] );

        if ( isset( $options_to_import[ Constants::OPTION_CUSTOM_DIMENSION_TYPES ] ) ) {
            update_option( Constants::OPTION_CUSTOM_DIMENSION_TYPES, $options_to_import[ Constants::OPTION_CUSTOM_DIMENSION_TYPES ] );
            $this->log( 'Saved `clisyc_custom_dimension_types` option.' );
        } else {
            $this->log( 'WARNING: `clisyc_custom_dimension_types` not found in import options.' );
        }

        if ( isset( $options_to_import[ Constants::OPTION_DIMENSION_FIELDS ] ) ) {
            update_option( Constants::OPTION_DIMENSION_FIELDS, $options_to_import[ Constants::OPTION_DIMENSION_FIELDS ] );
            $this->log( 'Saved `clisyc_dimension_fields` option.' );
        }
        $cpt_manager = new Dimension_CPT_Manager();
        $cpt_manager->register_custom_dimensions_cpts();
        $this->log( 'Programmatically registered CPTs for this request.' );

        if ( is_array( $options_to_import ) ) {
            foreach ( $options_to_import as $key => $value ) {
                if ( in_array( $key, [ Constants::OPTION_CUSTOM_DIMENSION_TYPES, Constants::OPTION_DIMENSION_FIELDS ], true ) ) {
                    continue;
                }
                // --- START: NEW PLACEHOLDER REPLACEMENT LOGIC ---
                if ( is_string( $value ) && str_starts_with( $value, '{{page_' ) ) {
                    $page_slug = str_replace( [ '{{page_', '}}' ], '', $value );
                    if ( isset( $page_id_map[ $page_slug ] ) ) {
                        $value = $page_id_map[ $page_slug ];
                        $this->log( "Replaced placeholder '{$value}' with new page ID {$value} for option '{$key}'." );
                    }
                }
                // --- END: NEW PLACEHOLDER REPLACEMENT LOGIC ---
                update_option( $key, $value );
                $this->log( "Saved option: {$key}" );
            }
        }
        
        flush_rewrite_rules();
        $this->log( 'Flushed rewrite rules.' );

        $import_maps = $this->_import_cpt_posts( $import_data['cpts'] ?? [] );

        if ( $visual_state_to_import && is_array( $visual_state_to_import ) ) {
            $translated_visual_state = [];
            $old_id_to_new_id_map = $import_maps['old_id_to_new_id'] ?? [];

            foreach ( $visual_state_to_import as $node_hash => $state ) {
                if ( strpos( $node_hash, ':' ) !== false ) {
                    list($cpt_slug, $old_id) = explode( ':', $node_hash );
                    
                    if ( isset( $old_id_to_new_id_map[ $old_id ] ) ) {
                        $new_id = $old_id_to_new_id_map[ $old_id ];
                        $new_hash = $cpt_slug . ':' . $new_id;
                        $translated_visual_state[ $new_hash ] = $state;
                        $this->log( "Translated visual state for node {$node_hash} to new hash {$new_hash}." );
                    } else {
                         $this->log( "WARNING: Could not find new post ID for old visual state key {$node_hash}." );
                    }
                } else {
                    $translated_visual_state[ $node_hash ] = $state;
                }
            }
            update_option( 'clisyc_graph_visual_state', $translated_visual_state );
            $this->log( 'Saved translated `clisyc_graph_visual_state` option.' );
        }

        $this->_import_relationships( $import_data['relationships'] ?? [], $import_maps['slug_to_new_id'] ?? [] );

        $graph_manager = new Graph_Node_Manager();
        $graph_manager->rebuild_index();
        $this->log( 'Rebuilt graph node index.' );
        
        $this->log( '--- Import Process Finished ---' );
        return true;
    }

    private function _wipe_existing_data() {
        global $wpdb;
        $this->log( 'Starting data wipe...' );
        $custom_types    = get_option( Constants::OPTION_CUSTOM_DIMENSION_TYPES, [] );
        $all_plugin_cpts = is_array( $custom_types ) ? array_keys( $custom_types ) : [];
        $this->log( 'Found ' . count( $all_plugin_cpts ) . ' CPTs to wipe posts from.' );

        foreach ( $all_plugin_cpts as $cpt_slug ) {
            if ( empty( $cpt_slug ) || strpos( $cpt_slug, 'clisyc_' ) !== 0 ) continue;
            $existing_posts = get_posts( [ 'post_type' => $cpt_slug, 'posts_per_page' => -1, 'post_status' => 'any', 'fields' => 'ids' ] );
            foreach ( $existing_posts as $post_id ) {
                wp_delete_post( $post_id, true );
            }
            $this->log( "  - Wiped " . count( $existing_posts ) . " posts from {$cpt_slug}." );
        }

        delete_option( Constants::OPTION_DIMENSION_REGISTRY );
        delete_option( Constants::OPTION_CUSTOM_DIMENSION_TYPES );
        delete_option( 'clisyc_graph_visual_state' );
        delete_option( Constants::OPTION_DIMENSION_FIELDS );

        $clisyc_db_manager = new Database_Manager();
        $clisyc_rels_table_name = $clisyc_db_manager->get_relationships_table_name();
        
        // Use prepared statement to satisfy WPCS (though TRUNCATE doesn't support placeholders)
        // Since we are getting the table name from a safe internal method, this is safe,
        // but we explicitly use the prefix to be doubly sure.
        $clisyc_rels_table_safe = $wpdb->prefix . 'clisyc_relationships';
        
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.SchemaChange, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is safely constructed from prefix.
        $wpdb->query( "TRUNCATE TABLE {$clisyc_rels_table_safe}" ); 
        
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange
        $wpdb->query( "TRUNCATE TABLE {$wpdb->prefix}clisyc_graph_nodes" ); 
        
        $this->log( 'Truncated custom tables.' );
        $this->log( 'Data wipe complete.' );
    }

    // --- START: NEW METHOD TO IMPORT PAGES ---
    private function _import_pages( array $pages_data ): array {
        $id_map = [];
        $this->log( 'Starting page import...' );

        if ( empty( $pages_data ) ) {
            $this->log( 'No pages to import.' );
            return [];
        }

        foreach ( $pages_data as $page_data ) {
            $slug = $page_data['post_name'] ?? '';
            if ( empty( $slug ) ) continue;

            $existing_page = get_page_by_path( $slug, OBJECT, 'page' );
            if ( $existing_page ) {
                $id_map[ $slug ] = $existing_page->ID;
                $this->log( "  - Found existing page '{$slug}' with ID {$existing_page->ID}." );
                continue;
            }

            $new_page_id = wp_insert_post( [
                'post_type'    => 'page',
                'post_name'    => $slug,
                'post_title'   => $page_data['post_title'] ?? ucfirst( $slug ),
                'post_content' => $page_data['post_content'] ?? '',
                'post_status'  => 'publish',
            ] );

            if ( $new_page_id > 0 ) {
                $id_map[ $slug ] = $new_page_id;
                $this->log( "  - SUCCESS: Created page '{$slug}' with new ID {$new_page_id}." );
            } else {
                $this->log( "  - ERROR: Failed to create page '{$slug}'." );
            }
        }
        $this->log( 'Finished page import.' );
        return $id_map;
    }
    // --- END: NEW METHOD ---

    private function _import_cpt_posts( array $cpts_data ): array {
        $slug_to_new_id_map = [];
        $old_id_to_new_id_map = [];
        $this->log( 'Starting CPT post import...' );

        foreach ( $cpts_data as $cpt_slug => $posts ) {
            $this->log( "  - Processing CPT: {$cpt_slug}" );
            if ( ! post_type_exists( $cpt_slug ) ) {
                $this->log( "    - ERROR: Post type '{$cpt_slug}' does not exist. Skipping." );
                continue;
            }
            if ( ! is_array( $posts ) ) {
                $this->log( "    - WARNING: No posts found for '{$cpt_slug}'. Skipping." );
                continue;
            }

            foreach ( $posts as $post_data ) {
                $old_slug = $post_data['post_name'] ?? sanitize_title( $post_data['post_title'] ?? '' );
                $original_id = $post_data['original_id'] ?? null;

                $meta_input_for_post = [];
                if ( isset( $post_data['post_meta'] ) && is_array( $post_data['post_meta'] ) ) {
                    foreach ( $post_data['post_meta'] as $meta_key => $meta_values ) {
                        if ( strpos( $meta_key, '_clisyc_' ) === 0 ) {
                            $value_to_unserialize = is_array( $meta_values ) ? ( $meta_values[0] ?? null ) : $meta_values;
                            $value = maybe_unserialize( $value_to_unserialize );
                            $meta_input_for_post[ $meta_key ] = $value;
                        }
                    }
                }

                $new_post_id = wp_insert_post( [
                    'post_type'    => $cpt_slug,
                    'post_name'    => $old_slug,
                    'post_title'   => $post_data['post_title'] ?? '',
                    'post_content' => $post_data['post_content'] ?? '',
                    'post_excerpt' => $post_data['post_excerpt'] ?? '',
                    'post_status'  => 'publish',
                    'meta_input'   => $meta_input_for_post,
                ], true );

                if ( is_wp_error( $new_post_id ) ) {
                    $this->log( "    - ERROR inserting post '{$old_slug}': " . $new_post_id->get_error_message() );
                } else {
                    $this->log( "    - SUCCESS: Inserted post '{$old_slug}' with new ID {$new_post_id} (Original ID was: {$original_id})." );
                    if ( $old_slug ) {
                        $slug_to_new_id_map[ $cpt_slug . '::' . $old_slug ] = $new_post_id;
                    }
                    if ( $original_id ) {
                        $old_id_to_new_id_map[ $original_id ] = $new_post_id;
                    }
                }
            }
        }
        $this->log( 'Finished CPT post import.' );
        return [
            'slug_to_new_id' => $slug_to_new_id_map,
            'old_id_to_new_id' => $old_id_to_new_id_map,
        ];
    }
    
    private function _import_relationships( array $relationships_data, array $slug_to_id_map ) {
        global $wpdb;
        $db_manager = new Database_Manager();
        $rels_table_name = $db_manager->get_relationships_table_name();
        $this->log( 'Starting relationship import...' );

        $inserted_relationships = []; // Track to prevent duplicates

        foreach ( $relationships_data as $rel ) {
            $parent_key = ( $rel['parent_type'] ?? '' ) . '::' . ( $rel['parent_slug'] ?? '' );
            $child_key  = ( $rel['child_type'] ?? '' ) . '::' . ( $rel['child_slug'] ?? '' );

            if ( isset( $slug_to_id_map[ $parent_key ] ) && isset( $slug_to_id_map[ $child_key ] ) ) {
                $new_parent_id = $slug_to_id_map[ $parent_key ];
                $new_child_id  = $slug_to_id_map[ $child_key ];
                
                // Create a unique key for this relationship
                $unique_key = $new_parent_id . '-' . $rel['parent_type'] . '-' . $new_child_id . '-' . $rel['child_type'];
                
                // Only insert if we haven't inserted this relationship yet
                if ( ! isset( $inserted_relationships[ $unique_key ] ) ) {
                    // Insert only ONE directional relationship (parent -> child)
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
                    $result = $wpdb->insert( $rels_table_name, [
                        'parent_object_id'   => $new_parent_id,
                        'parent_object_type' => $rel['parent_type'],
                        'child_object_id'    => $new_child_id,
                        'child_object_type'  => $rel['child_type']
                    ]);
                    
                    if ( $result ) {
                        $inserted_relationships[ $unique_key ] = true;
                        $this->log( "  - Inserted relationship: {$rel['parent_type']}:{$new_parent_id} -> {$rel['child_type']}:{$new_child_id}" );
                    } else {
                        $this->log( "  - ERROR inserting relationship: {$wpdb->last_error}" );
                    }
                } else {
                    $this->log( "  - SKIPPED duplicate relationship: {$unique_key}" );
                }
            } else {
                $this->log( "  - SKIPPING relationship: Could not map parent '{$parent_key}' or child '{$child_key}' to a new ID." );
            }
        }
        $this->log( 'Finished relationship import.' );
    }
}