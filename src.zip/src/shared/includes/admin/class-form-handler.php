<?php
/**
 * File: src/shared/includes/admin/class-form-handler.php
 * Handles all admin-post.php form submissions for the admin area.
 *
 * UPDATED: Added HIPAA compliance security hardening for data exports.
 *
 * @package    ClientSync
 * @subpackage ClientSync/Admin
 */

namespace DependentMedia\ClientSync\Admin;

use DependentMedia\ClientSync\Core\Database_Manager;
use DependentMedia\ClientSync\Admin\Dimension_CPT_Manager;
use DependentMedia\ClientSync\Core\Cron;
use DependentMedia\ClientSync\Services\Importer;
use DependentMedia\ClientSync\Constants;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Form_Handler {

	/**
	 * A reference to the database manager instance.
	 *
	 * @var \DependentMedia\ClientSync\Core\Database_Manager
	 */
	private $db_manager;

	/**
	 * Constructor.
	 *
	 * @param \DependentMedia\ClientSync\Core\Database_Manager $db_manager An instance of the database manager class.
	 */
	public function __construct( Database_Manager $db_manager ) {
		$this->db_manager = $db_manager;
	}

	/**
	 * Check if HIPAA mode is active.
	 *
	 * Uses the global helper function if available, otherwise checks
	 * both the constant and database option.
	 *
	 * @return bool True if HIPAA mode is active, false otherwise.
	 */
	private function is_hipaa_mode_active(): bool {
		// Use global helper if available
		if ( function_exists( '\DependentMedia\ClientSync\Services\clisyc_is_hipaa_mode' ) ) {
			return \DependentMedia\ClientSync\Services\clisyc_is_hipaa_mode();
		}

		// Fallback: Check constant first (set in wp-config.php for security)
		if ( defined( 'CLISYC_HIPAA_MODE' ) && CLISYC_HIPAA_MODE ) {
			return true;
		}

		// Fallback: Check database option
		return (bool) get_option( Constants::OPTION_HIPAA_MODE, false );
	}

	/**
	 * Registers all form handling hooks.
	 */
	public function register_hooks() {
		add_action( 'admin_post_clisyc_save_client_custom_field', [ $this, 'handle_save_client_custom_fields' ] );
		add_action( 'admin_post_clisyc_save_appointment_custom_field', [ $this, 'handle_save_appointment_custom_fields' ] );
		add_action( 'admin_post_clisyc_handle_testing_actions', [ $this, 'handle_testing_actions' ] );
		add_action( 'admin_init', [ $this, 'handle_list_view_actions' ] );
		add_action( 'admin_post_clisyc_handle_generate_slots_submission', [ $this, 'handle_generate_slots_submission' ] );
		add_action( 'admin_post_clisyc_handle_remove_past_slots', [ $this, 'handle_remove_past_slots' ] );
		add_action( 'admin_post_clisyc_export_settings', [ $this, 'handle_export_settings' ] );
		add_action( 'admin_post_clisyc_import_settings', [ $this, 'handle_import_settings' ] );
		add_action( 'admin_post_clisyc_export_database_data', [ $this, 'handle_export_database_data' ] );
		add_action( 'admin_post_clisyc_add_dimension_type', [ $this, 'handle_add_or_update_dimension_type' ] );
		add_action( 'admin_post_clisyc_delete_dimension_type', [ $this, 'handle_delete_dimension_type' ] );
		add_action( 'admin_post_clisyc_save_blocked_period', [ $this, 'handle_save_blocked_period' ] );
		add_action( 'admin_post_clisyc_delete_blocked_period', [ $this, 'handle_delete_blocked_period' ] );
		add_action( 'admin_post_clisyc_mark_milestone_complete', [ $this, 'handle_mark_milestone_complete' ] );
		add_action( 'admin_post_clisyc_save_dimension_custom_field', [ $this, 'handle_save_dimension_custom_fields' ] );

		// *** ADD THIS LINE *** - Saves the weekly schedule for dimension posts
		add_action( 'save_post', [ $this, 'save_dimension_schedule' ], 10, 2 );
	}

	/**
	 * Saves the weekly schedule when a dimension post is saved.
	 * Hooked into save_post for all dimension post types.
	 *
	 * @param int     $post_id The ID of the post being saved.
	 * @param \WP_Post $post    The post object.
	 */
	public function save_dimension_schedule( $post_id, $post ) {
		// Check if this is an autosave
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// Verify the user has permission to edit this post
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Check if our schedule data field exists in the POST data
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified via check_admin_referer() in metabox rendering or generally on post save.
		if ( ! isset( $_POST['clisyc_schedule_json_output'] ) ) {
			return;
		}

		// Get and decode the schedule data
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified on post save. JSON is decoded immediately.
		$schedule_json = isset( $_POST['clisyc_schedule_json_output'] ) ? wp_unslash( $_POST['clisyc_schedule_json_output'] ) : '';

		if ( empty( $schedule_json ) ) {
			return;
		}

		$schedule_data = json_decode( $schedule_json, true );

		// Validate that we have valid JSON
		if ( json_last_error() !== JSON_ERROR_NONE ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
				error_log( 'Client Sync: Invalid JSON in schedule data for post ' . $post_id . ': ' . json_last_error_msg() );
			}
			return;
		}

		// Optional: Additional validation
		if ( ! is_array( $schedule_data ) ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
				error_log( 'Client Sync: Schedule data is not an array for post ' . $post_id );
			}
			return;
		}

		// Save the schedule data as post meta
		$result = update_post_meta( $post_id, Constants::META_SCHEDULE, wp_json_encode( $schedule_data ) );

		// Optional: Log success for debugging
		if ( $result ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
				error_log( 'Client Sync: Successfully saved schedule for post ' . $post_id );
			}
		}
	}

	/**
	 * Handles marking a setup milestone as complete.
	 */
	public function handle_mark_milestone_complete() {
		$milestone_key = isset( $_POST['milestone_key'] ) ? sanitize_key( wp_unslash( $_POST['milestone_key'] ) ) : '';
		$nonce         = isset( $_POST['_wpnonce'] ) ? sanitize_key( wp_unslash( $_POST['_wpnonce'] ) ) : '';

		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_mark_milestone_' . $milestone_key ) ) {
			wp_die( 'Security check failed.' );
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Permission denied.' );
		}

		if ( ! empty( $milestone_key ) ) {
			$completed_milestones_option = get_option( Constants::OPTION_SETUP_MILESTONES, [] );
			if ( ! is_array( $completed_milestones_option ) ) {
				$completed_milestones_option = [];
			}
			$completed_milestones_option[ $milestone_key ] = true;
			update_option( Constants::OPTION_SETUP_MILESTONES, $completed_milestones_option );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=clisyc-settings&tab=setup' ) );
		exit;
	}

	/**
	 * Handles saving a new global blocked period.
	 */
	public function handle_save_blocked_period() {
		$nonce      = isset( $_POST['clisyc_blocked_period_nonce'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_blocked_period_nonce'] ) ) : '';
		$title      = isset( $_POST['blocked_period_title'] ) ? sanitize_text_field( wp_unslash( $_POST['blocked_period_title'] ) ) : '';
		$start_date = isset( $_POST['blocked_period_start_date'] ) ? sanitize_text_field( wp_unslash( $_POST['blocked_period_start_date'] ) ) : '';
		$end_date   = isset( $_POST['blocked_period_end_date'] ) ? sanitize_text_field( wp_unslash( $_POST['blocked_period_end_date'] ) ) : '';

		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_save_blocked_period_action' ) ) {
			wp_die( 'Security check failed.' );
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Permission denied.' );
		}

		if ( empty( $title ) || empty( $start_date ) || empty( $end_date ) ) {
			set_transient( 'clisyc_blocked_periods_feedback', [ 'error' => __( 'All fields are required to add a blocked period.', 'client-sync' ) ], 30 );
		} elseif ( strtotime( $end_date ) < strtotime( $start_date ) ) {
			set_transient( 'clisyc_blocked_periods_feedback', [ 'error' => __( 'End date cannot be before the start date.', 'client-sync' ) ], 30 );
		} else {
			$blocked_periods   = get_option( Constants::OPTION_GLOBAL_BLOCKED_PERIODS, [] );
			$blocked_periods[] = [
				'title'      => $title,
				'start_date' => $start_date,
				'end_date'   => $end_date,
			];
			update_option( Constants::OPTION_GLOBAL_BLOCKED_PERIODS, $blocked_periods );
			set_transient( 'clisyc_blocked_periods_feedback', [ 'message' => __( 'Blocked period added successfully.', 'client-sync' ) ], 30 );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=clisyc-calendars&tab=blocked-periods' ) );
		exit;
	}

	/**
	 * Handles deleting an existing global blocked period.
	 */
	public function handle_delete_blocked_period() {
		$period_index = isset( $_GET['period_index'] ) ? absint( wp_unslash( $_GET['period_index'] ) ) : -1;
		$nonce        = isset( $_GET['_wpnonce'] ) ? sanitize_key( wp_unslash( $_GET['_wpnonce'] ) ) : '';

		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_delete_blocked_period_' . $period_index ) ) {
			wp_die( 'Security check failed.' );
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Permission denied.' );
		}

		if ( $period_index >= 0 ) {
			$blocked_periods = get_option( Constants::OPTION_GLOBAL_BLOCKED_PERIODS, [] );
			if ( isset( $blocked_periods[ $period_index ] ) ) {
				unset( $blocked_periods[ $period_index ] );
				// Re-index the array to prevent issues.
				update_option( Constants::OPTION_GLOBAL_BLOCKED_PERIODS, array_values( $blocked_periods ) );
				set_transient( 'clisyc_blocked_periods_feedback', [ 'message' => __( 'Blocked period deleted.', 'client-sync' ) ], 30 );
			}
		}

		wp_safe_redirect( admin_url( 'admin.php?page=clisyc-calendars&tab=blocked-periods' ) );
		exit;
	}

	/**
	 * Handles all form submissions for Appointment Custom Fields, including conditional logic.
	 */
	public function handle_save_appointment_custom_fields() {
		$nonce      = isset( $_POST['clisyc_appointment_custom_field_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['clisyc_appointment_custom_field_nonce'] ) ) : '';
		$sub_action = isset( $_POST['clisyc_sub_action'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_sub_action'] ) ) : '';

		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_save_appointment_custom_field_action' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'client-sync' ) );
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'client-sync' ) );
		}

		$custom_fields = get_option( Constants::OPTION_APPOINTMENT_FIELDS, [] );
		$field_order   = get_option( 'clisyc_appointment_custom_fields_order', [] );
		if ( ! is_array( $custom_fields ) ) {
			$custom_fields = [];
		}
		if ( ! is_array( $field_order ) ) {
			$field_order = [];
		}

		$redirect_url   = admin_url( 'admin.php?page=clisyc-custom-fields&cf_tab=appointments-cf' );
		$notice_type    = null;
		$notice_message = null;

		if ( empty( $sub_action ) ) {
			wp_die( esc_html__( 'Invalid action specified.', 'client-sync' ) );
		}

		if ( 'add_field' === $sub_action || 'update_field' === $sub_action ) {
			$field_key = '';
			if ( 'add_field' === $sub_action ) {
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				$field_key = isset( $_POST['field_key'] ) ? sanitize_key( strtolower( str_replace( ' ', '_', wp_unslash( $_POST['field_key'] ) ) ) ) : '';
			} else {
				$field_key = isset( $_POST['edit_field_key'] ) ? sanitize_key( wp_unslash( $_POST['edit_field_key'] ) ) : '';
			}

			if ( empty( $field_key ) ) {
				$notice_type    = 'error';
				$notice_message = ( 'add_field' === $sub_action ) ? __( 'Field Key is required.', 'client-sync' ) : __( 'Field to update not specified.', 'client-sync' );
			} elseif ( 'add_field' === $sub_action && ! preg_match( '/^[a-z0-9_]+$/', $field_key ) ) {
				$notice_type    = 'error';
				$notice_message = __( 'Field Key format invalid. Lowercase letters, numbers, and underscores only.', 'client-sync' );
			} elseif ( 'add_field' === $sub_action && isset( $custom_fields[ $field_key ] ) ) {
				$notice_type    = 'error';
				$notice_message = __( 'Field Key already exists.', 'client-sync' );
			} elseif ( 'update_field' === $sub_action && ! isset( $custom_fields[ $field_key ] ) ) {
				$notice_type    = 'error';
				$notice_message = __( 'Field Key to update does not exist.', 'client-sync' );
			} else {
				$field_type         = isset( $_POST['field_type'] ) ? sanitize_key( wp_unslash( $_POST['field_type'] ) ) : 'text';
				
				// Fix: Sanitize the JSON string using sanitize_textarea_field to allow quotes but block malicious scripts.
				$field_options_json = ( in_array( $field_type, [ 'select', 'multi_checkbox', 'radio' ], true ) && isset( $_POST['field_options'] ) ) ?
					sanitize_textarea_field( wp_unslash( $_POST['field_options'] ) ) :
					'[]';
					
				$sanitized_options  = [];
				if ( is_string( $field_options_json ) && ! empty( $field_options_json ) ) {
					$decoded_options = json_decode( $field_options_json, true );
					if ( is_array( $decoded_options ) ) {
						foreach ( $decoded_options as $option ) {
							if ( is_array( $option ) && ! empty( $option['value'] ) ) {
								$sanitized_options[] = [
									'value' => sanitize_text_field( trim( $option['value'] ) ),
									'color' => isset( $option['color'] ) ? sanitize_hex_color( trim( $option['color'] ) ) : '',
								];
							}
						}
					}
				}

				$field_label            = isset( $_POST['field_label'] ) ? sanitize_text_field( wp_unslash( $_POST['field_label'] ) ) : '';
				$field_required         = isset( $_POST['field_required'] ) ? '1' : '0';
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				$field_custom_html      = isset( $_POST['field_custom_html'] ) ? wp_unslash( $_POST['field_custom_html'] ) : ''; // wp_kses_post is applied below
				$field_layout           = isset( $_POST['field_layout'] ) ? sanitize_key( wp_unslash( $_POST['field_layout'] ) ) : '';
				$field_image_id         = isset( $_POST['field_image_id'] ) ? absint( wp_unslash( $_POST['field_image_id'] ) ) : 0;
				$field_track_progress   = isset( $_POST['field_track_progress'] ) ? '1' : '0';
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				$conditional_logic_json = isset( $_POST['conditional_logic_json'] ) ? wp_unslash( $_POST['conditional_logic_json'] ) : ''; // Sanitized in its own method

				$field_data = [
					'label'             => $field_label,
					'type'              => $field_type,
					'options'           => $sanitized_options,
					'required'          => ( '1' === $field_required && ! in_array( $field_type, [ 'custom_html', 'image_map' ] ) ),
					'html_content'      => ( 'custom_html' === $field_type ) ? wp_kses_post( $field_custom_html ) : '',
					'layout'            => ( in_array( $field_type, [ 'multi_checkbox', 'radio' ], true ) && 'horizontal' === $field_layout ) ? 'horizontal' : 'vertical',
					'image_id'          => ( 'image_map' === $field_type ) ? $field_image_id : 0,
					'track_progress'    => ( in_array( $field_type, [ 'text', 'select', 'number' ] ) && '1' === $field_track_progress ),
					'conditional_logic' => $this->_sanitize_conditional_logic( $conditional_logic_json ),
				];

				if ( 'custom_html' !== $field_data['type'] ) {
					unset( $field_data['html_content'] );
				}
				if ( ! in_array( $field_data['type'], [ 'select', 'multi_checkbox', 'radio' ] ) ) {
					unset( $field_data['options'] );
				}
				if ( ! in_array( $field_data['type'], [ 'multi_checkbox', 'radio' ] ) ) {
					unset( $field_data['layout'] );
				}
				if ( 'image_map' !== $field_data['type'] ) {
					unset( $field_data['image_id'] );
				}
				if ( ! in_array( $field_data['type'], [ 'text', 'select', 'number' ] ) ) {
					unset( $field_data['track_progress'] );
				}

				$custom_fields[ $field_key ] = $field_data;
				if ( update_option( Constants::OPTION_APPOINTMENT_FIELDS, $custom_fields ) ) {
					if ( 'add_field' === $sub_action && ! in_array( $field_key, $field_order, true ) ) {
						$field_order[] = $field_key;
						update_option( 'clisyc_appointment_custom_fields_order', $field_order );
					}
					$notice_type    = 'success';
					$notice_message = ( 'add_field' === $sub_action ) ? __( 'Appointment custom field added.', 'client-sync' ) : __( 'Appointment custom field updated.', 'client-sync' );
				} else {
					$notice_type    = 'info';
					$notice_message = __( 'No changes detected in appointment custom field.', 'client-sync' );
				}
			}
		} elseif ( 'delete_field' === $sub_action ) {
			$delete_field_key = isset( $_POST['delete_field_key'] ) ? sanitize_key( wp_unslash( $_POST['delete_field_key'] ) ) : '';
			if ( ! empty( $delete_field_key ) && isset( $custom_fields[ $delete_field_key ] ) ) {
				unset( $custom_fields[ $delete_field_key ] );
				if ( update_option( Constants::OPTION_APPOINTMENT_FIELDS, $custom_fields ) ) {
					$field_order    = array_values( array_diff( $field_order, [ $delete_field_key ] ) );
					update_option( 'clisyc_appointment_custom_fields_order', $field_order );
					$notice_type    = 'success';
					$notice_message = __( 'Appointment custom field deleted.', 'client-sync' );
				}
			}
		}

		if ( $notice_type && $notice_message ) {
			set_transient( 'clisyc_custom_field_feedback', [ 'type' => $notice_type, 'message' => $notice_message ], 30 );
		}
		wp_safe_redirect( $redirect_url );
		exit;
	}

	public function handle_save_client_custom_fields() {
		$nonce      = isset( $_POST['clisyc_custom_field_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['clisyc_custom_field_nonce'] ) ) : '';
		$sub_action = isset( $_POST['clisyc_sub_action'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_sub_action'] ) ) : '';

		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_save_client_custom_field_action' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'client-sync' ) );
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'client-sync' ) );
		}

		$custom_fields = get_option( Constants::OPTION_CUSTOM_FIELDS, [] );
		$field_order   = get_option( Constants::OPTION_CUSTOM_FIELDS_ORDER, [] );
		if ( ! is_array( $custom_fields ) ) {
			$custom_fields = [];
		}
		if ( ! is_array( $field_order ) ) {
			$field_order = [];
		}

		$redirect_url   = admin_url( 'admin.php?page=clisyc-custom-fields&cf_tab=clients-cf' );
		$notice_type    = null;
		$notice_message = null;

		if ( empty( $sub_action ) ) {
			wp_die( esc_html__( 'Invalid action specified.', 'client-sync' ) );
		}

		if ( 'save_list_table_settings' === $sub_action ) {
			$column_field = isset( $_POST['client_list_custom_field_column'] ) ? sanitize_key( wp_unslash( $_POST['client_list_custom_field_column'] ) ) : '';
			update_option( Constants::OPTION_CLIENT_LIST_CF_COLUMN, $column_field );
			$notice_type    = 'success';
			$notice_message = __( 'User list column setting saved.', 'client-sync' );
		} elseif ( 'add_field' === $sub_action || 'update_field' === $sub_action ) {
			$field_key = '';
			if ( 'add_field' === $sub_action ) {
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				$field_key = isset( $_POST['field_key'] ) ? sanitize_key( strtolower( str_replace( ' ', '_', wp_unslash( $_POST['field_key'] ) ) ) ) : '';
			} else {
				$field_key = isset( $_POST['edit_field_key'] ) ? sanitize_key( wp_unslash( $_POST['edit_field_key'] ) ) : '';
			}

			if ( empty( $field_key ) ) {
				$notice_type    = 'error';
				$notice_message = ( 'add_field' === $sub_action ) ? __( 'Field Key is required.', 'client-sync' ) : __( 'Field to update not specified.', 'client-sync' );
			} elseif ( 'add_field' === $sub_action && ! preg_match( '/^[a-z0-9_]+$/', $field_key ) ) {
				$notice_type    = 'error';
				$notice_message = __( 'Field Key format invalid.', 'client-sync' );
			} elseif ( 'add_field' === $sub_action && isset( $custom_fields[ $field_key ] ) ) {
				$notice_type    = 'error';
				$notice_message = __( 'Field Key already exists.', 'client-sync' );
			} elseif ( 'update_field' === $sub_action && ! isset( $custom_fields[ $field_key ] ) ) {
				$notice_type    = 'error';
				$notice_message = __( 'Field Key to update does not exist.', 'client-sync' );
			} else {
				$field_type         = isset( $_POST['field_type'] ) ? sanitize_key( wp_unslash( $_POST['field_type'] ) ) : 'text';
				
				// Fix: Sanitize the JSON string using sanitize_textarea_field to allow quotes but block malicious scripts.
				$field_options_json = ( in_array( $field_type, [ 'select', 'multi_checkbox', 'radio' ], true ) && isset( $_POST['field_options'] ) ) ?
				sanitize_textarea_field( wp_unslash( $_POST['field_options'] ) ) :
				'[]';
				
				$field_options_array     = json_decode( $field_options_json, true );
				$sanitized_field_options = [];
				if ( is_array( $field_options_array ) ) {
					foreach ( $field_options_array as $option_item ) {
						if ( is_array( $option_item ) && isset( $option_item['value'] ) ) {
							$sanitized_item = [
								'value' => sanitize_text_field( trim( $option_item['value'] ) ),
								'color' => isset( $option_item['color'] ) ? sanitize_hex_color( trim( $option_item['color'] ) ) : '',
							];
							if ( ! empty( $sanitized_item['value'] ) ) {
								$sanitized_field_options[] = $sanitized_item;
							}
						}
					}
				}

				$field_label       = isset( $_POST['field_label'] ) ? sanitize_text_field( wp_unslash( $_POST['field_label'] ) ) : '';
				$field_required    = isset( $_POST['field_required'] ) ? '1' : '0';
				// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				$field_custom_html = isset( $_POST['field_custom_html'] ) ? wp_unslash( $_POST['field_custom_html'] ) : '';
				$field_layout      = isset( $_POST['field_layout'] ) ? sanitize_key( wp_unslash( $_POST['field_layout'] ) ) : '';
				$field_image_id    = isset( $_POST['field_image_id'] ) ? absint( wp_unslash( $_POST['field_image_id'] ) ) : 0;

				$field_data = [
					'label'        => $field_label,
					'type'         => $field_type,
					'required'     => ( '1' === $field_required && ! in_array( $field_type, [ 'custom_html', 'image_map' ], true ) ),
					'options'      => $sanitized_field_options,
					'html_content' => ( 'custom_html' === $field_type ) ? wp_kses_post( $field_custom_html ) : '',
					'layout'       => ( in_array( $field_type, [ 'multi_checkbox', 'radio' ], true ) && 'horizontal' === $field_layout ) ? 'horizontal' : 'vertical',
					'image_id'     => ( 'image_map' === $field_type ) ? $field_image_id : 0,
				];

				if ( 'custom_html' !== $field_data['type'] ) {
					unset( $field_data['html_content'] );
				}
				if ( ! in_array( $field_data['type'], [ 'select', 'multi_checkbox', 'radio' ], true ) ) {
					unset( $field_data['options'] );
				}
				if ( ! in_array( $field_data['type'], [ 'multi_checkbox', 'radio' ], true ) ) {
					unset( $field_data['layout'] );
				}
				if ( 'image_map' !== $field_data['type'] ) {
					unset( $field_data['image_id'] );
				}

				$custom_fields[ $field_key ] = $field_data;
				if ( update_option( Constants::OPTION_CUSTOM_FIELDS, $custom_fields ) ) {
					if ( 'add_field' === $sub_action && ! in_array( $field_key, $field_order, true ) ) {
						$field_order[] = $field_key;
						update_option( Constants::OPTION_CUSTOM_FIELDS_ORDER, $field_order );
					}
					$notice_type    = 'success';
					$notice_message = ( 'add_field' === $sub_action ) ? __( 'Client custom field added.', 'client-sync' ) : __( 'Client custom field updated.', 'client-sync' );
				} else {
					$notice_type    = 'info';
					$notice_message = __( 'Client custom field not changed.', 'client-sync' );
				}
			}
		} elseif ( 'delete_field' === $sub_action ) {
			$delete_field_key = isset( $_POST['delete_field_key'] ) ? sanitize_key( wp_unslash( $_POST['delete_field_key'] ) ) : '';
			if ( ! empty( $delete_field_key ) && isset( $custom_fields[ $delete_field_key ] ) ) {
				unset( $custom_fields[ $delete_field_key ] );
				if ( update_option( Constants::OPTION_CUSTOM_FIELDS, $custom_fields ) ) {
					$field_order    = array_values( array_diff( $field_order, [ $delete_field_key ] ) );
					update_option( Constants::OPTION_CUSTOM_FIELDS_ORDER, $field_order );
					$notice_type    = 'success';
					$notice_message = __( 'Client custom field deleted.', 'client-sync' );
				} else {
					$notice_type    = 'error';
					$notice_message = __( 'Failed to save changes after deleting client field definition.', 'client-sync' );
				}
			} else {
				$notice_type    = 'error';
				$notice_message = __( 'Field to delete was not found.', 'client-sync' );
			}
		}

		if ( $notice_type && $notice_message ) {
			set_transient( 'clisyc_custom_field_feedback', [ 'type' => $notice_type, 'message' => $notice_message ], 30 );
		}
		wp_safe_redirect( $redirect_url );
		exit;
	}

	/**
	 * Handles form submissions for Dimension Custom Fields.
	 */
	public function handle_save_dimension_custom_fields() {
		check_admin_referer( 'clisyc_save_dimension_custom_field_action', 'clisyc_dimension_custom_field_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Permission denied.' );
		}

		$redirect_url   = admin_url( 'admin.php?page=clisyc-custom-fields&cf_tab=dimensions-cf' );
		$unslashed_post = wp_unslash( $_POST );
		$sub_action     = sanitize_key( $unslashed_post['clisyc_sub_action'] ?? 'add_field' );

		$fields = get_option( Constants::OPTION_DIMENSION_FIELDS, [] );
		if ( ! is_array( $fields ) ) {
			$fields = [];
		}

		if ( 'delete_field' === $sub_action ) {
			$key_to_delete = sanitize_key( $unslashed_post['delete_field_key'] ?? '' );
			if ( ! empty( $key_to_delete ) && isset( $fields[ $key_to_delete ] ) ) {
				unset( $fields[ $key_to_delete ] );
				update_option( Constants::OPTION_DIMENSION_FIELDS, $fields );
				set_transient( 'clisyc_custom_field_feedback', [ 'type' => 'success', 'message' => 'Dimension Attribute deleted.' ], 30 );
			}
		} elseif ( 'add_field' === $sub_action || 'update_field' === $sub_action ) {
			$field_key = ( 'add_field' === $sub_action )
				? sanitize_key( $unslashed_post['field_key'] ?? '' )
				: sanitize_key( $unslashed_post['edit_field_key'] ?? '' );

			if ( empty( $field_key ) ) {
				set_transient( 'clisyc_custom_field_feedback', [ 'type' => 'error', 'message' => 'Field Key is required.' ], 30 );
			} elseif ( 'add_field' === $sub_action && isset( $fields[ $field_key ] ) ) {
				set_transient( 'clisyc_custom_field_feedback', [ 'type' => 'error', 'message' => 'Field Key already exists.' ], 30 );
			} else {
				$applies_to = isset( $unslashed_post['field_applies_to'] ) && is_array( $unslashed_post['field_applies_to'] )
					? array_map( 'sanitize_key', $unslashed_post['field_applies_to'] )
					: [];

				$allowed_operators = [ '=', '>=', '<=' ];
				$comparison_op     = $unslashed_post['field_comparison_operator'] ?? '=';

				$fields[ $field_key ] = [
					'label'               => sanitize_text_field( $unslashed_post['field_label'] ?? '' ),
					'type'                => sanitize_key( $unslashed_post['field_type'] ?? 'text' ),
					'icon'                => sanitize_text_field( $unslashed_post['field_icon'] ?? 'dashicons-admin-generic' ),
					'filterable'          => ! empty( $unslashed_post['field_filterable'] ),
					'options'             => sanitize_textarea_field( $unslashed_post['field_options'] ?? '' ),
					'applies_to'          => $applies_to,
					'comparison_operator' => in_array( $comparison_op, $allowed_operators, true ) ? $comparison_op : '=',
				];

				update_option( Constants::OPTION_DIMENSION_FIELDS, $fields );
				$message = ( 'add_field' === $sub_action ) ? 'Dimension Attribute added.' : 'Dimension Attribute updated.';
				set_transient( 'clisyc_custom_field_feedback', [ 'type' => 'success', 'message' => $message ], 30 );
			}
		}

		wp_safe_redirect( $redirect_url );
		exit;
	}

	public function handle_testing_actions() {
		$action = isset( $_POST['clisyc_test_action'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_test_action'] ) ) : '';
		if ( ! $action || ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Invalid action or insufficient permissions.', 'client-sync' ) );
		}
		if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
			wp_die( 'Testing tools are only available when WP_DEBUG is enabled.' );
		}

		$redirect_url = admin_url( 'admin.php?page=clisyc-testing' );
		$feedback     = [];

		switch ( $action ) {
			case 'generate_file_tree':
				$nonce = isset( $_POST['clisyc_testing_file_tree_nonce'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_testing_file_tree_nonce'] ) ) : '';
				if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_testing_generate_file_tree' ) ) {
					wp_die( 'Security check failed.' );
				}

				$file_tree_content = \DependentMedia\ClientSync\Admin\Admin::generate_file_tree( clisyc_PLUGIN_DIR );
				$filename          = 'clisyc-file-tree-' . wp_date( 'Y-m-d' ) . '.txt';

				header( 'Content-Type: text/plain; charset=utf-8' );
				header( 'Content-Disposition: attachment; filename="' . $filename . '"' );

				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo $file_tree_content;
				exit;

			case 'generate_site_file_tree':
				$nonce = isset( $_POST['clisyc_testing_site_file_tree_nonce'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_testing_site_file_tree_nonce'] ) ) : '';
				if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_testing_generate_site_file_tree' ) ) {
					wp_die( 'Security check failed.' );
				}

				$file_tree_content = \DependentMedia\ClientSync\Admin\Admin::generate_file_tree( ABSPATH );
				$filename          = 'site-root-file-tree-' . wp_date( 'Y-m-d' ) . '.txt';

				header( 'Content-Type: text/plain; charset=utf-8' );
				header( 'Content-Disposition: attachment; filename="' . $filename . '"' );

				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo $file_tree_content;
				exit;

			case 'force_run_frequent_maintenance':
				$nonce = isset( $_POST['clisyc_testing_run_frequent_cron_nonce'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_testing_run_frequent_cron_nonce'] ) ) : '';
				if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_testing_run_frequent_cron' ) ) {
					wp_die( 'Security check failed.' );
				}

				// Reset state to ensure manual run starts fresh
				delete_option( Constants::OPTION_SLOT_GEN_STATE );

				$cron_manager = new \DependentMedia\ClientSync\Core\Cron( $this->db_manager );
				$cron_manager->run_frequent_maintenance_tasks();
				$feedback['message'] = __( 'Forced maintenance tasks complete. Check debug.log for details on slot generation.', 'client-sync' );
				
				// Redirect back to the Automation tab if that's where the request came from
				$referer = wp_get_referer();
				if ( $referer && strpos( $referer, 'tab=automation' ) !== false ) {
					$redirect_url = admin_url( 'admin.php?page=clisyc-settings&tab=automation' );
				}
				break;

			case 'reset_plugin':
				$nonce = isset( $_POST['clisyc_testing_reset_nonce'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_testing_reset_nonce'] ) ) : '';
				if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_testing_reset' ) ) {
					wp_die( 'Security check failed.' );
				}

				// 1. Wipe all dimension CPTs and tables.
				if ( class_exists( '\DependentMedia\ClientSync\Admin\Onboarding_Wizard' ) ) {
					$wizard_instance = new \DependentMedia\ClientSync\Admin\Onboarding_Wizard();
					$wizard_instance->wipe_all_dimension_data();
				}

				// 2. Wipe appointment CPTs and related tables
				global $wpdb;
				$slots_table    = $this->db_manager->get_slots_table_name();
				$dims_table     = $this->db_manager->get_dimensions_table_name();
				$bookings_table = $wpdb->prefix . 'clisyc_bookings';

				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names from internal methods are safe; truncating tables is an admin action.
				$wpdb->query( "TRUNCATE TABLE {$slots_table}" );
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names from internal methods are safe.
				$wpdb->query( "TRUNCATE TABLE {$dims_table}" );
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name uses $wpdb->prefix which is safe.
				$wpdb->query( "TRUNCATE TABLE {$bookings_table}" );

				$appointment_posts = get_posts(
					[
						'post_type'   => Constants::POST_TYPE_APPOINTMENT,
						'post_status' => 'any',
						'numberposts' => -1,
						'fields'      => 'ids',
					]
				);
				foreach ( $appointment_posts as $post_id ) {
					wp_delete_post( $post_id, true );
				}

				// 3. Delete all plugin options
				$options_to_delete = [
					Constants::OPTION_CALENDAR_START_TIME, 'clisyc_calendar_end_time', 'clisyc_calendar_slot_duration',
					'clisyc_standard_schedule_calendar_start_time', 'clisyc_standard_schedule_calendar_end_time',
					'clisyc_frontend_calendar_style', 'clisyc_login_page_url', 'clisyc_last_frequent_maintenance_run_timestamp',
					'clisyc_available_time_slots', Constants::OPTION_CUSTOM_FIELDS, Constants::OPTION_CUSTOM_FIELDS_ORDER,
					Constants::OPTION_APPOINTMENT_FIELDS, 'clisyc_appointment_custom_fields_order', 'clisyc_client_list_custom_field_column',
					Constants::OPTION_NOTIFICATION_SETTINGS, Constants::OPTION_EMAIL_FROM_NAME, Constants::OPTION_EMAIL_FROM_ADDRESS,
					Constants::OPTION_NOTIFICATION_ADMINS, 'clisyc_reminder_settings', 'clisyc_appointment_view_page_slug',
					'clisyc_auto_generate_enabled', 'clisyc_auto_generate_lookahead', 'clisyc_wc_integration_enabled',
					'clisyc_wc_appointment_product_id', 'clisyc_min_booking_notice_minutes', 'clisyc_global_buffer_before',
					'clisyc_global_buffer_after', 'clisyc_slots_migrated_to_db_v2', Constants::OPTION_SETUP_MILESTONES,
					'clisyc_calendar_smart_start_date', 'clisyc_calendar_week_starts_on', 'clisyc_debug_standard_schedule_output',
					'clisyc_appointment_view_page_id', 'clisyc_booking_page_id', 'clisyc_booking_success_page_id',
					Constants::OPTION_ENABLE_SELF_SERVICE, Constants::OPTION_CANCEL_CUTOFF_VALUE, Constants::OPTION_CANCEL_CUTOFF_UNIT,
					Constants::OPTION_CANCEL_REFUND_POLICY, 'clisyc_mysql_convert_tz_override', 'clisyc_mysql_convert_tz_status',
					Constants::OPTION_CALENDAR_COLOR_SETTINGS, Constants::OPTION_DIMENSION_REGISTRY, Constants::OPTION_CUSTOM_DIMENSION_TYPES,
					// NEW OPTIONS
					'clisyc_slot_gen_state',
					'clisyc_search_results_page_id',
					'clisyc_global_blocked_periods',
					'clisyc_manager_edit_page_id',
					'clisyc_contact_page_id',
					'clisyc_last_successful_maintenance_run_timestamp',
				];
				foreach ( $options_to_delete as $option_name ) {
					delete_option( $option_name );
				}

				// 4. Clean up transients and crons
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( '_transient_clisyc_' ) . '%' ) );
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( '_transient_timeout_clisyc_' ) . '%' ) );

				$cron_manager = new \DependentMedia\ClientSync\Core\Cron( $this->db_manager );
				$cron_manager->unschedule_cron_jobs();

				// 5. Reactivate to set up defaults
				if ( class_exists( '\DependentMedia\ClientSync\Plugin' ) ) {
					$plugin_instance = new \DependentMedia\ClientSync\Plugin();
					$plugin_instance->activate();
				}

				$feedback['message'] = __( 'Plugin has been completely reset to default settings.', 'client-sync' );
				break;

			case 'repair_relationships':
				$nonce = isset( $_POST['clisyc_testing_repair_rels_nonce'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_testing_repair_rels_nonce'] ) ) : '';
				if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_testing_repair_rels' ) ) {
					wp_die( 'Security check failed.' );
				}
				$db_manager = new \DependentMedia\ClientSync\Core\Database_Manager();
				$result     = $db_manager->repair_missing_relationship_types();
				/* translators: 1: Number of repaired rows. 2: Number of unrepaired rows. */
				$feedback['message'] = sprintf( __( 'Relationship repair complete. Repaired: %1$d rows. Could not repair: %2$d rows.', 'client-sync' ), $result['repaired'], $result['unrepaired'] );
				break;

			case 'rebuild_graph_index':
				$nonce = isset( $_POST['clisyc_rebuild_index_nonce'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_rebuild_index_nonce'] ) ) : '';
				if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_rebuild_graph_index_action' ) ) {
					wp_die( 'Security check failed.' );
				}
				if ( class_exists( '\DependentMedia\ClientSync\Admin\Graph_Node_Manager' ) ) {
					$graph_node_manager = new \DependentMedia\ClientSync\Admin\Graph_Node_Manager();
					$graph_node_manager->rebuild_index();
					$feedback['message'] = __( 'The dimension graph index has been successfully rebuilt.', 'client-sync' );
				} else {
					$feedback['error'] = __( 'Could not find the Graph_Node_Manager class.', 'client-sync' );
				}
				break;

			case 'clear_transients':
				$nonce = isset( $_POST['clisyc_testing_clear_transients_nonce'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_testing_clear_transients_nonce'] ) ) : '';
				if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_testing_clear_transients' ) ) {
					wp_die( 'Security check failed.' );
				}
				$db_manager = new \DependentMedia\ClientSync\Core\Database_Manager();
				$db_manager->clear_all_slot_cache();

				// Also clear Smart Start Date cached option (used by some shortcodes)
				delete_option( 'clisyc_calendar_smart_start_date_next_available' );

				// Clear MySQL timezone detection status to allow re-detection
				delete_option( 'clisyc_mysql_convert_tz_status' );

				// Clear the Batch Generation State (fixes stalled cron jobs)
				delete_option( Constants::OPTION_SLOT_GEN_STATE );

				$feedback['message'] = __( 'All Client Sync transients, caches, generation states, and Smart Start Date data have been cleared.', 'client-sync' );
				break;

			case 'remove_ds_store':
				$nonce = isset( $_POST['clisyc_testing_remove_ds_store_nonce'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_testing_remove_ds_store_nonce'] ) ) : '';
				if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_testing_remove_ds_store' ) ) {
					wp_die( 'Security check failed.' );
				}

				$deleted_count = 0;
				try {
					// THE FIX: Scan from the parent of the shared directory to cover shared, free, and pro.
					// We use CLISYC_SHARED_DIR as our anchor and go up one level to the 'src' folder.
					$scan_path = dirname( rtrim( CLISYC_SHARED_DIR, '/\\' ) );

					// We use RecursiveDirectoryIterator WITHOUT SKIP_DOTS to ensure .DS_Store is found.
					$dir_iterator = new \RecursiveDirectoryIterator( $scan_path );
					$iterator     = new \RecursiveIteratorIterator( $dir_iterator, \RecursiveIteratorIterator::CHILD_FIRST );

					foreach ( $iterator as $file_info ) {
						// Check for exactly '.DS_Store'
						if ( $file_info->getFilename() === '.DS_Store' ) {
							$path = $file_info->getRealPath();

							/**
							 * We use native PHP unlink and is_writable here because this is a specific 
							 * cleanup utility for hidden system files. Using WP_Filesystem here would 
							 * require prompting the admin for credentials on many server setups, 
							 * which is intrusive for a simple developer maintenance tool.
							 */
							
							// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable, WordPress.WP.AlternativeFunctions.unlink_unlink -- Native functions used for targeted system file cleanup.
							if ( file_exists( $path ) && is_writable( $path ) && @unlink( $path ) ) {
								$deleted_count++;
							}
						}
					}

					if ( $deleted_count > 0 ) {
						/* translators: %d: The number of .DS_Store files found and deleted. */
						$feedback['message'] = sprintf( _n( 'Success: %d .DS_Store file was found and deleted.', 'Success: %d .DS_Store files were found and deleted.', $deleted_count, 'client-sync' ), $deleted_count );
					} else {
						$feedback['message'] = __( 'Scan complete. No .DS_Store files were found in the source directories.', 'client-sync' );
					}
				} catch ( \Exception $e ) {
					$feedback['error'] = __( 'An error occurred while scanning:', 'client-sync' ) . ' ' . $e->getMessage();
				}
				break;

			case 'fix_dimension_registry':
				$nonce = isset( $_POST['clisyc_testing_fix_registry_nonce'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_testing_fix_registry_nonce'] ) ) : '';
				if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_testing_fix_registry' ) ) {
					wp_die( 'Security check failed.' );
				}
				$registry = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
				// Force Practitioners to be a Resource
				if ( isset( $registry['dimensions'] ) && isset( $registry['dimensions']['clisyc_practitioner'] ) ) {
					$registry['dimensions']['clisyc_practitioner']['is_resource'] = true;
					update_option( Constants::OPTION_DIMENSION_REGISTRY, $registry );
					$feedback['message'] = __( 'Registry updated: Practitioners are now explicitly a Resource.', 'client-sync' );
				} else {
					$feedback['error'] = __( 'Practitioner dimension not found.', 'client-sync' );
				}
				break;
		}
		
		// Set feedback transient based on redirect destination
		if ( strpos( $redirect_url, 'tab=automation' ) !== false ) {
			set_transient( 'clisyc_automation_feedback', $feedback, 30 );
		} else {
			set_transient( 'clisyc_testing_feedback', $feedback, 30 );
		}
		wp_safe_redirect( esc_url_raw( $redirect_url ) );
		exit;
	}

	public function handle_generate_slots_submission() {
		check_admin_referer( 'clisyc_save_time_slots', 'clisyc_time_slot_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'client-sync' ) );
		}

		$start_date_str = isset( $_POST['start_date'] ) ? sanitize_text_field( wp_unslash( $_POST['start_date'] ) ) : '';
		$end_date_str   = isset( $_POST['end_date'] ) ? sanitize_text_field( wp_unslash( $_POST['end_date'] ) ) : '';
		$errors         = [];
		$start_date     = null;
		$end_date       = null;
		$site_timezone  = wp_timezone();

		try {
			if ( ! $start_date_str || ! $end_date_str ) {
				throw new \Exception( __( 'Start and end dates are required.', 'client-sync' ) );
			}
			$start_date = new \DateTime( $start_date_str, $site_timezone );
			$end_date   = new \DateTime( $end_date_str, $site_timezone );
			if ( $end_date < $start_date ) {
				throw new \Exception( __( 'End date cannot be before start date.', 'client-sync' ) );
			}
		} catch ( \Exception $e ) {
			$errors[] = $e->getMessage();
		}

		if ( empty( $errors ) ) {
			$cron_manager = new Cron( $this->db_manager );
			$result       = $cron_manager->run_slot_generation_for_date_range( $start_date, $end_date );

			if ( is_wp_error( $result ) ) {
				$errors[] = $result->get_error_message();
			} else {
				$inserted_count = $result['inserted'] ?? 0;
				if ( $inserted_count > 0 ) {
					/* translators: %d: The number of slots generated or updated. */
					set_transient( 'clisyc_manage_slots_feedback', [ 'message' => sprintf( _n( '%d slot generated/updated.', '%d slots generated/updated.', $inserted_count, 'client-sync' ), $inserted_count ) ], 30 );
				} else {
					set_transient( 'clisyc_manage_slots_feedback', [ 'message' => __( 'No new slots were generated. This could be due to conflicts with existing bookings, or no valid schedules were found for the selected date range.', 'client-sync' ) ], 30 );
				}
			}
		}

		if ( ! empty( $errors ) ) {
			set_transient( 'clisyc_manage_slots_feedback', [ 'error' => implode( '<br>', $errors ) ], 30 );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=clisyc-calendars&tab=time-slots' ) );
		exit;
	}


	public function handle_remove_past_slots() {
		check_admin_referer( 'clisyc_remove_past_slots_action', 'clisyc_remove_past_nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'client-sync' ) );
		}
		$deleted_count = $this->db_manager->delete_past_available_slots();
		if ( is_wp_error( $deleted_count ) ) {
			set_transient( 'clisyc_manage_slots_feedback', [ 'error' => __( 'Error removing past slots: ', 'client-sync' ) . $deleted_count->get_error_message() ], 30 );
		} elseif ( $deleted_count > 0 ) {
			/* translators: %d: The number of past available slots removed. */
			set_transient( 'clisyc_manage_slots_feedback', [ 'message' => sprintf( _n( '%d past available slot removed.', '%d past available slots removed.', $deleted_count, 'client-sync' ), $deleted_count ) ], 30 );
		} else {
			set_transient( 'clisyc_manage_slots_feedback', [ 'message' => __( 'No past available slots found to remove.', 'client-sync' ) ], 30 );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=clisyc-available-slots-list' ) );
		exit;
	}

	public function handle_list_view_actions() {
		$action = $this->current_action();
		$page   = isset( $_REQUEST['page'] ) ? sanitize_key( wp_unslash( $_REQUEST['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( 'clisyc-available-slots-list' !== $page || ! $action ) {
			return;
		}

		if ( 'clisyc_single_delete' === $action ) {
			$slot_id = isset( $_GET['slot_id'] ) ? absint( $_GET['slot_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( $slot_id > 0 ) {
				check_admin_referer( 'clisyc_delete_slot_' . $slot_id );
				if ( current_user_can( 'manage_options' ) ) {
					global $wpdb;
					$slots_table = $this->db_manager->get_slots_table_name();
					$dims_table  = $this->db_manager->get_dimensions_table_name();
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names from internal class method.
					$wpdb->delete( $dims_table, [ 'slot_id' => $slot_id ], [ '%d' ] );
					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names from internal class method.
					$deleted = $wpdb->delete( $slots_table, [ 'slot_id' => $slot_id ], [ '%d' ] );
					if ( $deleted ) {
						$this->db_manager->clear_all_slot_cache();
						set_transient( 'clisyc_manage_slots_feedback', [ 'message' => __( 'Time slot deleted successfully.', 'client-sync' ) ], 30 );
					} else {
						set_transient( 'clisyc_manage_slots_feedback', [ 'error' => __( 'Could not delete the specified time slot from the database.', 'client-sync' ) ], 30 );
					}
				}
			}
		}

		if ( 'bulk-delete' === $action ) {
			check_admin_referer( 'bulk-availableslots' );
			if ( current_user_can( 'manage_options' ) ) {
				$selected_slots = isset( $_POST['selected_slots'] ) && is_array( $_POST['selected_slots'] ) ? array_map( 'absint', wp_unslash( $_POST['selected_slots'] ) ) : [];
				$ids_to_delete  = $selected_slots;
				if ( ! empty( $ids_to_delete ) ) {
					global $wpdb;
					$how_many      = count( $ids_to_delete );
					$placeholders  = implode( ',', array_fill( 0, $how_many, '%d' ) );
					$slots_table   = $this->db_manager->get_slots_table_name();
					$dims_table    = $this->db_manager->get_dimensions_table_name();

					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- $placeholders is dynamically generated and safe.
					$sql_delete_dims = "DELETE FROM {$dims_table} WHERE slot_id IN ($placeholders)";
					// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Query prepared above; table name from internal method is safe.
					$wpdb->query( $wpdb->prepare( $sql_delete_dims, $ids_to_delete ) );

					// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- $placeholders is dynamically generated and safe.
					$sql_delete_slots = "DELETE FROM {$slots_table} WHERE slot_id IN ($placeholders)";
					// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Query prepared above; table name from internal method is safe.
					$deleted_count = $wpdb->query( $wpdb->prepare( $sql_delete_slots, $ids_to_delete ) );

					if ( $deleted_count > 0 ) {
						$this->db_manager->clear_all_slot_cache();
					}
					/* translators: %d: The number of time slots deleted. */
					set_transient( 'clisyc_manage_slots_feedback', [ 'message' => sprintf( _n( '%d time slot deleted.', '%d time slots deleted.', (int) $deleted_count, 'client-sync' ), (int) $deleted_count ) ], 30 );
				}
			}
		}

		$referer_url = wp_get_referer();
		if ( false === $referer_url ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$referer_page = isset( $_REQUEST['page'] ) ? sanitize_key( wp_unslash( $_REQUEST['page'] ) ) : 'clisyc-dashboard';
			$referer_url  = admin_url( 'admin.php?page=' . $referer_page );
		}
		if ( ! is_string( $referer_url ) ) {
			$referer_url = admin_url( 'admin.php?page=clisyc-dashboard' );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$redirect_url = remove_query_arg( [ 'action', 'slot_id', '_wpnonce', 'action2', 'selected_slots', '_wp_http_referer' ], $referer_url );
		if ( $redirect_url ) {
			wp_safe_redirect( $redirect_url );
			exit;
		}
	}

	private function current_action() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_REQUEST['filter_action'] ) && ! empty( $_REQUEST['filter_action'] ) ) {
			return false;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_REQUEST['action'] ) && -1 != $_REQUEST['action'] ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return sanitize_key( wp_unslash( $_REQUEST['action'] ) );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_REQUEST['action2'] ) && -1 != $_REQUEST['action2'] ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return sanitize_key( wp_unslash( $_REQUEST['action2'] ) );
		}
		return false;
	}

	private function _sanitize_conditional_logic( string $json_data ): ?array {
		$data = json_decode( $json_data, true );
		if ( ! is_array( $data ) || empty( $data['enabled'] ) || empty( $data['rules'] ) || ! is_array( $data['rules'] ) ) {
			return null;
		}
		$sanitized_logic           = [
			'enabled'   => true,
			'condition' => ( isset( $data['condition'] ) && 'any' === $data['condition'] ) ? 'any' : 'all',
			'rules'     => [],
		];
		$allowed_controller_fields = [ 'service_id' ];
		foreach ( $data['rules'] as $rule ) {
			if ( ! is_array( $rule ) || empty( $rule['field'] ) || empty( $rule['operator'] ) || ! isset( $rule['value'] ) ) {
				continue;
			}
			$field_key = sanitize_key( $rule['field'] );
			if ( ! in_array( $field_key, $allowed_controller_fields, true ) ) {
				continue;
			}
			$sanitized_logic['rules'][] = [
				'field'    => $field_key,
				'operator' => ( 'is_not' === $rule['operator'] ) ? 'is_not' : 'is',
				'value'    => sanitize_text_field( $rule['value'] ),
			];
		}
		if ( empty( $sanitized_logic['rules'] ) ) {
			return null;
		}
		return $sanitized_logic;
	}

	/**
	 * Handles the export of all plugin settings to a JSON file.
	 */
	public function handle_export_settings() {
		$nonce       = isset( $_POST['clisyc_export_settings_nonce'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_export_settings_nonce'] ) ) : '';
		$export_note = isset( $_POST['clisyc_export_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['clisyc_export_note'] ) ) : '';

		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_export_settings_action' ) ) {
			wp_die( 'Security check failed.' );
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Permission denied.' );
		}

		// =========================================================================
		// HIPAA COMPLIANCE: Block settings export in HIPAA mode
		// Settings export may contain email addresses and other sensitive config.
		// =========================================================================
		if ( $this->is_hipaa_mode_active() ) {
			wp_die(
				esc_html__( 'Settings export is disabled when HIPAA mode is active to prevent accidental PHI disclosure. Settings may contain email addresses and sensitive configuration data. Please disable HIPAA mode temporarily if you need to export settings for migration purposes.', 'client-sync' ),
				esc_html__( 'Export Blocked - HIPAA Mode Active', 'client-sync' ),
				[ 'response' => 403, 'back_link' => true ]
			);
		}

		global $wpdb;
		$export_data = [
			'template_meta' => [],
			'options'       => [],
			'cpts'          => [],
			'relationships' => [],
		];

		if ( ! empty( $export_note ) ) {
			$export_data['template_meta']['title']       = __( 'Custom Export', 'client-sync' ) . ' - ' . wp_date( 'Y-m-d' );
			$export_data['template_meta']['description'] = $export_note;
		}

		$options_to_export = [
			Constants::OPTION_CALENDAR_START_TIME,
			'clisyc_calendar_end_time',
			'clisyc_calendar_slot_duration',
			'clisyc_standard_schedule_calendar_start_time',
			'clisyc_standard_schedule_calendar_end_time',
			'clisyc_frontend_calendar_style',
			'clisyc_login_page_url',
			Constants::OPTION_CUSTOM_FIELDS,
			Constants::OPTION_CUSTOM_FIELDS_ORDER,
			Constants::OPTION_APPOINTMENT_FIELDS,
			'clisyc_appointment_custom_fields_order',
			Constants::OPTION_NOTIFICATION_SETTINGS,
			Constants::OPTION_EMAIL_FROM_NAME,
			Constants::OPTION_EMAIL_FROM_ADDRESS,
			Constants::OPTION_NOTIFICATION_ADMINS,
			'clisyc_reminder_settings',
			'clisyc_auto_generate_enabled',
			'clisyc_auto_generate_lookahead',
			'clisyc_wc_integration_enabled',
			'clisyc_wc_appointment_product_id',
			'clisyc_min_booking_notice_minutes',
			'clisyc_global_buffer_before',
			'clisyc_global_buffer_after',
			'clisyc_calendar_show_overview_availability',
			'clisyc_calendar_smart_start_date',
			'clisyc_mysql_convert_tz_override',
			Constants::OPTION_CALENDAR_COLOR_SETTINGS,
			Constants::OPTION_ENABLE_SELF_SERVICE,
			Constants::OPTION_CANCEL_CUTOFF_VALUE,
			Constants::OPTION_CANCEL_CUTOFF_UNIT,
			Constants::OPTION_CANCEL_REFUND_POLICY,
			'clisyc_appointment_view_page_id',
			'clisyc_booking_page_id',
			'clisyc_booking_success_page_id',
			Constants::OPTION_ANTISPAM_HONEYPOT,
			Constants::OPTION_ANTISPAM_TIME_CHECK,
			'clisyc_recaptcha_v3_settings',
			Constants::OPTION_DIMENSION_REGISTRY,
			Constants::OPTION_CUSTOM_DIMENSION_TYPES,
			Constants::OPTION_GRAPH_VISUAL_STATE,
		];

		foreach ( $options_to_export as $option_name ) {
			$export_data['options'][ $option_name ] = get_option( $option_name );
		}

		$registry       = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
		$cpts_to_export = array_keys( $registry['dimensions'] ?? [] );

		foreach ( $cpts_to_export as $cpt_slug ) {
			if ( empty( $registry['dimensions'][ $cpt_slug ]['enabled'] ) ) {
				continue;
			}
			$export_data['cpts'][ $cpt_slug ] = [];
			$posts                          = get_posts(
				[
					'post_type'      => $cpt_slug,
					'posts_per_page' => -1,
					'post_status'    => 'publish',
				]
			);
			foreach ( $posts as $post ) {
				$export_data['cpts'][ $cpt_slug ][] = [
					'original_id'  => $post->ID,
					'post_name'    => $post->post_name,
					'post_title'   => $post->post_title,
					'post_content' => $post->post_content,
					'post_meta'    => get_post_meta( $post->ID ),
				];
			}
		}

		$rels_table = $this->db_manager->get_relationships_table_name();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is safely retrieved.
		$query = "SELECT * FROM {$rels_table} WHERE parent_object_id < child_object_id";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name from internal method is safe.
		$relationships_raw = $wpdb->get_results( $query );

		$post_ids_to_lookup = [];
		foreach ( $relationships_raw as $rel ) {
			$post_ids_to_lookup[] = $rel->parent_object_id;
			$post_ids_to_lookup[] = $rel->child_object_id;
		}

		if ( ! empty( $post_ids_to_lookup ) ) {
			$unique_ids = array_unique( array_map( 'absint', $post_ids_to_lookup ) );
			if ( ! empty( $unique_ids ) ) {
				$placeholders     = implode( ',', array_fill( 0, count( $unique_ids ), '%d' ) );
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Placeholders are dynamically generated and safe.
				$query            = "SELECT ID, post_name FROM {$wpdb->posts} WHERE ID IN ($placeholders)";
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Query prepared below; table name is safe.
				$post_slugs_by_id = $wpdb->get_results( $wpdb->prepare( $query, ...$unique_ids ), OBJECT_K );
				foreach ( $relationships_raw as $rel ) {
					$parent_slug = $post_slugs_by_id[ $rel->parent_object_id ]->post_name ?? null;
					$child_slug  = $post_slugs_by_id[ $rel->child_object_id ]->post_name ?? null;
					if ( $parent_slug && $child_slug ) {
						$export_data['relationships'][] = [
							'parent_slug' => $parent_slug,
							'parent_type' => $rel->parent_object_type,
							'child_slug'  => $child_slug,
							'child_type'  => $rel->child_object_type,
						];
					}
				}
			}
		}

		$filename = 'clisyc-settings-export-' . wp_date( 'Y-m-d' ) . '.json';
		header( 'Content-Disposition: attachment; filename=' . $filename );
		header( 'Content-Type: application/json' );
		echo wp_json_encode( [ $export_data ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		exit;
	}

	public function handle_import_settings() {
		$nonce                = isset( $_POST['clisyc_import_settings_nonce'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_import_settings_nonce'] ) ) : '';
		$import_template_slug = isset( $_POST['import_template_slug'] ) ? sanitize_key( wp_unslash( $_POST['import_template_slug'] ) ) : '';

		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_import_settings_action' ) ) {
			wp_die( 'Security check failed.' );
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Permission denied.' );
		}

		$import_data = null;
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( isset( $_FILES['clisyc_import_file']['error'] ) && UPLOAD_ERR_OK === $_FILES['clisyc_import_file']['error'] && ! empty( $_FILES['clisyc_import_file']['tmp_name'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$file_path = $_FILES['clisyc_import_file']['tmp_name'];
			if ( 'application/json' === mime_content_type( $file_path ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				$json_data   = file_get_contents( $file_path );
				$import_data = json_decode( $json_data, true );
			}
		} elseif ( ! empty( $import_template_slug ) ) {
			$template_file_path = clisyc_PLUGIN_DIR . 'setup-templates/' . $import_template_slug . '.json';
			if ( file_exists( $template_file_path ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				$json_data    = file_get_contents( $template_file_path );
				$decoded_data = json_decode( $json_data, true );
				$import_data  = $decoded_data[0] ?? null;
			}
		}

		if ( is_array( $import_data ) ) {
			$importer = new Importer();
			$result   = $importer->install_from_data( $import_data );

			if ( is_wp_error( $result ) ) {
				set_transient( 'clisyc_import_export_feedback', [ 'error' => __( 'Import failed: ', 'client-sync' ) . $result->get_error_message() ], 30 );
			} else {
				$feedback_message = __( 'Configuration imported successfully.', 'client-sync' );
				if ( ! empty( $import_data['template_meta']['title'] ) ) {
					/* translators: %s: The title of the imported template. */
					$feedback_message .= '<br/>' . sprintf( '<strong>%s:</strong> %s', __( 'Template', 'client-sync' ), esc_html( $import_data['template_meta']['title'] ) );
				}
				set_transient( 'clisyc_import_export_feedback', [ 'message' => $feedback_message ], 30 );
			}
		} else {
			set_transient( 'clisyc_import_export_feedback', [ 'error' => __( 'Import failed. The provided file was invalid or could not be read.', 'client-sync' ) ], 30 );
		}

		$redirect_url = wp_get_referer();
		if ( ! $redirect_url ) {
			$redirect_url = admin_url( 'admin.php?page=clisyc-settings&tab=import_export' );
		}
		wp_safe_redirect( $redirect_url );
		exit;
	}


	/**
	 * Handles the export of the plugin's custom database tables to a JSON file for debugging.
	 */
	public function handle_export_database_data() {
		$nonce = isset( $_POST['clisyc_export_db_nonce'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_export_db_nonce'] ) ) : '';

		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_export_db_action' ) ) {
			wp_die( 'Security check failed: Nonce is invalid.' );
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Permission denied.' );
		}

		// =========================================================================
		// HIPAA COMPLIANCE: Block database export in HIPAA mode
		// Database export includes encrypted PHI that should not leave the system.
		// =========================================================================
		if ( $this->is_hipaa_mode_active() ) {
			wp_die(
				esc_html__( 'Database export is disabled when HIPAA mode is active to prevent accidental PHI disclosure. This export would include encrypted appointment data and potentially identifiable information. Please use the HIPAA-compliant migration tools or disable HIPAA mode temporarily for data migration purposes.', 'client-sync' ),
				esc_html__( 'Export Blocked - HIPAA Mode Active', 'client-sync' ),
				[ 'response' => 403, 'back_link' => true ]
			);
		}

		global $wpdb;
		$db_manager     = new \DependentMedia\ClientSync\Core\Database_Manager();
		$slots_table    = $db_manager->get_slots_table_name();
		$dims_table     = $db_manager->get_dimensions_table_name();
		$rels_table     = $db_manager->get_relationships_table_name();
		$nodes_table    = $wpdb->prefix . 'clisyc_graph_nodes';
		$bookings_table = $wpdb->prefix . 'clisyc_bookings';

		// --- START: MODIFIED LOGIC ---

		// 1. Export all relevant plugin options
		$options_to_export = [
			Constants::OPTION_DIMENSION_REGISTRY,
			Constants::OPTION_CUSTOM_DIMENSION_TYPES,
			Constants::OPTION_DIMENSION_FIELDS,
			Constants::OPTION_CUSTOM_FIELDS,
			Constants::OPTION_CUSTOM_FIELDS_ORDER,
			Constants::OPTION_APPOINTMENT_FIELDS,
			'clisyc_appointment_custom_fields_order',
			Constants::OPTION_GRAPH_VISUAL_STATE,
			Constants::OPTION_CALENDAR_START_TIME,
			'clisyc_calendar_end_time',
			'clisyc_calendar_slot_duration',
			'clisyc_standard_schedule_calendar_start_time',
			'clisyc_standard_schedule_calendar_end_time',
			'clisyc_frontend_calendar_style',
			'clisyc_auto_generate_enabled',
			'clisyc_auto_generate_lookahead',
			'clisyc_wc_integration_enabled',
			'clisyc_min_booking_notice_minutes',
			'clisyc_global_buffer_before',
			'clisyc_global_buffer_after',
			Constants::OPTION_ENABLE_SELF_SERVICE,
			Constants::OPTION_CANCEL_CUTOFF_VALUE,
			Constants::OPTION_CANCEL_CUTOFF_UNIT,
		];
		$exported_options  = [];
		foreach ( $options_to_export as $option_name ) {
			$exported_options[ $option_name ] = get_option( $option_name );
		}

		// 1. Find the primary dimension slug
		$registry         = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
		$primary_dim_slug = null;
		if ( ! empty( $registry['dimensions'] ) ) {
			foreach ( $registry['dimensions'] as $slug => $settings ) {
				if ( ! empty( $settings['primary'] ) ) {
					$primary_dim_slug = $slug;
					break;
				}
			}
		}

		// 2. Build the new SQL query with a JOIN to postmeta
		$sql_params = [];
		$sql_join_capacity = '';

		if ( $primary_dim_slug ) {
			$sql_join_capacity = $wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names from internal class property.
				"LEFT JOIN {$wpdb->postmeta} pm ON (d.dimension_value = pm.post_id AND pm.meta_key = Constants::META_CAPACITY AND d.dimension_key = %s)",
				$primary_dim_slug
			);
		}

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		// MODIFIED: Select s.* to include the new 'booking_count' column for debugging
		$slots_query = "
			SELECT s.*,
			GROUP_CONCAT(CONCAT(d.dimension_key, ':::', d.dimension_value) SEPARATOR '|||') AS dimensions_concat,
			" . ( $primary_dim_slug ? 'pm.meta_value as capacity' : '1 as capacity' ) . "
			FROM {$slots_table} s
			LEFT JOIN {$dims_table} d ON s.slot_id = d.slot_id
			{$sql_join_capacity}
			GROUP BY s.slot_id
			ORDER BY s.start_time ASC
		";
		// phpcs:enable

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Query uses interpolated safe table names from internal methods.
		$slots_results = $wpdb->get_results( $slots_query, ARRAY_A );

		$slots_export_data = [];
		if ( ! empty( $slots_results ) ) {
			foreach ( $slots_results as $row ) {
				$dimensions_array = [];
				if ( ! empty( $row['dimensions_concat'] ) ) {
					$pairs = explode( '|||', $row['dimensions_concat'] );
					foreach ( $pairs as $pair ) {
						$parts = explode( ':::', $pair, 2 );
						if ( count( $parts ) === 2 ) {
							list( $key, $value ) = $parts;
							$dimensions_array[ $key ] = $value;
						}
					}
				}
				$slots_export_data[] = [
					'slot_id'        => (int) $row['slot_id'],
					'start_time_utc' => $row['start_time'],
					'end_time_utc'   => $row['end_time'],
					'is_block'       => (int) $row['is_block'],
					'booking_count'  => (int) ( $row['booking_count'] ?? 0 ), // Export the optimization column
					'capacity'       => (int) ( $row['capacity'] ?? 1 ),
					'dimensions'     => $dimensions_array,
				];
			}
		}

		// --- END: MODIFIED LOGIC ---

		// The rest of the function remains the same...
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name from internal method is safe.
		$relationships_data = $wpdb->get_results( "SELECT * FROM {$rels_table} ORDER BY parent_object_type, parent_object_id", ARRAY_A );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name uses $wpdb->prefix which is safe.
		$graph_nodes_data = $wpdb->get_results( "SELECT * FROM {$nodes_table} ORDER BY node_type, cpt_slug, wp_post_id", ARRAY_A );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name uses $wpdb->prefix which is safe.
		$bookings_data = $wpdb->get_results( "SELECT * FROM {$bookings_table} ORDER BY booking_time_utc DESC", ARRAY_A );

		// --- START: ADDED DIMENSION POST META EXPORT ---
		$dimension_posts_data = [];
		if ( ! empty( $registry['dimensions'] ) ) {
			foreach ( $registry['dimensions'] as $slug => $settings ) {
				if ( empty( $settings['enabled'] ) ) {
					continue;
				}

				$posts = get_posts([
					'post_type'      => $slug,
					'posts_per_page' => -1,
					'post_status'    => 'any', // Get drafts/trash too for completeness
				]);

				foreach ( $posts as $post ) {
					$all_meta = get_post_meta( $post->ID );
					$clisyc_meta = [];

					// Filter to only include plugin-specific meta to keep file size reasonable
					foreach ( $all_meta as $key => $values ) {
						// Export all keys starting with _clisyc_ (schedules, capacity, etc.)
						// Also export standard keys if useful
						if ( strpos( $key, '_clisyc_' ) === 0 ) {
							$clisyc_meta[ $key ] = maybe_unserialize( $values[0] );
						}
					}

					$dimension_posts_data[ $slug ][] = [
						'ID'          => $post->ID,
						'post_title'  => $post->post_title,
						'post_status' => $post->post_status,
						'meta_data'   => $clisyc_meta
					];
				}
			}
		}
		// --- END: ADDED DIMENSION POST META EXPORT ---

		$final_export_data = [
			'plugin_options'        => $exported_options,
			'slots_with_dimensions' => $slots_export_data,
			'relationships'         => $relationships_data,
			'graph_nodes'           => $graph_nodes_data,
			'bookings'              => $bookings_data,
			// Added new section
			'dimension_source_data' => $dimension_posts_data, 
		];

		$filename = 'clisyc-db-export-' . wp_date( 'Y-m-d' ) . '.json';
		header( 'Content-Disposition: attachment; filename=' . $filename );
		header( 'Content-Type: application/json' );
		echo wp_json_encode( $final_export_data, JSON_PRETTY_PRINT );
		exit;
	}


	public function handle_add_or_update_dimension_type() {
		$nonce     = isset( $_POST['clisyc_add_dimension_nonce'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_add_dimension_nonce'] ) ) : '';
		$action    = isset( $_POST['clisyc_dimension_action'] ) ? sanitize_key( wp_unslash( $_POST['clisyc_dimension_action'] ) ) : 'add';
		$plural    = isset( $_POST['dim_plural_name'] ) ? sanitize_text_field( wp_unslash( $_POST['dim_plural_name'] ) ) : '';
		$singular  = isset( $_POST['dim_singular_name'] ) ? sanitize_text_field( wp_unslash( $_POST['dim_singular_name'] ) ) : '';
		$icon      = isset( $_POST['dim_icon'] ) ? sanitize_text_field( wp_unslash( $_POST['dim_icon'] ) ) : 'dashicons-admin-generic';
		$public    = ! empty( $_POST['dim_public'] );
		$slug      = ( 'update' === $action )
			? ( isset( $_POST['edit_dimension_slug'] ) ? sanitize_key( wp_unslash( $_POST['edit_dimension_slug'] ) ) : '' )
			: ( isset( $_POST['dim_slug'] ) ? sanitize_key( wp_unslash( $_POST['dim_slug'] ) ) : '' );

		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_add_dimension_type_action' ) ) {
			wp_die( 'Security check failed.' );
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Permission denied.' );
		}

		$custom_types       = get_option( Constants::OPTION_CUSTOM_DIMENSION_TYPES, [] );
		$is_first_dimension = empty( $custom_types );
		$is_public_flag     = false; // Default to false

		if ( 'add' === $action ) {
			// For any new dimension, set it to be Public by default.
			$is_public_flag = true;
		} elseif ( 'update' === $action && isset( $custom_types[ $slug ] ) ) {
			// When updating, preserve the existing 'public' status.
			$is_public_flag = ! empty( $custom_types[ $slug ]['public'] );
		}

		$result = Dimension_CPT_Manager::save_custom_dimension( $singular, $plural, $slug, $icon, $is_public_flag );

		if ( is_wp_error( $result ) ) {
			set_transient( 'clisyc_admin_feedback', [ 'error' => $result->get_error_message() ], 30 );
			wp_safe_redirect( admin_url( 'admin.php?page=clisyc-dimensions&tab=setup' ) );
			exit;
		}

		if ( 'add' === $action ) {
			$prefixed_slug = 'clisyc_' . str_replace( [ 'cs_', 'clisyc_' ], '', $slug );
			$registry      = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] ); // Still need this for updating
			// The is_first_dimension check is already performed above, we can reuse it.

			if ( ! isset( $registry['dimensions'] ) ) {
				$registry['dimensions'] = [];
			}

			// If this is the very first dimension being enabled, apply smart defaults.
			if ( $is_first_dimension ) {
				$registry['dimensions'][ $prefixed_slug ] = [
					'enabled'          => true,
					'primary'          => true,
					'frontend_visible' => true,
					'is_resource'      => false, // Corrected default
				];
			} else {
				$registry['dimensions'][ $prefixed_slug ] = [
					'enabled'          => true,
					'primary'          => false,
					'frontend_visible' => true, // This is the added line
					'is_resource'      => false, // Added for consistency
				];
			}
			update_option( Constants::OPTION_DIMENSION_REGISTRY, $registry );
		}

		set_transient( 'clisyc_admin_feedback', [ 'message' => __( 'Dimension type saved successfully.', 'client-sync' ) ], 30 );
		wp_safe_redirect( admin_url( 'admin.php?page=clisyc-dimensions&tab=setup' ) );
		exit;
	}

	public function handle_delete_dimension_type() {
		$slug  = isset( $_GET['dimension_slug'] ) ? sanitize_key( wp_unslash( $_GET['dimension_slug'] ) ) : '';
		$nonce = isset( $_GET['clisyc_delete_dimension_nonce'] ) ? sanitize_key( wp_unslash( $_GET['clisyc_delete_dimension_nonce'] ) ) : '';

		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'clisyc_delete_dimension_' . $slug ) ) {
			wp_die( 'Security check failed.' );
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Permission denied.' );
		}

		Dimension_CPT_Manager::delete_custom_dimension( $slug );

		wp_safe_redirect( admin_url( 'admin.php?page=clisyc-dimensions&tab=setup' ) );
		exit;
	}

	/**
	 * Checks if a user already has an appointment for a specific service on a given date.
	 *
	 * @param int   $user_id    The WordPress User ID.
	 * @param int   $service_id The service dimension ID.
	 * @param array $date_query The date query array for the check range.
	 * @return bool True if an appointment exists, false otherwise.
	 */
	private function has_user_appointment_for_service( $user_id, $service_id, $date_query ) {
		$args = [
			'post_type'      => Constants::POST_TYPE_APPOINTMENT,
			'post_status'    => [ 'publish', 'confirmed', 'clisyc_paid_on_day', 'wc-completed', 'wc-processing' ],
			'author'         => $user_id,
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'date_query'     => [ $date_query ],
			// THE FIX: Add the ignore comment with a performance justification.
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- This query is limited by user_id and a specific date range, ensuring performance even with a meta_query.
			'meta_query'     => [
				[
					'key'     => Constants::META_SLOT_DIMENSIONS,
					'value'   => '"clisyc_service";i:' . $service_id . ';',
					'compare' => 'LIKE',
				],
			],
		];

		$appointments = get_posts( $args );
		return ! empty( $appointments );
	}
}