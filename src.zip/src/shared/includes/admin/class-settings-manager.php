<?php
/**
 * File: src/shared/includes/admin/class-settings-manager.php
 * Manages all WordPress Settings API registration and callbacks.
 *
 * UPDATED: Split Style & Behavior into two separate menu items:
 * - Appearance (visual styling, colors, calendar display)
 * - Behavior (booking rules, links, self-service, spam protection)
 *
 * UPDATED (2026-01-01): Added Contact Page setting for "no availability" fallback.
 * UPDATED (2026-01-XX): Added HIPAA Compliance settings section.
 *
 * @package    ClientSync
 * @subpackage ClientSync/Admin
 */

namespace DependentMedia\ClientSync\Admin;

use DependentMedia\ClientSync\Utility\Sanitizer;
use DependentMedia\ClientSync\Constants;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Settings_Manager {

    /**
     * Default color palette for calendar styling.
     * Modern, accessible colors with good contrast ratios.
     *
     * @return array
     */
    public static function get_default_color_settings(): array {
        return [
            // Available slots - Emerald green (success/positive)
            'available_bg'      => '#d1fae5', // emerald-100
            'available_text'    => '#065f46', // emerald-800

            // Booked slots - Red (unavailable/negative)
            'booked_bg'         => '#fee2e2', // red-100
            'booked_text'       => '#991b1b', // red-800

            // Blocked slots - Gray (neutral/inactive)
            'blocked_bg'        => '#e5e7eb', // gray-200
            'blocked_text'      => '#374151', // gray-700

            // Accent colors - Blue (primary action)
            'accent_normal_bg'  => '#3b82f6', // blue-500
            'accent_normal_text'=> '#ffffff', // white
            'accent_hover_bg'   => '#2563eb', // blue-600
            'accent_hover_text' => '#ffffff', // white

            // Icon colors - Light gray background
            'icon_bg'           => '#f3f4f6', // gray-100
            'icon_text'         => '#4b5563', // gray-600

            // Text size scale (small, medium, large, x-large)
            'text_size'         => 'medium',
        ];
    }

    /**
     * Get merged color settings (saved values merged with defaults).
     *
     * @return array
     */
    public static function get_color_settings(): array {
        $defaults = self::get_default_color_settings();
        $saved = get_option( Constants::OPTION_CALENDAR_COLOR_SETTINGS, [] );

        // Merge saved values with defaults, using defaults for empty values
        $merged = [];
        foreach ( $defaults as $key => $default_value ) {
            $saved_value = $saved[ $key ] ?? '';
            $merged[ $key ] = ! empty( $saved_value ) ? $saved_value : $default_value;
        }

        return $merged;
    }
    
    public function register_hooks() {
        add_action( 'admin_init', [ $this, 'register_settings' ] );
    }

    public function register_settings() {
        if ( ! is_admin() ) {
            return;
        }
        
        $notification_group = 'clisyc_notification_settings_group';
        $notification_page  = 'clisyc-notifications-settings';

        // UPDATED: Split into two separate pages
        $appearance_group   = 'clisyc_appearance_settings_group';
        $appearance_page    = 'clisyc-appearance-settings';
        $behavior_group     = 'clisyc_behavior_settings_group';
        $behavior_page      = 'clisyc-behavior-settings';

        $automation_group   = 'clisyc_automation_settings_group';
        $automation_page    = 'clisyc-automation';
        $payment_group      = 'clisyc_payments_settings_group';
        $payment_page       = 'clisyc-payments';
        $integrations_group = 'clisyc_integrations_settings_group';
        $integrations_page  = 'clisyc-integrations';

        // --- 1. NOTIFICATION SETTINGS ---
        register_setting( $notification_group, Constants::OPTION_NOTIFICATION_SETTINGS, [ $this, 'sanitize_notification_settings' ] );
        register_setting( $notification_group, Constants::OPTION_EMAIL_FROM_NAME, 'sanitize_text_field' );
        register_setting( $notification_group, Constants::OPTION_EMAIL_FROM_ADDRESS, 'sanitize_email' );
        register_setting( $notification_group, Constants::OPTION_NOTIFICATION_ADMINS, [ $this, 'sanitize_admin_recipients' ] );
        register_setting( $notification_group, Constants::OPTION_REMINDER_SETTINGS, [ $this, 'sanitize_reminder_settings' ] );

        add_settings_section( 'clisyc_notification_general_section', __( 'General Email Settings', 'client-sync' ), null, $notification_page );
        add_settings_field( Constants::OPTION_EMAIL_FROM_NAME, __( 'Email "From" Name', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $notification_page, 'clisyc_notification_general_section', ['id' => Constants::OPTION_EMAIL_FROM_NAME, 'type' => 'text', 'default' => get_bloginfo( 'name' )] );
        add_settings_field( Constants::OPTION_EMAIL_FROM_ADDRESS, __( 'Email "From" Address', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $notification_page, 'clisyc_notification_general_section', ['id' => Constants::OPTION_EMAIL_FROM_ADDRESS, 'type' => 'email', 'default' => get_option( 'admin_email' )] );
        add_settings_field( Constants::OPTION_NOTIFICATION_ADMINS, __( 'Admin Notification Recipients', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $notification_page, 'clisyc_notification_general_section', ['id' => Constants::OPTION_NOTIFICATION_ADMINS, 'type' => 'textarea', 'default' => get_option( 'admin_email' ), 'desc' => __('Comma-separated email addresses.', 'client-sync')] );

        add_settings_section( 'clisyc_appointment_reminders_section', __( 'Appointment Reminder Settings', 'client-sync' ), [ $this, 'render_reminders_section_callback' ], $notification_page );
        add_settings_field( Constants::OPTION_REMINDER_SETTINGS . '[enabled]', __( 'Enable Reminders', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $notification_page, 'clisyc_appointment_reminders_section', ['id' => Constants::OPTION_REMINDER_SETTINGS . '[enabled]', 'type' => 'checkbox', 'option_name' => Constants::OPTION_REMINDER_SETTINGS, 'path' => ['enabled'], 'desc' => __('Send automatic email reminders to clients before their appointments.', 'client-sync')] );
        add_settings_field( Constants::OPTION_REMINDER_SETTINGS . '[lead_time_value]', __( 'Send Reminder Before', 'client-sync' ), [ $this, 'render_reminder_lead_time_field' ], $notification_page, 'clisyc_appointment_reminders_section' );
        
        $notifications_class = new \DependentMedia\ClientSync\Core\Notifications();
        $event_types = $notifications_class->get_event_types();
        foreach ( $event_types as $event_key => $event_data ) {
            add_settings_section( 'clisyc_notification_section_' . $event_key, $event_data['label'], [ $this, 'render_notification_section_header' ], $notification_page, ['placeholders' => $event_data['placeholders']] );
            foreach ( $event_data['recipient_types'] as $recipient_type ) {
                $base_id = "clisyc_notification_settings[{$event_key}][{$recipient_type}";
                $title_prefix = ('admin' === $recipient_type) ? __('Admin', 'client-sync') : __('Client', 'client-sync');
                /* translators: %s: Recipient type (e.g. "Admin" or "Client"). */
                add_settings_field( $base_id . '_enabled]', sprintf( esc_html__( '%s Email Notification', 'client-sync' ), $title_prefix ), [ $this, 'render_settings_field_callback' ], $notification_page, 'clisyc_notification_section_' . $event_key, ['id' => $base_id . '_enabled]', 'type' => 'checkbox', 'option_name' => Constants::OPTION_NOTIFICATION_SETTINGS, 'path' => [$event_key, $recipient_type.'_enabled']] );
                /* translators: %s: Recipient type (e.g. "Admin" or "Client"). */
                add_settings_field( $base_id . '_subject]', sprintf( esc_html__( '%s Email Subject', 'client-sync' ), $title_prefix ), [ $this, 'render_settings_field_callback' ], $notification_page, 'clisyc_notification_section_' . $event_key, ['id' => $base_id . '_subject]', 'type' => 'text', 'option_name' => Constants::OPTION_NOTIFICATION_SETTINGS, 'path' => [$event_key, $recipient_type.'_subject'], 'class' => 'regular-text'] );
                /* translators: %s: Recipient type (e.g. "Admin" or "Client"). */
                add_settings_field( $base_id . '_body]', sprintf( esc_html__( '%s Email Body', 'client-sync' ), $title_prefix ), [ $this, 'render_settings_field_callback' ], $notification_page, 'clisyc_notification_section_' . $event_key, ['id' => $base_id . '_body]', 'type' => 'wp_editor', 'option_name' => Constants::OPTION_NOTIFICATION_SETTINGS, 'path' => [$event_key, $recipient_type.'_body']] );
            }

            // Add SMS fields for client-facing notifications if Pro is active
            if ( in_array('client', $event_data['recipient_types'], true) && function_exists('clisyc_pro_is_license_active') && clisyc_pro_is_license_active() ) {
                $sms_base_id = "clisyc_notification_settings[{$event_key}][sms";
                add_settings_field( $sms_base_id . '_enabled]', __('Client SMS Notification', 'client-sync'), [$this, 'render_settings_field_callback'], $notification_page, 'clisyc_notification_section_' . $event_key, ['id' => $sms_base_id . '_enabled]', 'type' => 'checkbox', 'option_name' => Constants::OPTION_NOTIFICATION_SETTINGS, 'path' => [$event_key, 'sms_enabled']]);
                add_settings_field( $sms_base_id . '_body]', __('Client SMS Body', 'client-sync'), [$this, 'render_settings_field_callback'], $notification_page, 'clisyc_notification_section_' . $event_key, ['id' => $sms_base_id . '_body]', 'type' => 'textarea', 'option_name' => Constants::OPTION_NOTIFICATION_SETTINGS, 'path' => [$event_key, 'sms_body'], 'desc' => __('Max 160 characters recommended for single SMS.', 'client-sync')]);
            }
        }

        // --- 2. APPEARANCE SETTINGS ---
        register_setting( $appearance_group, Constants::OPTION_CALENDAR_START_TIME, 'sanitize_text_field' );
        register_setting( $appearance_group, Constants::OPTION_CALENDAR_END_TIME, 'sanitize_text_field' );
        register_setting( $appearance_group, Constants::OPTION_CALENDAR_ENABLED_VIEWS, [ $this, 'sanitize_enabled_views_setting' ] );
        register_setting( $appearance_group, Constants::OPTION_FRONTEND_CALENDAR_STYLE, [ $this, 'sanitize_frontend_calendar_style' ] );
        register_setting( $appearance_group, Constants::OPTION_CALENDAR_COLOR_SETTINGS, [ $this, 'sanitize_color_settings' ] );
        register_setting( $appearance_group, Constants::OPTION_CALENDAR_SLOT_HEIGHT, [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '80' ] );

        // --- Appearance Section: Calendar Display ---
        add_settings_section( 'clisyc_appearance_calendar_display_section', __( 'Calendar Display', 'client-sync' ), [ $this, 'render_calendar_display_section_header' ], $appearance_page );
        add_settings_field( Constants::OPTION_CALENDAR_START_TIME, __( 'Calendar Start Time', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $appearance_page, 'clisyc_appearance_calendar_display_section', ['id' => Constants::OPTION_CALENDAR_START_TIME, 'type' => 'time', 'default' => '08:00'] );
        add_settings_field( Constants::OPTION_CALENDAR_END_TIME, __( 'Calendar End Time', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $appearance_page, 'clisyc_appearance_calendar_display_section', ['id' => Constants::OPTION_CALENDAR_END_TIME, 'type' => 'time', 'default' => '18:00'] );
        add_settings_field( 'clisyc_calendar_visibility_check', __( 'Visibility Check', 'client-sync' ), [ $this, 'render_visibility_check_button' ], $appearance_page, 'clisyc_appearance_calendar_display_section' );
        add_settings_field( Constants::OPTION_CALENDAR_ENABLED_VIEWS, __( 'Enabled Calendar Views', 'client-sync' ), [ $this, 'render_calendar_views_field' ], $appearance_page, 'clisyc_appearance_calendar_display_section' );
        add_settings_field( Constants::OPTION_FRONTEND_CALENDAR_STYLE, __( 'Default Initial View', 'client-sync' ), [ $this, 'render_initial_view_field' ], $appearance_page, 'clisyc_appearance_calendar_display_section' );
        add_settings_field(
            Constants::OPTION_CALENDAR_SLOT_HEIGHT,
            __( 'Calendar Slot Height', 'client-sync' ),
            [ $this, 'render_slot_height_field' ],
            $appearance_page,
            'clisyc_appearance_calendar_display_section'
        );

        // --- Appearance Section: Calendar Event Styling (Colors) ---
        add_settings_section( 'clisyc_appearance_colors_section', __( 'Calendar Event Colors', 'client-sync' ), [ $this, 'render_colors_section_header' ], $appearance_page );

        // Slot colors
        $slot_color_fields = [
            'available_bg'   => __( 'Available Slot Background', 'client-sync' ),
            'available_text' => __( 'Available Slot Text', 'client-sync' ),
            'booked_bg'      => __( 'Booked Slot Background', 'client-sync' ),
            'booked_text'    => __( 'Booked Slot Text', 'client-sync' ),
            'blocked_bg'     => __( 'Blocked Slot Background', 'client-sync' ),
            'blocked_text'   => __( 'Blocked Slot Text', 'client-sync' ),
        ];
        foreach ( $slot_color_fields as $key => $label ) {
            add_settings_field( 'clisyc_calendar_color_settings[' . $key . ']', $label, [ $this, 'render_color_picker_field' ], $appearance_page, 'clisyc_appearance_colors_section', [ 'id' => 'clisyc_calendar_color_settings[' . $key . ']', 'option_name' => Constants::OPTION_CALENDAR_COLOR_SETTINGS, 'path' => [ $key ], ] );
        }

        // --- Appearance Section: UI Accent Colors ---
        add_settings_section( 'clisyc_appearance_accent_section', __( 'UI Accent Colors', 'client-sync' ), [ $this, 'render_accent_section_header' ], $appearance_page );

        $accent_color_fields = [
            'accent_normal_bg'   => __( 'Button Background', 'client-sync' ),
            'accent_normal_text' => __( 'Button Text', 'client-sync' ),
            'accent_hover_bg'    => __( 'Button Hover Background', 'client-sync' ),
            'accent_hover_text'  => __( 'Button Hover Text', 'client-sync' ),
            'icon_bg'            => __( 'Icon Background', 'client-sync' ),
            'icon_text'          => __( 'Icon Color', 'client-sync' ),
        ];
        foreach ( $accent_color_fields as $key => $label ) {
            add_settings_field( 'clisyc_calendar_color_settings[' . $key . ']', $label, [ $this, 'render_color_picker_field' ], $appearance_page, 'clisyc_appearance_accent_section', [ 'id' => 'clisyc_calendar_color_settings[' . $key . ']', 'option_name' => Constants::OPTION_CALENDAR_COLOR_SETTINGS, 'path' => [ $key ], ] );
        }

        // --- Appearance Section: Text Size ---
        add_settings_section( 'clisyc_appearance_text_size_section', __( 'Text Size', 'client-sync' ), [ $this, 'render_text_size_section_header' ], $appearance_page );
        add_settings_field( 'clisyc_calendar_color_settings[text_size]', __( 'Calendar Text Size', 'client-sync' ), [ $this, 'render_text_size_field' ], $appearance_page, 'clisyc_appearance_text_size_section', [ 'id' => 'clisyc_calendar_color_settings[text_size]', 'option_name' => Constants::OPTION_CALENDAR_COLOR_SETTINGS, 'path' => [ 'text_size' ], ] );

        // =====================================================================
        // 3. BEHAVIOR SETTINGS (Booking rules, links, self-service, spam)
        // =====================================================================
        register_setting( $behavior_group, Constants::OPTION_MIN_BOOKING_NOTICE, [ 'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 60 ] );
        register_setting( $behavior_group, Constants::OPTION_GLOBAL_BUFFER_BEFORE, [ 'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 0 ] );
        register_setting( $behavior_group, Constants::OPTION_GLOBAL_BUFFER_AFTER, [ 'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 0 ] );
        register_setting( $behavior_group, 'clisyc_calendar_show_overview_availability', [ 'type' => 'string', 'sanitize_callback' => [ $this, 'sanitize_overview_availability_setting' ], 'default' => 'none' ] );
        register_setting( $behavior_group, Constants::OPTION_CALENDAR_SMART_START, [ 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean', 'default' => false ] );
        register_setting( $behavior_group, 'clisyc_mysql_convert_tz_override', [ 'type' => 'string', 'sanitize_callback' => [$this, 'sanitize_convert_tz_override_setting'], 'default' => 'auto_detect' ] );
        register_setting( $behavior_group, Constants::OPTION_UNIVERSAL_SHORTCODE_MODE, [ 'type' => 'string', 'sanitize_callback' => 'sanitize_key', 'default' => 'slot' ] );
        register_setting( $behavior_group, Constants::OPTION_ENABLE_SELF_SERVICE, [ 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean', 'default' => false ] );
        register_setting( $behavior_group, Constants::OPTION_CANCEL_CUTOFF_VALUE, [ 'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 24 ] );
        register_setting( $behavior_group, Constants::OPTION_CANCEL_CUTOFF_UNIT, [ 'type' => 'string', 'sanitize_callback' => 'sanitize_key', 'default' => 'hours' ] );
        register_setting( $behavior_group, Constants::OPTION_CANCEL_REFUND_POLICY, [ 'type' => 'string', 'sanitize_callback' => 'sanitize_key', 'default' => 'none' ] );
        
        // FIX: Register ALL page ID settings so they save correctly
        register_setting( $behavior_group, Constants::OPTION_BOOKING_PAGE_ID, [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        register_setting( $behavior_group, Constants::OPTION_APPOINTMENT_VIEW_PAGE, [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        register_setting( $behavior_group, Constants::OPTION_BOOKING_SUCCESS_PAGE, [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        register_setting( $behavior_group, Constants::OPTION_SEARCH_RESULTS_PAGE, [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        
        // NEW: Contact Page for "no availability" fallback
        register_setting( $behavior_group, Constants::OPTION_CONTACT_PAGE, [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        
        // NEW: Manager Edit Appointment Page
        register_setting( $behavior_group, Constants::OPTION_MANAGER_EDIT_PAGE, [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        
        register_setting( $behavior_group, 'clisyc_global_blocked_periods', [ 'type' => 'array', 'sanitize_callback' => null ] );
        register_setting( $behavior_group, Constants::OPTION_ANTISPAM_HONEYPOT, [ 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean', 'default' => true ] );
        register_setting( $behavior_group, Constants::OPTION_ANTISPAM_TIME_CHECK, [ 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean', 'default' => true ] );

        // =========================================================================
        // HIPAA COMPLIANCE SETTINGS
        // =========================================================================
        register_setting( $behavior_group, Constants::OPTION_HIPAA_MODE, [
            'type'              => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default'           => false,
        ]);
        register_setting( $behavior_group, Constants::OPTION_AUDIT_LOG_RETENTION, [
            'type'              => 'integer',
            'sanitize_callback' => 'absint',
            'default'           => 2555, // ~7 years
        ]);
        register_setting( $behavior_group, Constants::OPTION_ANONYMIZE_EXTERNAL_SYNC, [
            'type'              => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default'           => true,
        ]);

        // --- Behavior Section: Booking Rules ---
        add_settings_section( 'clisyc_behavior_booking_rules_section', __( 'Booking Rules', 'client-sync' ), '__return_false', $behavior_page );
        add_settings_field( Constants::OPTION_MIN_BOOKING_NOTICE, __( 'Minimum Booking Notice', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $behavior_page, 'clisyc_behavior_booking_rules_section', ['id' => Constants::OPTION_MIN_BOOKING_NOTICE, 'type' => 'number', 'class' => 'small-text', 'desc' => __('minutes. Prevents last-minute bookings by requiring this much advance notice.', 'client-sync'), 'default' => 60] );
        add_settings_field( Constants::OPTION_GLOBAL_BUFFER_BEFORE, __( 'Buffer Time Before', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $behavior_page, 'clisyc_behavior_booking_rules_section', ['id' => Constants::OPTION_GLOBAL_BUFFER_BEFORE, 'type' => 'number', 'class' => 'small-text', 'desc' => __('minutes. Adds preparation time before each appointment.', 'client-sync'), 'default' => 0] );
        add_settings_field( Constants::OPTION_GLOBAL_BUFFER_AFTER, __( 'Buffer Time After', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $behavior_page, 'clisyc_behavior_booking_rules_section', ['id' => Constants::OPTION_GLOBAL_BUFFER_AFTER, 'type' => 'number', 'class' => 'small-text', 'desc' => __('minutes. Adds cleanup/transition time after each appointment.', 'client-sync'), 'default' => 0] );
        add_settings_field(
            Constants::OPTION_UNIVERSAL_SHORTCODE_MODE,
            __( 'Universal Shortcode Default', 'client-sync' ),
            [ $this, 'render_settings_field_callback' ],
            $behavior_page,
            'clisyc_behavior_booking_rules_section',
            [
                'id' => Constants::OPTION_UNIVERSAL_SHORTCODE_MODE,
                'type' => 'select',
                'options' => [
                    'slot'       => __( 'Time-Slot Calendar', 'client-sync' ),
                    'date_range' => __( 'Date Range Search Form', 'client-sync' ),
                ],
                'desc' => __( 'Default booking interface for <code>[clisyc_booking_form]</code> on generic pages.', 'client-sync' ),
            ]
        );
        add_settings_field( Constants::OPTION_CALENDAR_SMART_START, __( 'Smart Start Date', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $behavior_page, 'clisyc_behavior_booking_rules_section', [ 'id' => Constants::OPTION_CALENDAR_SMART_START, 'type' => 'checkbox', 'desc' => __( 'Calendar automatically displays the week of the next available slot instead of the current week.', 'client-sync' ) ] );

        // --- Behavior Section: Frontend Links & Pages ---
        add_settings_section( 'clisyc_behavior_frontend_links_section', __( 'Frontend Links & Pages', 'client-sync' ), '__return_false', $behavior_page );
        add_settings_field( Constants::OPTION_BOOKING_PAGE_ID, __( 'Booking Page', 'client-sync' ), [ $this, 'render_page_dropdown_field' ], $behavior_page, 'clisyc_behavior_frontend_links_section', [ 'id' => Constants::OPTION_BOOKING_PAGE_ID, 'desc' => __( 'Main page with the <code>[clisyc_booking_form]</code> shortcode. Used for generating direct links to services.', 'client-sync' ) ] );
        add_settings_field( Constants::OPTION_LOGIN_PAGE_URL, __( 'Custom Login Page URL', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $behavior_page, 'clisyc_behavior_frontend_links_section', ['id' => Constants::OPTION_LOGIN_PAGE_URL, 'type' => 'url', 'class' => 'regular-text', 'desc' => __('If set, guests will be redirected here instead of wp-login.php.', 'client-sync')] );
        add_settings_field( Constants::OPTION_APPOINTMENT_VIEW_PAGE, __( 'Appointment Detail Page', 'client-sync' ), [ $this, 'render_page_dropdown_field' ], $behavior_page, 'clisyc_behavior_frontend_links_section', [ 'id' => Constants::OPTION_APPOINTMENT_VIEW_PAGE, 'desc' => __( 'Page with <code>[clisyc_appointment_detail]</code> shortcode.', 'client-sync' ) ] );
        add_settings_field( Constants::OPTION_BOOKING_SUCCESS_PAGE, __( 'Booking Success Page', 'client-sync' ), [ $this, 'render_page_dropdown_field' ], $behavior_page, 'clisyc_behavior_frontend_links_section', [ 'id' => Constants::OPTION_BOOKING_SUCCESS_PAGE, 'desc' => __( 'Redirect destination after successful booking.', 'client-sync' ) ] );
        add_settings_field( Constants::OPTION_SEARCH_RESULTS_PAGE, __( 'Search Results Page', 'client-sync' ), [ $this, 'render_page_dropdown_field' ], $behavior_page, 'clisyc_behavior_frontend_links_section', [ 'id' => Constants::OPTION_SEARCH_RESULTS_PAGE, 'desc' => __( 'Page with <code>[clisyc_search_results]</code> shortcode.', 'client-sync' ) ] );
        
        // NEW: Manager Edit Appointment Page dropdown
        add_settings_field( Constants::OPTION_MANAGER_EDIT_PAGE, __( 'Manager Edit Appointment Page', 'client-sync' ), [ $this, 'render_page_dropdown_field' ], $behavior_page, 'clisyc_behavior_frontend_links_section', [ 'id' => Constants::OPTION_MANAGER_EDIT_PAGE, 'desc' => __( 'Page with <code>[clisyc_manager_edit_appointment]</code> shortcode. Used by the Manager Appointments dashboard.', 'client-sync' ) ] );
        
        // NEW: Contact Page dropdown
        add_settings_field( 
            Constants::OPTION_CONTACT_PAGE, 
            __( 'Contact Page', 'client-sync' ), 
            [ $this, 'render_page_dropdown_field' ], 
            $behavior_page, 
            'clisyc_behavior_frontend_links_section', 
            [ 
                'id' => Constants::OPTION_CONTACT_PAGE, 
                'desc' => __( 'Fallback page shown when no availability exists. Users can contact you for assistance.', 'client-sync' ) 
            ] 
        );

        // --- Behavior Section: Self-Service ---
        add_settings_section( 'clisyc_behavior_self_service_section', __( 'Client Self-Service', 'client-sync' ), '__return_false', $behavior_page );
        add_settings_field( Constants::OPTION_ENABLE_SELF_SERVICE, __( 'Enable Self-Service', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $behavior_page, 'clisyc_behavior_self_service_section', [ 'id' => Constants::OPTION_ENABLE_SELF_SERVICE, 'type' => 'checkbox', 'desc' => __( 'Allow logged-in clients to cancel or reschedule their own appointments.', 'client-sync' ) ] );
        add_settings_field( 'clisyc_cancellation_cutoff', __( 'Cancellation/Reschedule Cutoff', 'client-sync' ), [ $this, 'render_cancellation_cutoff_field' ], $behavior_page, 'clisyc_behavior_self_service_section' );
        add_settings_field( Constants::OPTION_CANCEL_REFUND_POLICY, __( 'Refund Policy on Cancellation', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $behavior_page, 'clisyc_behavior_self_service_section', [ 'id' => Constants::OPTION_CANCEL_REFUND_POLICY, 'type' => 'select', 'options' => [ 'none' => __( 'No Refund', 'client-sync' ), 'full_refund' => __( 'Attempt Full Refund (Requires WooCommerce)', 'client-sync' ) ], 'desc' => __( 'Action for paid appointments when cancelled within allowed time.', 'client-sync' ) ] );

        // --- Behavior Section: Spam Protection ---
        add_settings_section( 'clisyc_behavior_antispam_section', __( 'Spam Protection', 'client-sync' ), [ $this, 'render_antispam_section_callback' ], $behavior_page );
        add_settings_field( Constants::OPTION_ANTISPAM_HONEYPOT, __( 'Enable Honeypot Field', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $behavior_page, 'clisyc_behavior_antispam_section', [ 'id' => Constants::OPTION_ANTISPAM_HONEYPOT, 'type' => 'checkbox', 'desc' => __( 'Adds a hidden field to catch automated bots.', 'client-sync' ) ] );
        add_settings_field( Constants::OPTION_ANTISPAM_TIME_CHECK, __( 'Enable Timing Check', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $behavior_page, 'clisyc_behavior_antispam_section', [ 'id' => Constants::OPTION_ANTISPAM_TIME_CHECK, 'type' => 'checkbox', 'desc' => __( 'Rejects submissions that occur too quickly (likely bots).', 'client-sync' ) ] );

        // --- Behavior Section: HIPAA Compliance ---
        add_settings_section(
            'clisyc_behavior_hipaa_section',
            __( 'HIPAA Compliance', 'client-sync' ),
            [ $this, 'render_hipaa_section_header' ],
            $behavior_page
        );

        add_settings_field(
            Constants::OPTION_HIPAA_MODE,
            __( 'Enable HIPAA Mode', 'client-sync' ),
            [ $this, 'render_hipaa_mode_field' ],
            $behavior_page,
            'clisyc_behavior_hipaa_section'
        );

        add_settings_field(
            Constants::OPTION_AUDIT_LOG_RETENTION,
            __( 'Audit Log Retention', 'client-sync' ),
            [ $this, 'render_settings_field_callback' ],
            $behavior_page,
            'clisyc_behavior_hipaa_section',
            [
                'id'      => Constants::OPTION_AUDIT_LOG_RETENTION,
                'type'    => 'number',
                'class'   => 'small-text',
                'default' => 2555,
                'desc'    => __( 'days. HIPAA requires minimum 6 years. Default is ~7 years (2555 days).', 'client-sync' ),
            ]
        );

        add_settings_field(
            Constants::OPTION_ANONYMIZE_EXTERNAL_SYNC,
            __( 'Anonymize External Sync', 'client-sync' ),
            [ $this, 'render_settings_field_callback' ],
            $behavior_page,
            'clisyc_behavior_hipaa_section',
            [
                'id'   => Constants::OPTION_ANONYMIZE_EXTERNAL_SYNC,
                'type' => 'checkbox',
                'desc' => __( 'Send only "Busy - Appt #ID" to Google Calendar instead of client names.', 'client-sync' ),
            ]
        );

        // --- Behavior Section: Advanced/Technical ---
        add_settings_section( 'clisyc_behavior_advanced_section', __( 'Advanced Settings', 'client-sync' ), '__return_false', $behavior_page );
        $status_html = '<strong><span id="clisyc-detected-convert-tz-status">' . esc_html( ucfirst( get_option( Constants::OPTION_MYSQL_CONVERT_TZ, 'unknown' ) ) ) . '</span></strong>';
        $reset_link_html = '<br><a href="#" id="clisyc-reset-detection-link" class="clisyc-reset-detection-link">' . esc_html__( 'Reset Auto-Detection Status', 'client-sync' ) . '</a>';
        /* translators: 1: The current detected status. 2: A link to reset the status. */
        $tz_desc = sprintf( esc_html__( 'Current status: %1$s. %2$s', 'client-sync' ), $status_html, $reset_link_html );
        add_settings_field( 'clisyc_mysql_convert_tz_override', __('MySQL Timezone Method', 'client-sync'), [$this, 'render_settings_field_callback'], $behavior_page, 'clisyc_behavior_advanced_section', [ 'id' => 'clisyc_mysql_convert_tz_override', 'type' => 'select', 'options' => [ 'auto_detect' => __('Auto-Detect (Recommended)', 'client-sync'), 'force_mysql' => __('Force MySQL CONVERT_TZ', 'client-sync'), 'force_php' => __('Force PHP Conversion', 'client-sync'), ], 'desc' => $tz_desc ] );

        // --- AUTOMATION SETTINGS ---
        register_setting( $automation_group, Constants::OPTION_AUTO_GEN_ENABLED, [ 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean', 'default' => false ] );
        register_setting( $automation_group, Constants::OPTION_AUTO_GEN_LOOKAHEAD, [ 'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 14 ] );

        add_settings_section( 'clisyc_automation_slot_generation_section', '', [ $this, 'render_automation_section_header' ], $automation_page );
        add_settings_field( Constants::OPTION_AUTO_GEN_ENABLED, __( 'Enable Auto-Generation', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $automation_page, 'clisyc_automation_slot_generation_section', [ 'id' => Constants::OPTION_AUTO_GEN_ENABLED, 'type' => 'checkbox', 'desc' => __( 'Automatically generate future available time slots based on the schedule of your primary dimension.', 'client-sync' ) ] );
        add_settings_field( Constants::OPTION_AUTO_GEN_LOOKAHEAD, __( 'Generation Lookahead', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $automation_page, 'clisyc_automation_slot_generation_section', [ 'id' => Constants::OPTION_AUTO_GEN_LOOKAHEAD, 'type' => 'number', 'class' => 'small-text', 'desc' => __( 'days. How many days in advance should slots be generated?', 'client-sync' ), 'default' => 14 ] );

        // --- PAYMENTS SETTINGS ---
        register_setting( $payment_group, Constants::OPTION_WC_ENABLED, [ 'type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean', 'default' => false ] );
        add_settings_section( 'clisyc_payments_wc_section', __( 'WooCommerce Integration', 'client-sync' ), null, $payment_page );
        add_settings_field( Constants::OPTION_WC_ENABLED, __( 'Enable WooCommerce Payments', 'client-sync' ), [ $this, 'render_settings_field_callback' ], $payment_page, 'clisyc_payments_wc_section', [ 'id' => Constants::OPTION_WC_ENABLED, 'type' => 'checkbox', 'desc' => __( 'Require payment for appointments via WooCommerce.', 'client-sync' ) ] );
        register_setting( $payment_group, Constants::OPTION_WC_PRODUCT_ID, [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );

        // --- INTEGRATIONS SETTINGS ---
        register_setting( $integrations_group, 'clisyc_sms_credentials', [ 'type' => 'array', 'sanitize_callback' => [ $this, 'sanitize_sms_credentials' ] ] );
        register_setting( $integrations_group, 'clisyc_webhooks', [ 'type' => 'array', 'sanitize_callback' => [ $this, 'sanitize_webhooks' ] ] );

        add_settings_section( 'clisyc_twilio_section', __( 'Twilio SMS', 'client-sync' ), [ $this, 'render_twilio_section_header' ], $integrations_page );
        add_settings_field( 'clisyc_sms_credentials[twilio_sid]', __('Account SID', 'client-sync'), [$this, 'render_settings_field_callback'], $integrations_page, 'clisyc_twilio_section', ['id' => 'clisyc_sms_credentials[twilio_sid]', 'type' => 'text', 'class' => 'regular-text', 'option_name' => 'clisyc_sms_credentials', 'path' => ['twilio_sid']]);
        add_settings_field( 'clisyc_sms_credentials[twilio_token]', __('Auth Token', 'client-sync'), [$this, 'render_settings_field_callback'], $integrations_page, 'clisyc_twilio_section', ['id' => 'clisyc_sms_credentials[twilio_token]', 'type' => 'password', 'class' => 'regular-text', 'option_name' => 'clisyc_sms_credentials', 'path' => ['twilio_token']]);
        add_settings_field( 'clisyc_sms_credentials[twilio_from]', __('From Number', 'client-sync'), [$this, 'render_settings_field_callback'], $integrations_page, 'clisyc_twilio_section', ['id' => 'clisyc_sms_credentials[twilio_from]', 'type' => 'text', 'class' => 'regular-text', 'option_name' => 'clisyc_sms_credentials', 'path' => ['twilio_from'], 'desc' => __('Your Twilio phone number (e.g., +1234567890).', 'client-sync')]);

        add_settings_section( 'clisyc_webhooks_section', __( 'Webhooks', 'client-sync' ), [ $this, 'render_webhooks_section_header' ], $integrations_page );
        add_settings_field( 'clisyc_webhooks', '', [ $this, 'render_webhooks_field' ], $integrations_page, 'clisyc_webhooks_section' );
    }

    // =========================================================================
    // SECTION HEADER CALLBACKS
    // =========================================================================

    public function render_calendar_display_section_header() {
        echo '<p>' . esc_html__( 'Configure how the booking calendar appears to your visitors.', 'client-sync' ) . '</p>';
    }

    public function render_colors_section_header() {
        echo '<p>' . esc_html__( 'Customize the colors used to display calendar events. Leave empty to use defaults.', 'client-sync' ) . '</p>';
        echo '<p class="description">' . esc_html__( 'Default colors provide a clean, accessible palette. Clear any field to restore its default.', 'client-sync' ) . '</p>';
    }

    public function render_accent_section_header() {
        echo '<p>' . esc_html__( 'Customize buttons, icons, and interactive elements throughout the booking interface.', 'client-sync' ) . '</p>';
    }

    public function render_antispam_section_callback() {
        echo '<p>' . esc_html__( 'Protect your booking forms from spam submissions without requiring CAPTCHA.', 'client-sync' ) . '</p>';
    }

    public function render_reminders_section_callback() {
        echo '<p>' . esc_html__( 'Configure automatic reminder emails sent to clients before their appointments.', 'client-sync' ) . '</p>';
    }

    public function render_automation_section_header() {
        echo '<p>' . esc_html__( 'Configure automatic slot generation based on your defined schedules.', 'client-sync' ) . '</p>';
    }

    public function render_twilio_section_header() {
        echo '<p>' . esc_html__( 'Enter your Twilio credentials to enable SMS notifications.', 'client-sync' ) . '</p>';
    }

    public function render_webhooks_section_header() {
        echo '<p>' . esc_html__( 'Configure webhooks to notify external systems when appointments are created, updated, or cancelled.', 'client-sync' ) . '</p>';
    }

    public function render_text_size_section_header() {
        echo '<p>' . esc_html__( 'Adjust the text size throughout the booking interface.', 'client-sync' ) . '</p>';
    }

    public function render_notification_section_header( $args ) {
        if ( ! empty( $args['placeholders'] ) && is_array( $args['placeholders'] ) ) {
            $placeholder_list = implode( ', ', array_map( function( $p ) { return '<code>' . esc_html( $p ) . '</code>'; }, $args['placeholders'] ) );
            echo '<p class="description">' . esc_html__( 'Available placeholders:', 'client-sync' ) . ' ' . wp_kses( $placeholder_list, [ 'code' => [] ] ) . '</p>';
        }
    }

    /**
     * Render the HIPAA section header with status indicator.
     *
     * @return void
     */
    public function render_hipaa_section_header(): void {
        $hipaa_helper = \DependentMedia\ClientSync\Services\HIPAA_Helper::get_instance();
        $status       = $hipaa_helper->get_status();

        echo '<div class="clisyc-hipaa-section-header">';
        echo '<p>' . esc_html__( 'Configure HIPAA compliance features for protecting Patient Health Information (PHI).', 'client-sync' ) . '</p>';

        // Show status badge
        if ( $status['enabled'] ) {
            if ( $status['operational'] ) {
                echo '<p class="clisyc-hipaa-status clisyc-hipaa-status--active">';
                echo '<span class="dashicons dashicons-shield-alt"></span> ';
                echo esc_html__( 'HIPAA Mode: Active & Operational', 'client-sync' );
                echo '</p>';
            } else {
                echo '<p class="clisyc-hipaa-status clisyc-hipaa-status--warning">';
                echo '<span class="dashicons dashicons-warning"></span> ';
                echo esc_html__( 'HIPAA Mode: Enabled but encryption not configured', 'client-sync' );
                echo '</p>';
            }
        }

        echo '</div>';
    }

    /**
     * Render the HIPAA mode toggle field with lock indicator.
     *
     * @return void
     */
    public function render_hipaa_mode_field(): void {
        $hipaa_helper = \DependentMedia\ClientSync\Services\HIPAA_Helper::get_instance();
        $is_locked    = $hipaa_helper->is_hipaa_mode_locked();
        $is_enabled   = $hipaa_helper->is_hipaa_mode();

        $field_id   = Constants::OPTION_HIPAA_MODE;
        $disabled   = $is_locked ? 'disabled' : '';
        $checked    = $is_enabled ? 'checked' : '';

        echo '<fieldset>';
        echo '<label for="' . esc_attr( $field_id ) . '">';

        // Render the checkbox
        printf(
            '<input type="checkbox" id="%1$s" name="%1$s" value="1" %2$s %3$s />',
            esc_attr( $field_id ),
            esc_attr( $checked ),
            esc_attr( $disabled )
        );

        echo ' ' . esc_html__( 'Enable HIPAA compliance features (encryption, audit logging, anonymization).', 'client-sync' );
        echo '</label>';

        // Show lock indicator if controlled by constant
        if ( $is_locked ) {
            $lock_status = CLISYC_HIPAA_MODE ? __( 'ON', 'client-sync' ) : __( 'OFF', 'client-sync' );
            echo '<p class="description clisyc-hipaa-locked">';
            echo '<span class="dashicons dashicons-lock"></span> ';
            printf(
                /* translators: %s: Current lock status (ON/OFF) */
                esc_html__( 'Locked by CLISYC_HIPAA_MODE constant in wp-config.php (currently: %s)', 'client-sync' ),
                '<strong>' . esc_html( $lock_status ) . '</strong>'
            );
            echo '</p>';

            // Hidden field to preserve the constant value in form submissions
            printf(
                '<input type="hidden" name="%s" value="%s" />',
                esc_attr( $field_id ),
                $is_enabled ? '1' : '0'
            );
        }

        // Show encryption key status
        if ( $is_enabled ) {
            $key_status = $hipaa_helper->validate_encryption_key();
            if ( $key_status['valid'] ) {
                echo '<p class="description" style="color: #00a32a;">';
                echo '<span class="dashicons dashicons-yes-alt"></span> ';
                echo esc_html__( 'Encryption key configured.', 'client-sync' );
                echo '</p>';
            } else {
                echo '<p class="description" style="color: #d63638;">';
                echo '<span class="dashicons dashicons-warning"></span> ';
                echo esc_html( $key_status['message'] );
                echo '</p>';
            }
        }

        echo '</fieldset>';
    }

    // =========================================================================
    // FIELD RENDER CALLBACKS
    // =========================================================================

    public function render_settings_field_callback( $args ) {
        $id          = $args['id'] ?? '';
        $type        = $args['type'] ?? 'text';
        $class       = $args['class'] ?? '';
        $desc        = $args['desc'] ?? '';
        $default     = $args['default'] ?? '';
        $option_name = $args['option_name'] ?? $id;
        $path        = $args['path'] ?? [];
        $options     = $args['options'] ?? [];

        // Get value
        if ( ! empty( $path ) ) {
            $option_value = get_option( $option_name, [] );
            $value = $option_value;
            foreach ( $path as $key ) {
                $value = $value[ $key ] ?? $default;
            }
        } else {
            $value = get_option( $id, $default );
        }

        switch ( $type ) {
            case 'checkbox':
                printf(
                    '<input type="checkbox" id="%1$s" name="%2$s" value="1" %3$s />',
                    esc_attr( $id ),
                    esc_attr( $option_name . ( ! empty( $path ) ? '[' . implode( '][', $path ) . ']' : '' ) ),
                    checked( 1, $value, false )
                );
                break;

            case 'select':
                printf( '<select id="%1$s" name="%2$s">', esc_attr( $id ), esc_attr( $option_name . ( ! empty( $path ) ? '[' . implode( '][', $path ) . ']' : '' ) ) );
                foreach ( $options as $opt_value => $opt_label ) {
                    printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $opt_value ), selected( $value, $opt_value, false ), esc_html( $opt_label ) );
                }
                echo '</select>';
                break;

            case 'textarea':
                printf(
                    '<textarea id="%1$s" name="%2$s" class="large-text" rows="3">%3$s</textarea>',
                    esc_attr( $id ),
                    esc_attr( $option_name . ( ! empty( $path ) ? '[' . implode( '][', $path ) . ']' : '' ) ),
                    esc_textarea( $value )
                );
                break;

            case 'wp_editor':
                $editor_id = str_replace( [ '[', ']' ], '_', $id );
                wp_editor( $value, $editor_id, [
                    'textarea_name' => $option_name . ( ! empty( $path ) ? '[' . implode( '][', $path ) . ']' : '' ),
                    'textarea_rows' => 10,
                    'media_buttons' => false,
                    'teeny'         => true,
                ] );
                break;

            default: // text, number, email, url, password
                printf(
                    '<input type="%1$s" id="%2$s" name="%3$s" value="%4$s" class="%5$s" />',
                    esc_attr( $type ),
                    esc_attr( $id ),
                    esc_attr( $option_name . ( ! empty( $path ) ? '[' . implode( '][', $path ) . ']' : '' ) ),
                    esc_attr( $value ),
                    esc_attr( $class )
                );
                break;
        }

        if ( $desc ) {
            printf( '<p class="description">%s</p>', wp_kses( $desc, [ 'code' => [], 'strong' => [], 'em' => [], 'a' => [ 'href' => [], 'target' => [] ], 'br' => [], 'span' => [ 'id' => [], 'class' => [] ] ] ) );
        }
    }

    public function render_page_dropdown_field( $args ) {
        $id    = $args['id'] ?? '';
        $desc  = $args['desc'] ?? '';
        $value = get_option( $id, 0 );

        // FIXED: Set echo to 0 to capture output, then escape with wp_kses.
        $dropdown = wp_dropdown_pages( [
            'name'              => esc_attr( $id ),
            'id'                => esc_attr( $id ),
            'selected'          => absint( $value ),
            'show_option_none'  => esc_html__( '— Select —', 'client-sync' ),
            'option_none_value' => '0',
            'echo'              => 0,
        ] );

        echo '<div class="clisyc-page-dropdown-wrap" style="display: flex; align-items: center; gap: 8px;">';

        echo wp_kses(
            $dropdown,
            [
                'select' => [
                    'name' => [],
                    'id'   => [],
                ],
                'option' => [
                    'value'    => [],
                    'selected' => [],
                    'class'    => [],
                ],
            ]
        );

        // Show "Create Page" button for settings that have a page definition.
        $page_definitions = \DependentMedia\ClientSync\Admin\Onboarding_Wizard::get_page_definitions();
        $has_definition   = false;
        foreach ( $page_definitions as $def ) {
            if ( ( $def['option_key'] ?? '' ) === $id ) {
                $has_definition = true;
                break;
            }
        }

        if ( $has_definition ) {
            printf(
                '<button type="button" class="button button-secondary clisyc-create-page-btn" data-option-key="%s" data-dropdown-id="%s" title="%s" style="%s">
                    <span class="dashicons dashicons-plus-alt2" style="vertical-align: middle; margin-top: -2px;"></span> %s
                </button>',
                esc_attr( $id ),
                esc_attr( $id ),
                esc_attr__( 'Create a new page with the correct shortcode and select it automatically', 'client-sync' ),
                absint( $value ) > 0 ? 'display:none;' : '',
                esc_html__( 'Create Page', 'client-sync' )
            );
        }

        echo '</div>';

        if ( $desc ) {
            printf( '<p class="description">%s</p>', wp_kses( $desc, [ 'code' => [], 'strong' => [], 'em' => [], 'a' => [ 'href' => [], 'target' => [] ] ] ) );
        }
    }

    public function render_color_picker_field( $args ) {
        $id          = $args['id'] ?? '';
        $option_name = $args['option_name'] ?? '';
        $path        = $args['path'] ?? [];
        $defaults    = self::get_default_color_settings();

        $option_value = get_option( $option_name, [] );
        $value = $option_value;
        foreach ( $path as $key ) {
            $value = $value[ $key ] ?? '';
        }

        $default_for_key = $defaults[ $path[0] ] ?? '#000000';
        $placeholder = $default_for_key;

        printf(
            '<input type="text" id="%1$s" name="%2$s" value="%3$s" class="clisyc-color-picker" data-default-color="%4$s" placeholder="%5$s" />',
            esc_attr( $id ),
            esc_attr( $option_name . '[' . implode( '][', $path ) . ']' ),
            esc_attr( $value ),
            esc_attr( $default_for_key ),
            esc_attr( $placeholder )
        );
        echo '<p class="description">' . esc_html__( 'Leave empty to use default.', 'client-sync' ) . '</p>';
    }

    public function render_text_size_field( $args ) {
        $id          = $args['id'] ?? '';
        $option_name = $args['option_name'] ?? '';
        $path        = $args['path'] ?? [];

        $option_value = get_option( $option_name, [] );
        $value = 'medium';
        foreach ( $path as $key ) {
            if ( isset( $option_value[ $key ] ) ) {
                $value = $option_value[ $key ];
            }
        }

        $sizes = [
            'small'   => __( 'Small', 'client-sync' ),
            'medium'  => __( 'Medium (Default)', 'client-sync' ),
            'large'   => __( 'Large', 'client-sync' ),
            'x-large' => __( 'Extra Large', 'client-sync' ),
        ];

        printf( '<select id="%1$s" name="%2$s">', esc_attr( $id ), esc_attr( $option_name . '[' . implode( '][', $path ) . ']' ) );
        foreach ( $sizes as $size_value => $size_label ) {
            printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $size_value ), selected( $value, $size_value, false ), esc_html( $size_label ) );
        }
        echo '</select>';
    }

    /**
     * Render the Calendar Slot Height dropdown field.
     * Controls the vertical height of time slots in the calendar.
     * Value represents pixels per hour.
     */
    public function render_slot_height_field() {
        $current_value = get_option( Constants::OPTION_CALENDAR_SLOT_HEIGHT, '80' );

        $height_options = [
            '48'  => __( 'Compact (48px/hour)', 'client-sync' ),
            '60'  => __( 'Small (60px/hour)', 'client-sync' ),
            '80'  => __( 'Medium (80px/hour) - Default', 'client-sync' ),
            '100' => __( 'Large (100px/hour)', 'client-sync' ),
            '120' => __( 'Extra Large (120px/hour)', 'client-sync' ),
            '150' => __( 'Maximum (150px/hour)', 'client-sync' ),
        ];

        echo '<select id="clisyc_calendar_slot_height" name="clisyc_calendar_slot_height">';
        foreach ( $height_options as $height_value => $height_label ) {
            printf(
                '<option value="%1$s" %2$s>%3$s</option>',
                esc_attr( $height_value ),
                selected( $current_value, $height_value, false ),
                esc_html( $height_label )
            );
        }
        echo '</select>';
        echo '<p class="description">' . esc_html__( 'Controls the vertical height of time slots in week/day views. Larger values make short appointments easier to see and click.', 'client-sync' ) . '</p>';
    }

    public function render_calendar_views_field() {
        $saved_views = get_option( Constants::OPTION_CALENDAR_ENABLED_VIEWS, [] );
        if ( empty( $saved_views ) ) {
            $saved_views = [ 'dayGridMonth', 'timeGridWeek', 'timeGridDay', 'listWeek' ];
        }

        $all_views = [
            'dayGridMonth' => __( 'Month Grid', 'client-sync' ),
            'dayGridWeek'  => __( 'Week Grid', 'client-sync' ),
            'dayGridDay'   => __( 'Day Grid', 'client-sync' ),
            'timeGridWeek' => __( 'Week Time Grid', 'client-sync' ),
            'timeGridDay'  => __( 'Day Time Grid', 'client-sync' ),
            'listWeek'     => __( 'Week List', 'client-sync' ),
            'listDay'      => __( 'Day List', 'client-sync' ),
            'listMonth'    => __( 'Month List', 'client-sync' ),
        ];

        echo '<fieldset>';
        foreach ( $all_views as $view_value => $view_label ) {
            $checked = in_array( $view_value, $saved_views, true ) ? 'checked' : '';
            printf(
                '<label style="display: block; margin-bottom: 5px;"><input type="checkbox" name="clisyc_calendar_enabled_views[]" value="%1$s" %2$s /> %3$s</label>',
                esc_attr( $view_value ),
                esc_attr( $checked ),
                esc_html( $view_label )
            );
        }
        echo '</fieldset>';
        echo '<p class="description">' . esc_html__( 'Select which calendar views are available to users.', 'client-sync' ) . '</p>';
    }

    public function render_initial_view_field() {
        $style = get_option( Constants::OPTION_FRONTEND_CALENDAR_STYLE, [] );
        $current = $style[ Constants::OPTION_INITIAL_VIEW ] ?? 'timeGridWeek';

        $views = [
            'dayGridMonth' => __( 'Month Grid', 'client-sync' ),
            'dayGridWeek'  => __( 'Week Grid', 'client-sync' ),
            'dayGridDay'   => __( 'Day Grid', 'client-sync' ),
            'timeGridWeek' => __( 'Week Time Grid', 'client-sync' ),
            'timeGridDay'  => __( 'Day Time Grid', 'client-sync' ),
            'listWeek'     => __( 'Week List', 'client-sync' ),
            'listDay'      => __( 'Day List', 'client-sync' ),
            'listMonth'    => __( 'Month List', 'client-sync' ),
        ];

        printf( '<select id="%1$s" name="clisyc_frontend_calendar_style[%1$s]">', esc_attr( Constants::OPTION_INITIAL_VIEW ) );
        foreach ( $views as $view_value => $view_label ) {
            printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $view_value ), selected( $current, $view_value, false ), esc_html( $view_label ) );
        }
        echo '</select>';
        echo '<p class="description">' . esc_html__( 'The default view when the calendar first loads.', 'client-sync' ) . '</p>';
    }

    public function render_visibility_check_button() {
        echo '<button type="button" id="clisyc-check-slot-visibility" class="button button-secondary">';
        echo '<span class="dashicons dashicons-search" style="vertical-align: middle; margin-right: 4px;"></span>';
        esc_html_e( 'Check for Hidden Slots', 'client-sync' );
        echo '</button>';
        echo '<p class="description">' . esc_html__( 'Scan for time slots that fall outside the visible calendar hours.', 'client-sync' ) . '</p>';
        echo '<div id="clisyc-visibility-results" style="margin-top: 10px;"></div>';
    }

    public function render_cancellation_cutoff_field() {
        $value = get_option( Constants::OPTION_CANCEL_CUTOFF_VALUE, 24 );
        $unit  = get_option( Constants::OPTION_CANCEL_CUTOFF_UNIT, 'hours' );

        printf( '<input type="number" id="clisyc_cancellation_cutoff_value" name="clisyc_cancellation_cutoff_value" value="%s" class="small-text" min="0" />', esc_attr( $value ) );

        echo '<select id="clisyc_cancellation_cutoff_unit" name="clisyc_cancellation_cutoff_unit">';
        printf( '<option value="hours" %s>%s</option>', selected( $unit, 'hours', false ), esc_html__( 'hours', 'client-sync' ) );
        printf( '<option value="days" %s>%s</option>', selected( $unit, 'days', false ), esc_html__( 'days', 'client-sync' ) );
        echo '</select>';

        echo '<p class="description">' . esc_html__( 'How far in advance clients must cancel or reschedule.', 'client-sync' ) . '</p>';
    }

    public function render_reminder_lead_time_field() {
        $settings = get_option( Constants::OPTION_REMINDER_SETTINGS, [] );
        $value = $settings['lead_time_value'] ?? 24;
        $unit  = $settings['lead_time_unit'] ?? 'hours';

        printf( '<input type="number" name="%s[lead_time_value]" value="%s" class="small-text" min="1" />', esc_attr( Constants::OPTION_REMINDER_SETTINGS ), esc_attr( $value ) );

        printf( '<select name="%s[lead_time_unit]">', esc_attr( Constants::OPTION_REMINDER_SETTINGS ) );
        printf( '<option value="hours" %s>%s</option>', selected( $unit, 'hours', false ), esc_html__( 'hours', 'client-sync' ) );
        printf( '<option value="days" %s>%s</option>', selected( $unit, 'days', false ), esc_html__( 'days', 'client-sync' ) );
        echo '</select>';

        echo '<p class="description">' . esc_html__( 'How long before the appointment should the reminder be sent?', 'client-sync' ) . '</p>';
    }

    public function render_webhooks_field() {
        $webhooks = get_option( Constants::OPTION_WEBHOOKS, [] );
        if ( empty( $webhooks ) ) {
            $webhooks = [ [ 'enabled' => false, 'url' => '', 'events' => [] ] ];
        }

        $available_events = [
            'appointment_created'   => __( 'Appointment Created', 'client-sync' ),
            'appointment_updated'   => __( 'Appointment Updated', 'client-sync' ),
            'appointment_cancelled' => __( 'Appointment Cancelled', 'client-sync' ),
        ];

        echo '<div id="clisyc-webhooks-container">';
        foreach ( $webhooks as $index => $webhook ) {
            echo '<div class="clisyc-webhook-row" style="margin-bottom: 20px; padding: 15px; background: #f9f9f9; border: 1px solid #ddd;">';
            
            printf(
                '<p><label><input type="checkbox" name="clisyc_webhooks[%d][enabled]" value="1" %s /> %s</label></p>',
                absint( $index ),
                checked( ! empty( $webhook['enabled'] ), true, false ),
                esc_html__( 'Enable this webhook', 'client-sync' )
            );

            printf(
                '<p><label>%s<br><input type="url" name="clisyc_webhooks[%d][url]" value="%s" class="regular-text" placeholder="https://example.com/webhook" /></label></p>',
                esc_html__( 'Webhook URL', 'client-sync' ),
                absint( $index ),
                esc_attr( $webhook['url'] ?? '' )
            );

            echo '<p><strong>' . esc_html__( 'Trigger on events:', 'client-sync' ) . '</strong></p>';
            foreach ( $available_events as $event_key => $event_label ) {
                $checked = in_array( $event_key, $webhook['events'] ?? [], true ) ? 'checked' : '';
                printf(
                    '<label style="display: block; margin-left: 10px;"><input type="checkbox" name="clisyc_webhooks[%d][events][]" value="%s" %s /> %s</label>',
                    absint( $index ),
                    esc_attr( $event_key ),
                    esc_attr( $checked ),
                    esc_html( $event_label )
                );
            }

            echo '</div>';
        }
        echo '</div>';
    }

    // =========================================================================
    // SANITIZATION CALLBACKS
    // =========================================================================

    public function sanitize_color_settings( $input ) {
        if ( ! is_array( $input ) ) {
            return [];
        }

        $sanitized_output = [];
        $allowed_sizes = [ 'small', 'medium', 'large', 'x-large' ];

        foreach ( $input as $key => $value_to_sanitize ) {
            if ( 'text_size' === $key ) {
                $sanitized_output[ $key ] = in_array( $value_to_sanitize, $allowed_sizes, true ) ? $value_to_sanitize : 'medium';
            } else {
                // Sanitize hex color, keep empty if cleared (will use CSS default)
                $sanitized = sanitize_hex_color( $value_to_sanitize );
                $sanitized_output[ $key ] = $sanitized ?: '';
            }
        }

        return $sanitized_output;
    }

    public function sanitize_frontend_calendar_style( $input ) {
        $output = [];
        $allowed_views = [
            'dayGridMonth', 'dayGridWeek', 'dayGridDay',
            'timeGridWeek', 'timeGridDay',
            'listWeek', 'listDay', 'listMonth'
        ];
        if ( isset( $input[ Constants::OPTION_INITIAL_VIEW ] ) && in_array( $input[ Constants::OPTION_INITIAL_VIEW ], $allowed_views, true ) ) {
            $output[ Constants::OPTION_INITIAL_VIEW ] = $input[ Constants::OPTION_INITIAL_VIEW ];
        } else {
            $output[ Constants::OPTION_INITIAL_VIEW ] = 'timeGridWeek';
        }
        return $output;
    }

    public function sanitize_enabled_views_setting( $input ) {
        if ( ! is_array( $input ) ) {
            return [];
        }
        $allowed_views = [
            'dayGridMonth', 'dayGridWeek', 'dayGridDay',
            'timeGridWeek', 'timeGridDay',
            'listWeek', 'listDay', 'listMonth'
        ];
        return array_values( array_filter( $input, function( $view ) use ( $allowed_views ) {
            return in_array( $view, $allowed_views, true );
        } ) );
    }

    public function sanitize_overview_availability_setting( $input ) {
        $allowed_values = [ 'none', 'overview_preview', 'overview_bookable', 'overview_bookable_no_filter' ];
        return in_array( $input, $allowed_values, true ) ? $input : 'none';
    }

    public function sanitize_convert_tz_override_setting( $input ) {
        $allowed_values = [ 'auto_detect', 'force_mysql', 'force_php' ];
        if ( in_array( $input, $allowed_values, true ) ) {
            $current_value = get_option( Constants::OPTION_MYSQL_CONVERT_TZ_OR, 'auto_detect' );
            if ( $current_value !== $input ) {
                update_option( 'clisyc_mysql_convert_tz_status', 'unknown' );
                delete_transient( 'clisyc_convert_tz_notice_shown' );
            }
            return $input;
        }
        return 'auto_detect';
    }

    public function sanitize_notification_settings( $input ) {
        $output = get_option( Constants::OPTION_NOTIFICATION_SETTINGS, [] );
        $notifications_class = new \DependentMedia\ClientSync\Core\Notifications();
        $event_types = $notifications_class->get_event_types();

        if ( ! is_array( $input ) ) {
            return $output;
        }

        foreach ( $event_types as $event_key => $event_data ) {
            if ( isset( $input[ $event_key ] ) && is_array( $input[ $event_key ] ) ) {
                foreach ( $event_data['recipient_types'] as $recipient_type ) {
                    $base_key = $recipient_type;
                    $output[ $event_key ][ $base_key . '_enabled' ] = isset( $input[ $event_key ][ $base_key . '_enabled' ] ) ? 1 : 0;
                    $output[ $event_key ][ $base_key . '_subject' ] = isset( $input[ $event_key ][ $base_key . '_subject' ] ) ? sanitize_text_field( wp_unslash( $input[ $event_key ][ $base_key . '_subject' ] ) ) : '';
                    $output[ $event_key ][ $base_key . '_body' ] = isset( $input[ $event_key ][ $base_key . '_body' ] ) ? wp_kses_post( wp_unslash( $input[ $event_key ][ $base_key . '_body' ] ) ) : '';
                }
                if ( in_array( 'client', $event_data['recipient_types'], true ) ) {
                    $output[ $event_key ]['sms_enabled'] = ! empty( $input[ $event_key ]['sms_enabled'] );
                    $output[ $event_key ]['sms_body'] = isset( $input[ $event_key ]['sms_body'] ) ? sanitize_textarea_field( wp_unslash( $input[ $event_key ]['sms_body'] ) ) : '';
                }
            }
        }
        return $output;
    }

    public function sanitize_reminder_settings( $input ) {
        $output = get_option( Constants::OPTION_REMINDER_SETTINGS, [] );
        if ( ! is_array( $input ) ) {
            return $output;
        }
        $output['enabled'] = isset( $input['enabled'] ) ? 1 : 0;
        $output['lead_time_value'] = isset( $input['lead_time_value'] ) ? max( 1, absint( $input['lead_time_value'] ) ) : 24;
        $allowed_units = [ 'hours', 'days' ];
        $output['lead_time_unit'] = isset( $input['lead_time_unit'] ) && in_array( $input['lead_time_unit'], $allowed_units, true ) ? $input['lead_time_unit'] : 'hours';
        return $output;
    }

    public function sanitize_admin_recipients( $input ) {
        $emails_raw = isset( $input ) ? sanitize_textarea_field( wp_unslash( $input ) ) : '';
        $emails = array_map( 'trim', explode( ',', $emails_raw ) );
        return implode( ',', array_filter( $emails, 'is_email' ) );
    }

    public function sanitize_sms_credentials( $input ) {
        if ( ! current_user_can( 'manage_options' ) ) {
            return get_option( Constants::OPTION_SMS_CREDENTIALS, [] );
        }
        $output = get_option( Constants::OPTION_SMS_CREDENTIALS, [] );
        if ( ! is_array( $input ) ) {
            return $output;
        }
        $output['twilio_sid'] = isset( $input['twilio_sid'] ) ? sanitize_text_field( $input['twilio_sid'] ) : '';
        $output['twilio_token'] = isset( $input['twilio_token'] ) ? sanitize_text_field( $input['twilio_token'] ) : '';
        $output['twilio_from'] = isset( $input['twilio_from'] ) ? sanitize_text_field( $input['twilio_from'] ) : '';
        return $output;
    }

    public function sanitize_webhooks( $input ) {
        if ( ! current_user_can( 'manage_options' ) ) {
            return get_option( Constants::OPTION_WEBHOOKS, [] );
        }
        $output = [];
        if ( ! is_array( $input ) ) {
            return [];
        }
        foreach ( $input as $webhook ) {
            if ( empty( $webhook['url'] ) || ! filter_var( $webhook['url'], FILTER_VALIDATE_URL ) ) {
                continue;
            }
            $output[] = [
                'enabled' => ! empty( $webhook['enabled'] ),
                'url'     => esc_url_raw( $webhook['url'] ),
                'events'  => isset( $webhook['events'] ) && is_array( $webhook['events'] ) ? array_map( 'sanitize_key', $webhook['events'] ) : [],
            ];
        }
        return $output;
    }
}