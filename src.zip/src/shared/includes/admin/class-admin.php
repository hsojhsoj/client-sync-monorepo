<?php
/**
 * File: src/shared/includes/admin/class-admin.php -> client-sync/includes/admin/class-admin.php
 * The admin-specific functionality of the plugin.
 *
 * This file defines the plugin name, version, and registers all hooks for the admin area.
 * This class coordinates various manager classes to handle specific responsibilities.
 *
 * UPDATED: Added HIPAA Compliance settings tab with setup guide and configuration options.
 *
 * @package    ClientSync
 * @subpackage ClientSync/Admin
 */

namespace DependentMedia\ClientSync\Admin;

use DependentMedia\ClientSync\Core\Database_Manager;
use DependentMedia\ClientSync\Services\FormRenderer;
use DependentMedia\ClientSync\Admin\Asset_Manager;
use DependentMedia\ClientSync\Admin\Settings_Manager;
use DependentMedia\ClientSync\Admin\Form_Handler;
use DependentMedia\ClientSync\Admin\Menu_Manager;
use DependentMedia\ClientSync\Constants;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Admin {

	private $plugin_name;
	private $version;
	private $db_manager;

	public function __construct( string $plugin_name, string $version, Database_Manager $db_manager ) {
		$this->plugin_name = $plugin_name;
		$this->version     = $version;
		$this->db_manager  = $db_manager;
	}

	public function register_hooks() {
		$asset_manager    = new Asset_Manager( $this->plugin_name, $this->version, $this->db_manager );
		$settings_manager = new Settings_Manager();
		$form_handler     = new Form_Handler( $this->db_manager );
		$menu_manager     = new Menu_Manager( $this );

		$asset_manager->register_hooks();
		$settings_manager->register_hooks();
		$form_handler->register_hooks();
		add_action( 'admin_init', [ '\DependentMedia\ClientSync\Admin\Onboarding_Wizard', 'handle_post_on_init' ] );

		add_action( 'admin_menu', [ $menu_manager, 'register_menus' ], 10 );
		add_action( 'admin_menu', [ $menu_manager, 'modify_and_reorder_submenu' ], 99 );
		add_action( 'admin_menu', [ $this, 'setup_wizard_page' ] );
		add_action( 'admin_init', [ $this, 'handle_activation_redirect' ] );

		// Hook format is load-{parent_slug}_page_{menu_slug}
		add_action( 'load-client-sync_page_clisyc-available-slots-list', [ $this, 'add_available_slots_screen_options' ] );
		add_action( 'load-client-sync_page_clisyc-calendars', [ $this, 'add_calendars_page_help_tabs' ] );
		
		add_filter( 'set-screen-option', [ $this, 'set_available_slots_screen_option' ], 10, 3 );
		add_action( 'wp_ajax_clisyc_reset_convert_tz_detection', [ $this, 'ajax_reset_convert_tz_detection' ] );
		add_action( 'admin_post_clisyc_export_report', [ $this, 'handle_export_report_to_csv' ] );
		add_filter( 'parent_file', [ $this, 'fix_admin_menu_highlight' ] );
		add_action( 'admin_footer', [ $this, 'render_global_icon_picker_modal' ] );

		// HIPAA Compliance settings registration
		add_action( 'admin_init', [ $this, 'register_hipaa_settings' ] );

		// HIPAA Audit Logs menu and export handler
		add_action( 'admin_menu', [ $this, 'register_audit_logs_menu' ], 20 );
		add_action( 'admin_post_clisyc_export_audit_logs', [ $this, 'handle_audit_log_export' ] );
	}

	/**
	 * Registers HIPAA compliance settings for the WordPress Settings API.
	 *
	 * These settings are used in the HIPAA Compliance tab of the Settings page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register_hipaa_settings() {
		// HIPAA Mode toggle (database-based, less secure than wp-config.php constant)
		register_setting(
			'clisyc_hipaa_settings_group',
			Constants::OPTION_HIPAA_MODE,
			[
				'type'              => 'boolean',
				'default'           => false,
				'sanitize_callback' => 'rest_sanitize_boolean',
			]
		);

		// Audit log retention period (HIPAA requires minimum 6 years = 2190 days)
		register_setting(
			'clisyc_hipaa_settings_group',
			Constants::OPTION_AUDIT_LOG_RETENTION,
			[
				'type'              => 'integer',
				'default'           => 2555, // 7 years default
				'sanitize_callback' => [ $this, 'sanitize_audit_retention_days' ],
			]
		);

		// Anonymize data in external calendar sync
		register_setting(
			'clisyc_hipaa_settings_group',
			'clisyc_anonymize_external_sync',
			[
				'type'              => 'boolean',
				'default'           => true,
				'sanitize_callback' => 'rest_sanitize_boolean',
			]
		);
	}

	/**
	 * Sanitizes the audit log retention days setting.
	 *
	 * Enforces HIPAA minimum of 6 years (2190 days) and maximum of 20 years (7300 days).
	 *
	 * @since 1.0.0
	 * @param mixed $value The value to sanitize.
	 * @return int The sanitized retention period in days.
	 */
	public function sanitize_audit_retention_days( $value ): int {
		$value = absint( $value );
		// Enforce HIPAA minimum of 6 years (2190 days)
		// Maximum of 20 years (7300 days) to prevent unreasonable values
		return max( 2190, min( 7300, $value ) );
	}

	public function render_dimensions_page() {
		require_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-dimensions-page.php';
	}

	public function render_settings_page() {
		// Handle Google OAuth Callback.
		// Nonce verification is not possible here as this is an OAuth redirect from Google's servers.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callback from external service.
		if ( isset( $_GET['action'] ) && 'google_oauth_callback' === sanitize_text_field( wp_unslash( $_GET['action'] ) ) && isset( $_GET['code'], $_GET['state'] ) ) {
			if ( class_exists( '\ClientSyncPro\Services\Google_Sync_Service' ) ) {
				$sync_service = new \ClientSyncPro\Services\Google_Sync_Service();
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callback from external service.
				$oauth_code  = sanitize_text_field( wp_unslash( $_GET['code'] ) );
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- OAuth callback from external service.
				$oauth_state = sanitize_text_field( wp_unslash( $_GET['state'] ) );
				$result      = $sync_service->handle_oauth_callback( $oauth_code, $oauth_state );

				if ( is_wp_error( $result ) ) {
					// Display error and stop.
					echo '<div class="notice notice-error"><p><strong>' . esc_html__( 'Google Sync Error:', 'client-sync' ) . '</strong> ' . esc_html( $result->get_error_message() ) . '</p></div>';
					return;
				} else {
					// Redirect to the Employee CPT edit screen of the user who just connected.
					$decoded_state = json_decode( base64_decode( $oauth_state ), true );
					$user_id       = $decoded_state['user_id'] ?? 0;
					if ( $user_id && ( $employee_post_id = get_user_meta( $user_id, 'clisyc_employee_post_id', true ) ) ) {
						set_transient( 'clisyc_admin_feedback', [ 'message' => 'Successfully connected to Google Calendar for ' . $result['email'] ], 30 );
						wp_safe_redirect( get_edit_post_link( $employee_post_id, 'raw' ) );
						exit;
					}
				}
			}
		}

		// UPDATED: Split 'styles' into 'appearance' and 'behavior', added 'hipaa' tab
		$tabs = [
			'setup'         => __( 'Setup Checklist', 'client-sync' ),
			'directions'    => __( 'Directions', 'client-sync' ),
			'appearance'    => __( 'Appearance', 'client-sync' ),      // Visual styling, colors
			'behavior'      => __( 'Behavior', 'client-sync' ),        // Booking rules, links
			'notifications' => __( 'Notifications', 'client-sync' ),
			'payments'      => __( 'Payments', 'client-sync' ),
			'automation'    => __( 'Automation', 'client-sync' ),
			'integrations'  => __( 'Integrations', 'client-sync' ),
			'import_export' => __( 'Import / Export', 'client-sync' ),
			'shortcodes'    => __( 'Shortcodes', 'client-sync' ),
			'hipaa'         => __( 'HIPAA Compliance', 'client-sync' ), // NEW: HIPAA setup guide & settings
		];

		// Nonce verification is not required here as we are just reading a URL parameter for navigation.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$unslashed_get = wp_unslash( $_GET );
		
		// UPDATED: Default to 'appearance' instead of 'styles'
		$active_tab = isset( $unslashed_get['tab'] ) && array_key_exists( $unslashed_get['tab'], $tabs ) ? sanitize_key( $unslashed_get['tab'] ) : 'appearance';
		?>
<div class="wrap">
		<h1><?php esc_html_e( 'Client Sync Settings', 'client-sync' ); ?></h1>
		<?php
		// This is the correct place to show settings update messages for a tabbed page.
		// It will catch the redirect from options.php and display the "Settings saved." notice.
		settings_errors();
		?>

		<nav class="nav-tab-wrapper">
			<?php foreach ( $tabs as $slug => $label ) : ?>
				<a href="?page=clisyc-settings&tab=<?php echo esc_attr( $slug ); ?>" class="nav-tab <?php echo $active_tab === $slug ? 'nav-tab-active' : ''; ?>">
					<?php echo esc_html( $label ); ?>
				</a>
			<?php endforeach; ?>
		</nav>
		<div class="tab-content" style="margin-top: 1em;">
			<?php
			switch ( $active_tab ) {
				case 'notifications':
					include_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-notifications-page.php';
					break;
				case 'payments':
					include_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-payments-page.php';
					break;
				case 'automation':
					include_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-automation-page.php';
					break;
				case 'integrations':
					include_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-integrations-page.php';
					break;
				case 'import_export':
					include_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-import-export-page.php';
					break;
				case 'directions':
					include_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-directions-page.php';
					break;
				case 'setup':
					$this->render_getting_started_page();
					break;
				case 'shortcodes':
					include_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-shortcodes-page.php';
					break;
				// NEW: Appearance tab (visual styling, colors, calendar display)
				case 'appearance':
					include_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-appearance-page.php';
					break;
				// NEW: Behavior tab (booking rules, links, self-service, spam)
				case 'behavior':
					include_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-behavior-page.php';
					break;
				// NEW: HIPAA Compliance tab (setup guide, encryption status, audit settings)
				case 'hipaa':
					include_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-hipaa-settings-page.php';
					break;
				default:
					// Fallback to appearance if unknown tab
					include_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-appearance-page.php';
					break;
			}
			?>
		</div>
	</div>
	<?php
}

public function setup_wizard_page() {
	add_submenu_page( 'options.php', __( 'Client Sync Setup Wizard', 'client-sync' ), __( 'Setup Wizard', 'client-sync' ), 'manage_options', 'clisyc-setup', [ $this, 'render_wizard_page_wrapper' ] );
}

public function render_wizard_page_wrapper() {
	require_once clisyc_PLUGIN_DIR . 'includes/admin/class-onboarding-wizard.php';
	$wizard = new \DependentMedia\ClientSync\Admin\Onboarding_Wizard();
	$wizard->render_wizard_page();
}

public function handle_activation_redirect() {
	if ( get_transient( 'clisyc_activation_redirect' ) ) {
		delete_transient( 'clisyc_activation_redirect' );

		// This is a standard WordPress check on activation and does not require a nonce.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! wp_doing_ajax() && ! isset( $_GET['activate-multi'] ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=clisyc-setup' ) );
			exit;
		}
	}
}

public function render_dashboard_page() {
	$setup_milestones = $this->get_setup_milestones_status();

	$dashboard_stats = [
		'appointments_this_month' => $this->get_appointments_count_for_period('this_month'),
		'income_this_month'       => $this->get_income_for_period('this_month'),
		'upcoming_appointments'   => $this->get_appointments_count_for_period('upcoming'),
		'total_clients'           => $this->_get_total_clients(),
		'busiest_day'             => $this->_get_busiest_day_of_week(),
	];

	// New data for the view
	$upcoming_appointments_widget_data = $this->_get_upcoming_appointments( 5 );
	$bookings_this_week_chart_data     = $this->_get_appointments_this_week_by_day();
	$busiest_services_chart_data       = $this->_get_busiest_services_data( 5 );

	// Localize script data for the new charts
	wp_localize_script(
		'clisyc-admin-dashboard-charts',
		'clisycDashboardData',
		[
			'bookingsThisWeek' => $bookings_this_week_chart_data,
			'busiestServices'  => $busiest_services_chart_data,
			'l10n'             => [
				'bookings' => __( 'Bookings', 'client-sync' ),
			],
		]
	);

	$system_status_checks = $this->get_system_status_checks();

	require_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-dashboard-page.php';
}

public function render_getting_started_page() {
	// This processing logic is now moved to a dedicated admin-post handler
	// to ensure reliability. The page's only job is to display the view.
	$setup_milestones = $this->get_setup_milestones_status();
	require_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-getting-started-page.php';
}

public function render_custom_fields_page() {
	$client_custom_fields      = get_option( Constants::OPTION_CUSTOM_FIELDS, [] );
	$client_field_order        = get_option( Constants::OPTION_CUSTOM_FIELDS_ORDER, [] );
	$appointment_custom_fields = get_option( Constants::OPTION_APPOINTMENT_FIELDS, [] );
	$appointment_field_order   = get_option( 'clisyc_appointment_custom_fields_order', [] );
	$dimension_fields          = get_option( Constants::OPTION_DIMENSION_FIELDS, [] );

	// Reading the 'cf_tab' GET parameter is for displaying the correct navigational tab, a non-state-changing action.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$unslashed_get = wp_unslash( $_GET );
	$active_tab    = isset( $unslashed_get['cf_tab'] ) ? sanitize_key( $unslashed_get['cf_tab'] ) : 'clients-cf';
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Custom Fields', 'client-sync' ); ?></h1>
		<p><?php esc_html_e( 'Add custom fields to store extra information about your clients or appointments.', 'client-sync' ); ?></p>
		
		<?php
		$feedback = get_transient( 'clisyc_custom_field_feedback' );
		if ( $feedback && is_array( $feedback ) && ! empty( $feedback['message'] ) ) {
			$notice_class = 'error' === ( $feedback['type'] ?? 'success' ) ? 'notice-error' : 'notice-success';
			echo '<div class="notice ' . esc_attr( $notice_class ) . ' is-dismissible"><p>' . wp_kses_post( $feedback['message'] ) . '</p></div>';
			delete_transient( 'clisyc_custom_field_feedback' );
		}
		?>
		
		<nav class="nav-tab-wrapper">
			<a href="?page=clisyc-custom-fields&cf_tab=clients-cf" class="nav-tab <?php echo $active_tab === 'clients-cf' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Client Fields', 'client-sync' ); ?></a>
			<a href="?page=clisyc-custom-fields&cf_tab=appointments-cf" class="nav-tab <?php echo $active_tab === 'appointments-cf' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Booking Fields', 'client-sync' ); ?></a>
			<a href="?page=clisyc-custom-fields&cf_tab=dimensions-cf" class="nav-tab <?php echo $active_tab === 'dimensions-cf' ? 'nav-tab-active' : ''; ?>"><?php esc_html_e( 'Dimension Attributes', 'client-sync' ); ?></a>
		</nav>
		<div class="clisyc-fields-tab-content" style="margin-top: 1em;">
			<div class="clisyc-fields-tab-pane" style="display: <?php echo $active_tab === 'clients-cf' ? 'block' : 'none'; ?>;"><?php include clisyc_PLUGIN_DIR . 'includes/admin/views/template-parts/part-client-custom-fields.php'; ?></div>
			<div class="clisyc-fields-tab-pane" style="display: <?php echo $active_tab === 'appointments-cf' ? 'block' : 'none'; ?>;"><?php include clisyc_PLUGIN_DIR . 'includes/admin/views/template-parts/part-appointment-custom-fields.php'; ?></div>
			<div class="clisyc-fields-tab-pane" style="display: <?php echo $active_tab === 'dimensions-cf' ? 'block' : 'none'; ?>;"><?php include clisyc_PLUGIN_DIR . 'includes/admin/views/template-parts/part-dimension-custom-fields.php'; ?></div>
		</div>
	</div>
	<?php
}

public function render_calendars_page() {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading for non-state-changing tab navigation.
	$unslashed_get = wp_unslash( $_GET );
	$default_tab   = 'appointment-calendar';
	$current_tab   = isset( $unslashed_get['tab'] ) ? sanitize_key( $unslashed_get['tab'] ) : $default_tab;

	$tabs = [
		'appointment-calendar' => __( 'Appointment Calendar', 'client-sync' ),
		'master-schedule'      => __( 'Master Schedule', 'client-sync' ),
		'time-slots'           => __( 'Manage Time Slots', 'client-sync' ),
		'blocked-periods'      => __( 'Global Blocked Periods', 'client-sync' ),
		'timeline'             => __( 'Timeline Overview', 'client-sync' ),
	];

	if ( ! array_key_exists( $current_tab, $tabs ) ) {
		$current_tab = $default_tab;
	}
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Calendars & Availability', 'client-sync' ); ?></h1>
		<nav class="nav-tab-wrapper">
			<?php foreach ( $tabs as $slug => $label ) : ?>
				<a href="?page=clisyc-calendars&tab=<?php echo esc_attr( $slug ); ?>" class="nav-tab <?php echo $current_tab === $slug ? 'nav-tab-active' : ''; ?>">
					<?php echo esc_html( $label ); ?>
				</a>
			<?php endforeach; ?>
		</nav>
		<div class="tab-content" style="margin-top: 1em;">
			<?php
			$template_parts = [
				'appointment-calendar' => clisyc_PLUGIN_DIR . 'includes/admin/views/template-parts/part-appointment-calendar.php',
				'master-schedule'      => clisyc_PLUGIN_DIR . 'includes/admin/views/template-parts/part-master-schedule.php',
				'time-slots'           => clisyc_PLUGIN_DIR . 'includes/admin/views/template-parts/part-manage-time-slots.php',
				'blocked-periods'      => clisyc_PLUGIN_DIR . 'includes/admin/views/template-parts/part-blocked-periods.php',
				'timeline'             => clisyc_PLUGIN_DIR . 'includes/admin/views/template-parts/part-timeline-overview.php',
			];

			if ( isset( $template_parts[ $current_tab ] ) ) {
				include_once $template_parts[ $current_tab ];
			}
			?>
		</div>
	</div>
	<?php
}

public function render_blocked_periods_page() {
	require_once clisyc_PLUGIN_DIR . 'includes/admin/views/template-parts/part-blocked-periods.php';
}

public function render_available_slots_list_page() {
	require_once clisyc_PLUGIN_DIR . 'includes/admin/list-tables/class-available-slots-list-table.php';
	require_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-available-slots-list-page.php';
}

public function render_reports_page() {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading for non-state-changing report filtering.
	$unslashed_get = wp_unslash( $_GET );
	
	$today = wp_date( 'Y-m-d' );
	$start_of_year = wp_date( 'Y-01-01' );

	$start_date_filter = isset( $unslashed_get['start_date'] ) && $unslashed_get['start_date'] ? sanitize_text_field( $unslashed_get['start_date'] ) : $start_of_year;
	$end_date_filter = isset( $unslashed_get['end_date'] ) && $unslashed_get['end_date'] ? sanitize_text_field( $unslashed_get['end_date'] ) : $today;

	if ( strtotime( $end_date_filter ) < strtotime( $start_date_filter ) ) {
		$end_date_filter = $start_date_filter;
	}

	$appointments_per_month_raw = $this->get_appointments_per_month_data_for_report( $start_date_filter, $end_date_filter );
	$appointments_by_status_raw = $this->get_appointments_by_status_data_for_report( $start_date_filter, $end_date_filter );
	$popular_times_raw = $this->get_popular_times_data_for_report( $start_date_filter, $end_date_filter );
	$popular_days_raw = $this->get_popular_days_data_for_report( $start_date_filter, $end_date_filter );

	$appointments_per_month = []; foreach ($appointments_per_month_raw['labels'] as $i => $label) { $appointments_per_month[$label] = $appointments_per_month_raw['data'][$i]; }
	$appointments_by_status = []; foreach ($appointments_by_status_raw['labels'] as $i => $label) { $appointments_by_status[$label] = $appointments_by_status_raw['data'][$i]; }
	$popular_times = [];          foreach ($popular_times_raw['labels'] as $i => $label) { $popular_times[$label] = $popular_times_raw['data'][$i]; }
	$popular_days = [];           foreach ($popular_days_raw['labels'] as $i => $label) { $popular_days[$label] = $popular_days_raw['data'][$i]; }
	
	wp_localize_script('clisyc-admin-reports', 'clisycReportsData', [
		'appointmentsPerMonth' => $appointments_per_month_raw,
		'appointmentsByStatus' => $appointments_by_status_raw,
		'popularTimes'         => $popular_times_raw,
		'popularDays'          => $popular_days_raw,
		'l10n' => [
			'numberOfAppointments'      => __('Number of Appointments', 'client-sync'),
			'appointmentsPerMonthTitle' => __('Appointments per Month', 'client-sync'),
			'appointmentsByStatusTitle' => __('Appointments by Status', 'client-sync'),
			'popularTimesTitle'         => __('Popular Appointment Times', 'client-sync'),
			'popularDaysTitle'          => __('Popular Days of the Week', 'client-sync'),
		]
	]);
	require_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-reports-page.php';
}

public function render_testing_page() {
	require_once clisyc_PLUGIN_DIR . 'includes/admin/views/view-testing-page.php';
}

public function render_global_icon_picker_modal() {
	$screen = get_current_screen();
	if ( ! $screen || ! in_array( $screen->id, [ 'client-sync_page_clisyc-dimensions', 'client-sync_page_clisyc-custom-fields' ], true ) ) {
		return;
	}
	?>
	<div id="clisyc-global-icon-picker-modal" title="<?php esc_attr_e( 'Choose an Icon', 'client-sync' ); ?>" style="display:none;">
		<nav class="nav-tab-wrapper" style="margin-bottom: 1em;">
			<a href="#clisyc-icon-tab-fa" class="nav-tab nav-tab-active" data-icon-set="fa"><?php esc_html_e( 'Font Awesome', 'client-sync' ); ?></a>
			<a href="#clisyc-icon-tab-dashicons" class="nav-tab" data-icon-set="dashicons"><?php esc_html_e( 'Dashicons', 'client-sync' ); ?></a>
		</nav>
		<div class="clisyc-icon-picker-controls">
			<input type="search" id="clisyc-global-icon-picker-search" placeholder="<?php esc_attr_e( 'Search icons...', 'client-sync' ); ?>" class="widefat">
		</div>
		<div id="clisyc-global-icon-picker-grid" class="clisyc-icon-picker-grid"></div>
	</div>

	<?php // ================== START: THE FIX ================== ?>
	<script type="text/javascript">
		jQuery(document).ready(function($) {
			// This code now runs AFTER the modal HTML is on the page.
			if (typeof ClisycGlobalIconPicker !== 'undefined' && typeof clisycIconPickerData !== 'undefined') {
				console.log('[DEBUG] Initializing Global Icon Picker from footer script...');
				ClisycGlobalIconPicker.init(clisycIconPickerData.icons);
			} else {
				console.error('[DEBUG] Could not initialize Global Icon Picker: Picker object or data is missing.');
			}
		});
	</script>
	<?php // =================== END: THE FIX =================== ?>
	<?php
}

/**
 * Adds contextual help tabs to the Calendars & Availability page.
 */
public function add_calendars_page_help_tabs() {
    $screen = get_current_screen();
    if ( ! $screen ) {
        return;
    }

    // Tab 1: Overview of Global Blocks
    $screen->add_help_tab(
        [
            'id'      => 'clisyc_global_blocks_overview',
            'title'   => __( 'Global Blocked Periods', 'client-sync' ),
            'content' => '<p><strong>' . __( 'What are Global Blocked Periods?', 'client-sync' ) . '</strong></p>' .
                    '<p>' . __( 'These are "Master Rules" used for broad date ranges where your entire business is closed (e.g., Christmas, New Years, or a week for renovations).', 'client-sync' ) . '</p>' .
                    '<p>' . __( 'When a date falls within a Global Blocked Period, the system will mark the entire day as unavailable on the frontend, regardless of what is in your time slot database.', 'client-sync' ) . '</p>',
        ]
    );

    // Tab 2: Comparison (The explanation you requested)
    $screen->add_help_tab(
        [
            'id'      => 'clisyc_blocking_comparison',
            'title'   => __( 'Understanding Blocking', 'client-sync' ),
            'content' => '<p><strong>' . __( 'Two Ways to Block Time', 'client-sync' ) . '</strong></p>' .
                    '<p>' . __( 'Client Sync uses two different methods for blocking time. It is important to choose the right one for your situation:', 'client-sync' ) . '</p>' .
                    '<ul>' .
                    '<li><strong>' . __( 'Global Blocked Periods (Current Tab):', 'client-sync' ) . '</strong> ' . 
                        __( 'Used for broad date ranges (days/weeks). These live in your Settings and act as a master override for the whole system.', 'client-sync' ) . '</li>' .
                    '<li><strong>' . __( 'Slot-Level Blocks (Manage Time Slots Tab):', 'client-sync' ) . '</strong> ' . 
                        __( 'Used for granular, one-off changes (specific hours). For example, if you need to block off 2:00 PM to 3:00 PM next Tuesday for a personal appointment.', 'client-sync' ) . '</li>' .
                    '</ul>' .
                    '<p><em>' . __( 'Note: Granular blocks created on the "Manage Time Slots" calendar will not appear here as date ranges, as they are stored as individual units in the slot database.', 'client-sync' ) . '</em></p>',
        ]
    );

    // Add Help Sidebar
    $screen->set_help_sidebar(
        '<p><strong>' . __( 'Need more help?', 'client-sync' ) . '</strong></p>' .
        '<p><a href="https://dependentmedia.com/" target="_blank">' . __( 'Documentation', 'client-sync' ) . '</a></p>'
    );
}

public function add_available_slots_screen_options() {
	$screen = get_current_screen();
	if ( ! $screen ) {
		return;
	}

	// 1. Add Screen Option (Pagination)
	$option = 'per_page';
	$args   = [
		'label'   => __( 'Slots per page', 'client-sync' ),
		'default' => 20,
		'option'  => 'clisyc_slots_per_page',
	];
	add_screen_option( $option, $args );

	// 2. Add Help Tabs
	$screen->add_help_tab(
		[
			'id'      => 'clisyc_slots_overview',
			'title'   => __( 'Overview', 'client-sync' ),
			'content' => '<p>' . __( 'This screen provides a raw database view of every single time slot generated by the system. It includes both "Available" slots (which can be booked) and "Blocked" slots (admin overrides).', 'client-sync' ) . '</p>' .
					'<p>' . __( 'You can use this screen to audit your schedule or bulk-delete specific slots if necessary.', 'client-sync' ) . '</p>',
		]
	);

	$screen->add_help_tab(
		[
			'id'      => 'clisyc_slots_filtering',
			'title'   => __( 'Filtering', 'client-sync' ),
			'content' => '<p>' . __( 'Use the filters above the table to narrow down the list:', 'client-sync' ) . '</p>' .
					'<ul>' .
					'<li><strong>' . __( 'Dates:', 'client-sync' ) . '</strong> ' . __( 'Select a start and end date to see slots within a specific range.', 'client-sync' ) . '</li>' .
					'<li><strong>' . __( 'Dimensions:', 'client-sync' ) . '</strong> ' . __( 'Filter slots that belong to a specific Service, Staff member, or Room.', 'client-sync' ) . '</li>' .
					'</ul>',
		]
	);

	$screen->add_help_tab(
		[
			'id'      => 'clisyc_slots_cleanup',
			'title'   => __( 'Cleanup', 'client-sync' ),
			'content' => '<p>' . __( '<strong>Cleanup Past Available Slots:</strong> This button deletes all "Available" slots in the past. It does NOT delete Blocked slots or Booked Appointments (which are stored separately). This is useful for keeping your database size small.', 'client-sync' ) . '</p>',
		]
	);

	// Add Help Sidebar
	$screen->set_help_sidebar(
		'<p><strong>' . __( 'For more information:', 'client-sync' ) . '</strong></p>' .
		'<p><a href="https://dependentmedia.com/" target="_blank">' . __( 'Documentation', 'client-sync' ) . '</a></p>' .
		'<p><a href="https://dependentmedia.com/support/" target="_blank">' . __( 'Support', 'client-sync' ) . '</a></p>'
	);
}

public function set_available_slots_screen_option( $status, $option, $value ) {
	if ( 'clisyc_slots_per_page' === $option ) { return $value; } return $status;
}

public function ajax_reset_convert_tz_detection() {
	check_ajax_referer('clisyc_reset_convert_tz_nonce', 'security');
	if (!current_user_can('manage_options')) {
		wp_send_json_error(['message' => __('Permission denied.', 'client-sync')]);
	}
	update_option(Constants::OPTION_MYSQL_CONVERT_TZ, 'unknown');
	delete_transient('clisyc_convert_tz_notice_shown');
	wp_send_json_success([
		'message' => __('MySQL timezone conversion auto-detection status has been reset. The plugin will attempt to re-evaluate on the next relevant calendar operation.', 'client-sync'),
		'new_status' => __('Unknown', 'client-sync')
	]);
}

private function get_appointments_count_for_period(string $period): int {
	$date_query_args = [];
	$current_time = current_time('timestamp');

	if ('this_month' === $period) {
		$date_query_args = [ 'key' => 'clisyc_appointment_date', 'value' => [ wp_date('Y-m-01', $current_time), wp_date('Y-m-t', $current_time), ], 'compare' => 'BETWEEN', 'type' => 'DATE', ];
	} elseif ('upcoming' === $period) {
		 $date_query_args = [ 'key' => 'clisyc_appointment_date', 'value' => wp_date('Y-m-d', $current_time), 'compare' => '>=', 'type' => 'DATE', ];
	} else { return 0; }

	$args = [ 'post_type' => Constants::POST_TYPE_APPOINTMENT, 'post_status' => ['publish', Constants::STATUS_CONFIRMED, 'clisyc_paid_on_day', 'wc-completed', 'wc-processing'], 'posts_per_page' => -1, 'fields' => 'ids', 'meta_query' => [$date_query_args], 'no_found_rows' => true, 'update_post_meta_cache' => false, 'update_post_term_cache' => false, ];
	
	$query = new \WP_Query($args);
	return $query->post_count;
}

private function get_income_for_period(string $period): string {
	if (!class_exists('WooCommerce')) { return 'N/A'; }

	global $wpdb;
	$start_date_str = ''; $end_date_str = '';
	if ('this_month' === $period) { $start_date_str = wp_date('Y-m-01 00:00:00'); $end_date_str = wp_date('Y-m-t 23:59:59'); } else { return wc_price(0); }
	
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Complex aggregate query for dashboard reporting.
	$total_income = (float) $wpdb->get_var( $wpdb->prepare( "SELECT SUM(pm.meta_value) FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id WHERE p.post_type = 'shop_order' AND p.post_status IN ('wc-processing', 'wc-completed') AND pm.meta_key = '_order_total' AND EXISTS (SELECT 1 FROM {$wpdb->prefix}woocommerce_order_items oi JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim ON oi.order_item_id = oim.order_item_id WHERE oi.order_id = p.ID AND oim.meta_key = '_clisyc_appointment_id' AND oim.meta_value != '' AND oim.meta_value IS NOT NULL) AND p.post_date_gmt >= %s AND p.post_date_gmt <= %s", gmdate('Y-m-d H:i:s', strtotime($start_date_str)), gmdate('Y-m-d H:i:s', strtotime($end_date_str)) ) );
	return wc_price($total_income);
}

private function get_appointments_per_month_data_for_report( ?string $start_date = null, ?string $end_date = null ): array {
	global $wpdb;
	$relevant_statuses = [ 'publish', 'confirmed', 'clisyc_paid_on_day', 'wc-completed', 'wc-processing' ];
	$status_placeholders = implode( ', ', array_fill( 0, count( $relevant_statuses ), '%s' ) );
	
	$date_where = '';
	$prepare_args = [ '%Y-%m-%d', '%Y-%m' ];
	$prepare_args = array_merge($prepare_args, $relevant_statuses);

	if ( $start_date && $end_date ) {
		$date_where = 'AND pm.meta_value BETWEEN %s AND %s';
		$prepare_args[] = $start_date;
		$prepare_args[] = $end_date;
	}

	$post_type = Constants::POST_TYPE_APPOINTMENT;
	$sql = "
		SELECT DATE_FORMAT(STR_TO_DATE(pm.meta_value, %s), %s) as month_year, COUNT(p.ID) as count
		FROM {$wpdb->posts} p
			JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
			WHERE p.post_type = '{$post_type}'
		AND p.post_status IN ({$status_placeholders})
		AND pm.meta_key = 'clisyc_appointment_date'
		{$date_where}
		AND STR_TO_DATE(pm.meta_value, %s) IS NOT NULL
		GROUP BY month_year
		ORDER BY STR_TO_DATE(pm.meta_value, %s) ASC
	";

	$prepare_args[] = '%Y-%m-%d';
	$prepare_args[] = '%Y-%m-%d';

	// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Dynamic SQL for reporting; query is prepared.
	$results = $wpdb->get_results( $wpdb->prepare( $sql, ...$prepare_args ), ARRAY_A );

	$labels = []; $data = [];
	if ( $results ) { foreach ( $results as $row ) {
		try { $date_obj = \DateTime::createFromFormat( 'Y-m', $row['month_year'] ); $labels[] = $date_obj ? $date_obj->format( 'M Y' ) : $row['month_year']; } catch ( \Exception $e ) { $labels[] = $row['month_year']; }
		$data[] = (int) $row['count']; }
	} return ['labels' => $labels, 'data' => $data];
}

private function get_appointments_by_status_data_for_report( ?string $start_date = null, ?string $end_date = null ): array {
	$args = [ 'post_type' => Constants::POST_TYPE_APPOINTMENT, 'posts_per_page' => -1, 'fields' => 'post_status' ];
	if ($start_date && $end_date) {
		$args['meta_query'] = [[ 'key' => 'clisyc_appointment_date', 'value' => [$start_date, $end_date], 'compare' => 'BETWEEN', 'type' => 'DATE' ]];
	}

	$query = new \WP_Query($args);
	$status_counts = array_count_values($query->posts);

	$labels = []; $data = [];
	if ( $status_counts ) {
		$all_statuses_obj = get_post_stati( [ 'show_in_admin_all_list' => true ], 'objects' );
		$custom_statuses = [ 'clisyc_pending_payment', 'clisyc_paid_on_day', 'clisyc_failed_on_day' ];
		foreach ( $custom_statuses as $key ) { if ( ! isset( $all_statuses_obj[ $key ] ) && ($s = get_post_status_object( $key )) ) { $all_statuses_obj[ $key ] = $s; }}
		foreach ( $status_counts as $key => $count ) { if ( $count > 0 ) {
			$labels[] = isset( $all_statuses_obj[ $key ] ) ? $all_statuses_obj[ $key ]->label : ucfirst( str_replace( 'clisyc_', '', $key ) );
			$data[] = (int) $count; }}
	} return ['labels' => $labels, 'data' => $data];
}

private function get_popular_times_data_for_report( ?string $start_date = null, ?string $end_date = null ): array {
	$meta_query = [ [ 'key' => Constants::META_TIME_SLOT, 'compare' => 'EXISTS' ] ];
	if ($start_date && $end_date) {
		$meta_query[] = [ 'key' => 'clisyc_appointment_date', 'value' => [$start_date, $end_date], 'compare' => 'BETWEEN', 'type' => 'DATE' ];
	}
	
	$times_count = [];
	$query = new \WP_Query( [ 'post_type' => Constants::POST_TYPE_APPOINTMENT, 'post_status' => 'any', 'posts_per_page' => -1, 'meta_query' => $meta_query, 'fields' => 'ids' ] );
	if ( $query->have_posts() ) { foreach ( $query->posts as $id ) { if ( ($slot = get_post_meta( $id, Constants::META_TIME_SLOT, true )) && preg_match( '/T(\d{2}:\d{2})/', $slot, $m ) ) { $times_count[ $m[1] ] = ($times_count[ $m[1] ] ?? 0) + 1; }}}
	arsort( $times_count ); $limited = array_slice($times_count, 0, 15, true);
	return ['labels' => array_keys($limited), 'data' => array_values($limited)];
}

private function get_popular_days_data_for_report( ?string $start_date = null, ?string $end_date = null ): array {
	$meta_query = [ [ 'key' => 'clisyc_appointment_date', 'compare' => 'EXISTS' ] ];
	if ($start_date && $end_date) {
		 $meta_query[] = [ 'key' => 'clisyc_appointment_date', 'value' => [$start_date, $end_date], 'compare' => 'BETWEEN', 'type' => 'DATE' ];
	}

	$days = [ 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' ]; $counts = array_fill_keys( $days, 0 );
	$query = new \WP_Query( [ 'post_type' => Constants::POST_TYPE_APPOINTMENT, 'post_status' => 'any', 'posts_per_page' => -1, 'meta_query' => $meta_query, 'fields' => 'ids' ] );
	if ( $query->have_posts() ) { foreach ( $query->posts as $id ) { if ( ($date = get_post_meta( $id, 'clisyc_appointment_date', true )) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) { try { $counts[ (new \DateTime( $date ))->format( 'l' ) ]++; } catch ( \Exception $e ) {} }}}
	$ordered_labels = []; $ordered_data = []; $start_week = get_option( 'start_of_week', 0 );
	for ( $i = 0; $i < 7; $i++ ) { $day_name = $days[ ($start_week + $i) % 7 ]; $ordered_labels[] = $day_name; $ordered_data[] = $counts[ $day_name ]; }
	return ['labels' => $ordered_labels, 'data' => $ordered_data];
}

private function get_setup_milestones_status(): array {
	$completed_milestones_option = get_option(Constants::OPTION_SETUP_MILESTONES, []);
	if (!is_array($completed_milestones_option)) $completed_milestones_option = [];

	$registry = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
	$custom_types = get_option(Constants::OPTION_CUSTOM_DIMENSION_TYPES, []);
	$enabled_dimensions = array_filter($registry['dimensions'] ?? [], fn($dim) => !empty($dim['enabled']));
	
	$milestones = [];

	// --- Core Milestones (Always present) ---
	$milestones['timezone_configured'] = [
		'label' => __('Confirm Website Timezone', 'client-sync'),
		'is_complete' => !empty(get_option('timezone_string')),
		'next_step_label' => __('Set Timezone', 'client-sync'),
		'next_step_url' => admin_url('options-general.php#timezone_string'),
		'settings_url' => admin_url('options-general.php#timezone_string'),
		'description' => __('A city-based timezone is required for accurate scheduling.', 'client-sync')
	];
	$milestones['pages_created'] = [
		'label' => __('Create Essential Pages', 'client-sync'),
		'is_complete' => $this->check_essential_pages_exist(),
		'next_step_label' => __('Create Pages (Wizard)', 'client-sync'),
		'next_step_url' => admin_url('admin.php?page=clisyc-setup&step=pages'),
		'settings_url' => admin_url('edit.php?post_type=page'),
		'description' => __('The booking calendar and client account pages are needed.', 'client-sync')
	];
	$milestones['frontend_pages_set'] = [
		'label'           => __( 'Configure Frontend Pages', 'client-sync' ),
		'is_complete'     => $this->check_frontend_pages_set(),
		'next_step_label' => __( 'Configure Pages', 'client-sync' ),
		'next_step_url'   => admin_url( 'admin.php?page=clisyc-settings&tab=behavior#clisyc_frontend_links_section' ),
		'settings_url'    => admin_url( 'admin.php?page=clisyc-settings&tab=behavior#clisyc_frontend_links_section' ),
		'description'     => __( 'Select the pages containing your booking, account, and appointment detail shortcodes in the settings.', 'client-sync' ),
	];

	// --- DYNAMICALLY GENERATED MILESTONES ---
	if (!empty($enabled_dimensions)) {
		$primary_dimension_slug = null;
		foreach ($enabled_dimensions as $slug => $settings) {
			if (!empty($settings['primary'])) {
				$primary_dimension_slug = $slug;
				break;
			}
		}

		// 1. Build milestones for CREATING items in each enabled dimension
		foreach ($enabled_dimensions as $slug => $settings) {
			$cpt_obj = get_post_type_object($slug);
			if (!$cpt_obj) continue;

			$singular_name = $custom_types[$slug]['singular'] ?? $cpt_obj->labels->singular_name;
			$plural_name   = $custom_types[$slug]['plural'] ?? $cpt_obj->labels->name;

			$milestones["create_{$slug}"] = [
				/* translators: %s: The singular name of a content type, like "Service" or "Practitioner". */
				'label' => sprintf( __( 'Create your first %s', 'client-sync' ), $singular_name ),
				'is_complete' => (int) wp_count_posts($slug)->publish > 0,
				/* translators: %s: The singular name of a content type, like "Service" or "Practitioner". */
				'next_step_label' => sprintf( __( 'Add New %s', 'client-sync' ), $singular_name ),
				'next_step_url' => admin_url('post-new.php?post_type=' . $slug),
				'settings_url' => admin_url('edit.php?post_type=' . $slug),
				/* translators: %s: The plural name of a content type, like "Services". */
				'description' => sprintf( __( 'Create at least one item for your "%s" dimension.', 'client-sync' ), $plural_name ),
			];
		}

		// 2. Add the availability milestone for the PRIMARY dimension
		if ($primary_dimension_slug && ($cpt_obj = get_post_type_object($primary_dimension_slug))) {
			$primary_singular_name = $custom_types[$primary_dimension_slug]['singular'] ?? $cpt_obj->labels->singular_name;

			$milestones['availability_set'] = [
				/* translators: %s: The singular name of the primary content type, like "Service". */
				'label' => sprintf( __( 'Set Availability for a %s', 'client-sync' ), $primary_singular_name ),
				'is_complete' => $this->check_standard_availability_set($primary_dimension_slug),
				'next_step_label' => __('Set Availability', 'client-sync'),
				'next_step_url' => admin_url('edit.php?post_type=' . $primary_dimension_slug),
				'settings_url' => admin_url('edit.php?post_type=' . $primary_dimension_slug),
				'description' => __('Define your typical weekly working hours for at least one of your primary dimension items.', 'client-sync')
			];
		}

		// 3. Build milestones for CREATING RELATIONSHIPS
		$relationships = $registry['relationships'] ?? [];
		foreach ($relationships as $parent_slug => $child_slugs) {
			if (empty($enabled_dimensions[$parent_slug])) continue;
			
			$parent_cpt = get_post_type_object($parent_slug);
			if (!$parent_cpt) continue;
			$parent_plural_name = $custom_types[$parent_slug]['plural'] ?? $parent_cpt->labels->name;
			
			foreach ((array) $child_slugs as $child_slug) {
				if (empty($enabled_dimensions[$child_slug])) continue;

				$child_cpt = get_post_type_object($child_slug);
				if (!$child_cpt) continue;
				$child_plural_name = $custom_types[$child_slug]['plural'] ?? $child_cpt->labels->name;
				
				$milestones["link_{$parent_slug}_to_{$child_slug}"] = [
					/* translators: 1: The plural name of a parent content type (e.g., "Practitioners"). 2: The plural name of a child content type (e.g., "Services"). */
					'label' => sprintf( __( 'Link %1$s to %2$s', 'client-sync' ), $parent_plural_name, $child_plural_name ),
					'is_complete' => $this->check_relationship_exists($parent_slug, $child_slug),
					/* translators: %s: The plural name of a content type, like "Practitioners". */
					'next_step_label' => sprintf( __( 'Edit %s', 'client-sync' ), $parent_plural_name ),
					'next_step_url' => admin_url('edit.php?post_type=' . $parent_slug),
					'settings_url' => admin_url('edit.php?post_type=' . $parent_slug),
					/* translators: 1: The lowercase plural name of a parent content type (e.g., "practitioners"). 2: The lowercase plural name of a child content type (e.g., "services"). */
					'description' => sprintf( __( 'You must link your %1$s to the %2$s they are associated with.', 'client-sync' ), strtolower( $parent_plural_name ), strtolower( $child_plural_name ) ),
				];
			}
		}
	}

	// --- Optional / Manual Milestones ---
	$last_run_timestamp = get_option( Constants::OPTION_LAST_MAINTENANCE_TS );
	$is_cron_running_recently = false;
	$cron_status_text         = '<em>' . __( 'The automation task has not run yet.', 'client-sync' ) . '</em>';

	if ( $last_run_timestamp ) {
		$current_utc_time      = current_time( 'timestamp', true );
		$time_since_last_run = $current_utc_time - $last_run_timestamp;

		if ( $time_since_last_run <= ( 20 * MINUTE_IN_SECONDS ) ) {
			$is_cron_running_recently = true;
		}

		/* translators: %s: Human-readable time difference like "5 minutes". */
		$cron_status_text = sprintf( esc_html__( 'Last run: %s ago.', 'client-sync' ), esc_html( human_time_diff( $last_run_timestamp, $current_utc_time ) ) );
	}


	$milestones['auto_generation_enabled'] = [
		'label' => __( 'Enable Automatic Slot Generation', 'client-sync' ),
		'is_complete' => (bool) get_option( Constants::OPTION_AUTO_GEN_ENABLED, false ),
		'is_optional' => true,
		'next_step_label' => __( 'Configure Automation', 'client-sync' ),
		'next_step_url' => admin_url( 'admin.php?page=clisyc-settings&tab=automation' ),
		'settings_url' => admin_url( 'admin.php?page=clisyc-settings&tab=automation' ),
		'description' => __( 'Allow the plugin to automatically create future time slots based on your schedules.', 'client-sync' ),
	];

	$milestones['woocommerce_setup'] = [
		'label'           => __( 'Configure Payments (Optional)', 'client-sync' ),
		'is_complete'     => ! get_option( Constants::OPTION_WC_ENABLED, false ) || ( get_option( Constants::OPTION_WC_ENABLED, false ) && absint( get_option( Constants::OPTION_WC_PRODUCT_ID, 0 ) ) > 0 ),
		'is_optional'     => true,
		'next_step_label' => __( 'Set Up Payments (Wizard)', 'client-sync' ),
		'next_step_url'   => admin_url( 'admin.php?page=clisyc-setup&step=payment' ),
		'settings_url'    => admin_url( 'admin.php?page=clisyc-settings&tab=payments' ),
		'description'     => __( 'Integrate with WooCommerce to charge for appointments.', 'client-sync' ),
	];
	$milestones['notifications_reviewed'] = [
		'label'                => __( 'Review Notifications', 'client-sync' ),
		'is_complete'          => ! empty( $completed_milestones_option['notifications_reviewed'] ),
		'is_manual_completion' => true,
		'next_step_label'      => __( 'Review Emails', 'client-sync' ),
		'next_step_url'        => admin_url( 'admin.php?page=clisyc-settings&tab=notifications' ),
		'settings_url'         => admin_url( 'admin.php?page=clisyc-settings&tab=notifications' ),
		'description'          => __( 'Check the default email templates for booking confirmations and reminders.', 'client-sync' ),
	];
	$milestones['server_cron_recommended'] = [
		'label'                => __( 'Optimize Automation (Recommended)', 'client-sync' ),
		'is_complete'          => ! empty( $completed_milestones_option['server_cron_recommended'] ) || $is_cron_running_recently,
		'is_manual_completion' => true,
		'is_optional'          => true,
		'next_step_label'      => __( 'Learn about Server Cron', 'client-sync' ),
		'next_step_url'        => admin_url( 'admin.php?page=clisyc-settings&tab=automation' ),
		'settings_url'         => admin_url( 'admin.php?page=clisyc-settings&tab=automation' ),
		'description'          => __( 'For best reliability, set up a server-level cron job.', 'client-sync' ) . ' ' . $cron_status_text,
	];

	// Recalculate completion status
	$new_completed_status = $completed_milestones_option;
	foreach ($milestones as $key => $details) {
		if (!($details['is_manual_completion'] ?? false)) $new_completed_status[$key] = $details['is_complete'];
	}
	if ($new_completed_status !== $completed_milestones_option) update_option(Constants::OPTION_SETUP_MILESTONES, $new_completed_status);

	return $milestones;
}

private function check_essential_pages_exist(): bool {
	$booking_page_slug = 'booking-calendar';
	$account_page_slug = 'my-account';
	$details_page_slug = get_option( Constants::OPTION_APPOINTMENT_VIEW_SLUG, 'appointment-details' );

	$booking_page = get_page_by_path( $booking_page_slug );
	$account_page = get_page_by_path( $account_page_slug );
	$details_page = get_page_by_path( $details_page_slug );

	return ( $booking_page && $account_page && $details_page );
}

private function check_frontend_pages_set(): bool {
	$booking_page_id = (int) get_option( Constants::OPTION_BOOKING_PAGE_ID, 0 );
	$details_page_id = (int) get_option( Constants::OPTION_APPOINTMENT_VIEW_PAGE, 0 );
	$search_page_id  = (int) get_option( Constants::OPTION_SEARCH_RESULTS_PAGE, 0 );

	// Complete if Details page is set AND (Booking Page OR Search Results Page is set)
	return $details_page_id > 0 && ( $booking_page_id > 0 || $search_page_id > 0 );
}

private function check_standard_availability_set( string $cpt_slug ): bool {
	$args = [
		'post_type'      => $cpt_slug,
		'post_status'    => 'publish',
		'posts_per_page' => 1,
		'fields'         => 'ids',
		'meta_query'     => [
			[
				'key'     => Constants::META_SCHEDULE,
				'compare' => 'EXISTS',
			],
			[
				'key'     => Constants::META_SCHEDULE,
				'compare' => '!=',
				'value'   => '',
			],
		],
		'no_found_rows' => true,
		'cache_results' => false,
	];
	
	$found_posts = get_posts( $args );

	if ( empty( $found_posts ) ) {
		return false;
	}

	$schedule_json = get_post_meta($found_posts[0], Constants::META_SCHEDULE, true);
	if ( empty( $schedule_json ) ) {
		return false;
	}

	$schedule_data = json_decode($schedule_json, true);
	if ( !is_array($schedule_data) || empty($schedule_data['templates']) ) {
		return false;
	}

	foreach ($schedule_data['templates'] as $template) {
		if (is_array($template)) {
			foreach ($template as $day_data) {
				if (!empty($day_data['slots'])) {
					return true;
				}
			}
		}
	}

	return false;
}

private function check_relationship_exists( string $parent_slug, string $child_slug ): bool {
	global $wpdb;
	$rels_table = $this->db_manager->get_relationships_table_name();

	// Table name is safe; it comes from an internal method that returns a prefixed table name.
	// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$sql = "SELECT 1 FROM {$rels_table} WHERE parent_object_type = %s AND child_object_type = %s LIMIT 1";
	// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
	$result = $wpdb->get_var( $wpdb->prepare( $sql, $parent_slug, $child_slug ) );

	return ! empty( $result );
}

public function handle_export_report_to_csv() {
	if ( ! isset( $_POST['clisyc_export_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['clisyc_export_nonce'] ) ), 'clisyc_export_report_nonce' ) ) {
		wp_die( 'Security check failed.' );
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Permission denied.' );
	}

	$post_data = wp_unslash( $_POST );
	$report_id = sanitize_key( $post_data['report_id'] ?? '' );
	$start_date = isset( $post_data['start_date'] ) && $post_data['start_date'] ? sanitize_text_field( $post_data['start_date'] ) : null;
	$end_date = isset( $post_data['end_date'] ) && $post_data['end_date'] ? sanitize_text_field( $post_data['end_date'] ) : null;

	$data = [];
	$headers = [];
	$filename = 'clisyc-report-' . $report_id . '-' . wp_date( 'Y-m-d' ) . '.csv';

	switch ( $report_id ) {
		case 'appointments_per_month':
			$headers = [ 'Month', 'Count' ];
			$raw_data = $this->get_appointments_per_month_data_for_report( $start_date, $end_date );
			$data = array_map( null, $raw_data['labels'], $raw_data['data'] );
			break;
		case 'appointments_by_status':
			$headers = [ 'Status', 'Count' ];
			$raw_data = $this->get_appointments_by_status_data_for_report( $start_date, $end_date );
			 $data = array_map( null, $raw_data['labels'], $raw_data['data'] );
			break;
		case 'popular_times':
			$headers = [ 'Time Slot', 'Count' ];
			$raw_data = $this->get_popular_times_data_for_report( $start_date, $end_date );
			 $data = array_map( null, $raw_data['labels'], $raw_data['data'] );
			break;
		case 'popular_days':
			$headers = [ 'Day of Week', 'Count' ];
			$raw_data = $this->get_popular_days_data_for_report( $start_date, $end_date );
			 $data = array_map( null, $raw_data['labels'], $raw_data['data'] );
			break;
		default:
			wp_die( 'Invalid report ID.' );
	}

	header( 'Content-Type: text/csv' );
	header( 'Content-Disposition: attachment; filename=' . $filename );

	$output = fopen( 'php://output', 'w' );
	fputcsv( $output, $headers );
	foreach ( $data as $row ) {
		fputcsv( $output, $row );
	}
	// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- This is a false positive. We are writing to the php://output stream, not a file on the server filesystem.
	fclose( $output );
	exit;
}

public function fix_admin_menu_highlight( $parent_file ) {
	global $current_screen, $pagenow;

	// Reading the 'page' GET parameter is for menu highlighting only, a non-state-changing action.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';

	if ( 'admin.php' === $pagenow && in_array( $page, [ 'clisyc-calendars', 'clisyc-blocked-periods' ], true ) ) {
		return 'clisyc-settings';
	}
	
	if ( 'admin.php' === $pagenow && 'clisyc-setup' === $page ) {
		return 'clisyc-settings';
	}

	$registry        = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
	$dimension_slugs = array_keys( $registry['dimensions'] ?? [] );
	$plugin_cpts     = array_merge( [ Constants::POST_TYPE_APPOINTMENT ], $dimension_slugs );

	if ( $current_screen && in_array( $current_screen->post_type, $plugin_cpts, true ) ) {
		return 'client-sync';
	}

	return $parent_file;
}

private function get_system_status_checks(): array {
	$status_checks = [];

	// Timezone check remains the same
	if ( empty( get_option( 'timezone_string' ) ) ) {
		$status_checks['timezone'] = [
			'status'      => 'critical',
			'message'     => __( 'Your website timezone is set to a manual UTC offset. This can cause scheduling errors. Please set a city-based timezone for accurate booking.', 'client-sync' ),
			'action_url'  => admin_url( 'options-general.php#timezone_string' ),
			'action_text' => __( 'Set Timezone', 'client-sync' ),
		];
	}

	// --- DYNAMIC PRIMARY DIMENSION CHECK ---
	$registry        = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
	$primary_dim_slug  = null;
	$primary_dim_label = __( 'Primary Dimension', 'client-sync' );

	if ( ! empty( $registry['dimensions'] ) ) {
		foreach ( $registry['dimensions'] as $slug => $settings ) {
			if ( ! empty( $settings['enabled'] ) && ! empty( $settings['primary'] ) ) {
				$primary_dim_slug = $slug;
				$cpt_object       = get_post_type_object( $slug );
				if ( $cpt_object ) {
					$primary_dim_label = $cpt_object->labels->singular_name;
				}
				break;
			}
		}
	}

	if ( ! $primary_dim_slug ) {
		$status_checks['no_primary_dimension'] = [
			'status'      => 'critical',
			'message'     => __( 'No "Primary Dimension" is set. The system does not know which schedule to use. Please enable a dimension and set it as primary.', 'client-sync' ),
			'action_url'  => admin_url( 'admin.php?page=clisyc-dimensions&tab=setup' ),
			'action_text' => __( 'Configure Dimensions', 'client-sync' ),
		];
	} elseif ( post_type_exists( $primary_dim_slug ) ) {
		$item_count_obj = wp_count_posts( $primary_dim_slug );
		$item_count     = is_object( $item_count_obj ) ? ( $item_count_obj->publish ?? 0 ) : 0;

		if ( 0 === $item_count ) {
			$status_checks['no_primary_items'] = [
				'status'      => 'warning',
				/* translators: %s: The singular name of the primary dimension (e.g., "Service"). */
				'message'     => sprintf( __( 'No "%s" items have been created yet. You must have at least one for clients to book.', 'client-sync' ), $primary_dim_label ),
				'action_url'  => admin_url( 'post-new.php?post_type=' . $primary_dim_slug ),
				/* translators: %s: The singular name of the primary dimension (e.g., "Service"). */
				'action_text' => sprintf( __( 'Create First %s', 'client-sync' ), $primary_dim_label ),
			];
		} else {
			$db_manager        = new \DependentMedia\ClientSync\Core\Database_Manager();
			$future_slot_dates = $db_manager->get_distinct_available_slot_dates();

			if ( empty( $future_slot_dates ) ) {
				$status_checks['no_availability'] = [
					'status'      => 'notice',
					'message'     => __( 'You have items to book, but no future availability has been generated. Clients will not be able to book any appointments.', 'client-sync' ),
					'action_url'  => admin_url( 'admin.php?page=clisyc-calendars&tab=time-slots' ),
					'action_text' => __( 'Generate Time Slots', 'client-sync' ),
				];
			}
		}
	}
	// --- END: DYNAMIC PRIMARY DIMENSION CHECK ---

	// --- START: NEW AND IMPROVED WOOCOMMERCE CHECK ---
	if ( get_option( Constants::OPTION_WC_ENABLED, false ) && class_exists( 'WooCommerce' ) && $primary_dim_slug ) {
		$primary_items = get_posts(
			[
				'post_type'      => $primary_dim_slug,
				'posts_per_page' => -1,
				'post_status'    => 'publish',
				'fields'         => 'ids',
			]
		);

		$unlinked_item_count = 0;
		foreach ( $primary_items as $item_id ) {
			$product_id = get_post_meta( $item_id, Constants::META_WC_PRODUCT_ID, true );
			if ( empty( $product_id ) || ! is_numeric( $product_id ) || $product_id <= 0 ) {
				$unlinked_item_count++;
			}
		}

		if ( $unlinked_item_count > 0 ) {
			$cpt_object   = get_post_type_object( $primary_dim_slug );
			$plural_label = $cpt_object ? $cpt_object->labels->name : __( 'Primary Items', 'client-sync' );

			/* translators: 1: Number of unlinked items. 2: Plural name of the primary dimension (e.g., "Room Types"). */
			$message_format = _n(
				'WooCommerce payments are enabled, but %1$d %2$s is not linked to a product and cannot be booked with a payment.',
				'WooCommerce payments are enabled, but %1$d %2$s are not linked to a product and cannot be booked with a payment.',
				$unlinked_item_count,
				'client-sync'
			);

			/* translators: %s: Plural name of the primary dimension (e.g., "Room Types"). */
			$link_text = sprintf( __( 'Link %s', 'client-sync' ), $plural_label );

			$status_checks['wc_product_linking'] = [
				'status'      => 'notice',
				'message'     => sprintf(
					$message_format,
					$unlinked_item_count,
					strtolower( $plural_label )
				),
				'action_url'  => admin_url( 'edit.php?post_type=' . $primary_dim_slug ),
				'action_text' => $link_text,
			];
		}
	}
	// --- END: NEW AND IMPROVED WOOCOMMERCE CHECK ---

	return apply_filters( 'clisyc_dashboard_status_checks', $status_checks );
}

/**
 * Recursively scans the plugin directory and generates a text-based file tree.
 *
 * @param string $path The absolute path to the directory to scan.
 * @return string The formatted file and folder tree.
 */
public static function generate_file_tree(string $path): string {
    $output = basename( rtrim( $path, '/' ) ) . "/\n";

    $iterator = new \RecursiveIteratorIterator(
        new \RecursiveDirectoryIterator( $path, \RecursiveDirectoryIterator::SKIP_DOTS ),
        \RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ( $iterator as $fileInfo ) {
        $depth = $iterator->getDepth();
        $indent = str_repeat( '|   ', $depth ) . '|-- ';
        $output .= $indent . $fileInfo->getFilename() . "\n";
    }

    return $output;
}

/**
 * Retrieves the total number of users with client roles.
 * @return int
 */
private function _get_total_clients(): int {
	$client_roles = apply_filters( 'clisyc_client_user_roles', [ 'subscriber', 'customer' ] );
	$user_count = count_users();
	$total_clients = 0;
	foreach ( $client_roles as $role ) {
		if ( isset( $user_count['avail_roles'][ $role ] ) ) {
			$total_clients += $user_count['avail_roles'][ $role ];
		}
	}
	return $total_clients;
}

/**
 * Retrieves the busiest day of the week based on all-time appointment data.
 * @return string
 */
private function _get_busiest_day_of_week(): string {
	$popular_days_raw = $this->get_popular_days_data_for_report( null, null );
	if ( empty( $popular_days_raw['data'] ) ) {
		return __( 'N/A', 'client-sync' );
	}
	$max_value = max( $popular_days_raw['data'] );
	$day_index = array_search( $max_value, $popular_days_raw['data'], true );

	return $popular_days_raw['labels'][ $day_index ] ?? __( 'N/A', 'client-sync' );
}

/**
 * Retrieves a specified number of upcoming appointments for the dashboard widget.
 * @param int $limit The number of appointments to retrieve.
 * @return array
 */
private function _get_upcoming_appointments( int $limit = 5 ): array {
	$upcoming = [];
	$now_utc  = current_time( 'mysql', 1 );

	$args = [
		'post_type'      => Constants::POST_TYPE_APPOINTMENT,
		'posts_per_page' => $limit,
		'post_status'    => [ 'publish', Constants::STATUS_CONFIRMED, 'clisyc_paid_on_day', 'wc-processing', 'wc-completed' ],
		'meta_key'       => Constants::META_TIME_SLOT,
		'orderby'        => 'meta_value',
		'order'          => 'ASC',
		'meta_query'     => [
			[
				'key'     => Constants::META_TIME_SLOT,
				'value'   => $now_utc,
				'compare' => '>=',
				'type'    => 'DATETIME',
			],
		],
	];

	$query = new \WP_Query( $args );

	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) {
			$query->the_post();
			$post_id    = get_the_ID();
			$client     = get_user_by( 'id', get_post_field( 'post_author' ) );
			$time_slot  = get_post_meta( $post_id, Constants::META_TIME_SLOT, true );
			$start_time = strtotime( $time_slot );

			$upcoming[] = [
				'id'           => $post_id,
				'title'        => get_the_title(),
				'client_name'  => $client ? $client->display_name : __( 'Unknown Client', 'client-sync' ),
				'date_time'    => wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $start_time ),
				'relative_time' => sprintf( '%s ago', human_time_diff( $start_time, current_time( 'timestamp' ) ) ),
				'edit_link'    => get_edit_post_link( $post_id ),
			];
		}
	}
	wp_reset_postdata();

	return $upcoming;
}

/**
 * Retrieves appointment counts for each of the last 7 days for a chart.
 * @return array
 */
private function _get_appointments_this_week_by_day(): array {
	global $wpdb;
	$labels = [];
	$data   = [];
	$start_of_week = (int) get_option( 'start_of_week', 0 );

	for ( $i = 6; $i >= 0; $i-- ) {
		$date           = new \DateTime( "-$i days", wp_timezone() );
		$labels[]       = $date->format( 'D, M j' ); // e.g., "Mon, Oct 28"
		$date_key       = $date->format( 'Y-m-d' );
		$data[ $date_key ] = 0;
	}

	$start_date_filter = ( new \DateTime( '-6 days', wp_timezone() ) )->format( 'Y-m-d' );
	$end_date_filter   = ( new \DateTime( 'now', wp_timezone() ) )->format( 'Y-m-d' );

	$post_type = Constants::POST_TYPE_APPOINTMENT;
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Dashboard widget requires fresh appointment data.
	$results = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT pm.meta_value as appt_date, COUNT(p.ID) as count
			FROM {$wpdb->posts} p
			JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
			WHERE p.post_type = '{$post_type}'
			AND p.post_status IN ('publish', 'confirmed', 'clisyc_paid_on_day', 'wc-completed', 'wc-processing')
			AND pm.meta_key = 'clisyc_appointment_date'
			AND pm.meta_value >= %s AND pm.meta_value <= %s
			GROUP BY pm.meta_value",
			$start_date_filter,
			$end_date_filter
		)
	);

	if ( $results ) {
		foreach ( $results as $row ) {
			if ( isset( $data[ $row->appt_date ] ) ) {
				$data[ $row->appt_date ] = (int) $row->count;
			}
		}
	}

	return [
		'labels' => $labels,
		'data'   => array_values( $data ),
	];
}

/**
 * Retrieves the busiest services (primary dimension items) for a chart.
 * @param int $limit The number of services to show.
 * @return array
 */
private function _get_busiest_services_data( int $limit = 5 ): array {
	global $wpdb;
	$registry         = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
	$primary_dim_slug = null;
	if ( ! empty( $registry['dimensions'] ) ) {
		foreach ( $registry['dimensions'] as $slug => $settings ) {
			if ( ! empty( $settings['primary'] ) ) {
				$primary_dim_slug = $slug;
				break;
			}
		}
	}

	if ( ! $primary_dim_slug ) {
		return [ 'labels' => [], 'data' => [] ];
	}

	$post_type = Constants::POST_TYPE_APPOINTMENT;
	$meta_key  = Constants::META_SLOT_DIMENSIONS;
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Complex query for dashboard chart; requires counting serialized meta values.
	$results = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT meta_value FROM {$wpdb->postmeta}
			WHERE meta_key = '{$meta_key}'
			AND post_id IN (
				SELECT ID FROM {$wpdb->posts}
				WHERE post_type = '{$post_type}'
				AND post_status IN ('publish', 'confirmed', 'clisyc_paid_on_day', 'wc-completed', 'wc-processing')
			)
			AND meta_value LIKE %s",
			'%"' . $wpdb->esc_like( $primary_dim_slug ) . '"%'
		)
	);

	$service_counts = [];
	if ( $results ) {
		foreach ( $results as $row ) {
			$dimensions = maybe_unserialize( $row->meta_value );
			if ( is_array( $dimensions ) && isset( $dimensions[ $primary_dim_slug ] ) ) {
				$service_id = (int) $dimensions[ $primary_dim_slug ];
				if ( $service_id > 0 ) {
					$service_counts[ $service_id ] = ( $service_counts[ $service_id ] ?? 0 ) + 1;
				}
			}
		}
	}

	arsort( $service_counts );
	$top_services = array_slice( $service_counts, 0, $limit, true );

	$labels = [];
	$data   = [];
	foreach ( $top_services as $service_id => $count ) {
		$labels[] = get_the_title( $service_id ) ?: "Service #{$service_id}";
		$data[]   = $count;
	}

	return [ 'labels' => $labels, 'data' => $data ];
	}

	// =========================================================================
	// HIPAA COMPLIANCE: Audit Logs Methods
	// =========================================================================

	/**
	 * Register the Audit Logs submenu page.
	 *
	 * This page is only visible to administrators and provides
	 * HIPAA-compliant audit log viewing capabilities.
	 *
	 * @return void
	 */
	public function register_audit_logs_menu() {
		add_submenu_page(
			'clisyc-dashboard',                              // Parent slug
			__( 'Audit Logs', 'client-sync' ),               // Page title
			__( 'Audit Logs', 'client-sync' ),               // Menu title
			'manage_options',                                 // Capability
			'clisyc-audit-logs',                             // Menu slug
			[ $this, 'render_audit_logs_page' ]              // Callback
		);
	}

	/**
	 * Render the Audit Logs admin page.
	 *
	 * @return void
	 */
	public function render_audit_logs_page() {
		// Check if the view file exists
		$view_file = \CLISYC_SHARED_DIR . 'includes/admin/views/view-audit-logs-page.php';
		
		if ( file_exists( $view_file ) ) {
			include $view_file;
		} else {
			echo '<div class="wrap"><h1>' . esc_html__( 'Audit Logs', 'client-sync' ) . '</h1>';
			echo '<div class="notice notice-error"><p>' . esc_html__( 'Audit logs view file not found.', 'client-sync' ) . '</p></div>';
			echo '</div>';
		}
	}

	/**
	 * Handle audit log export requests.
	 *
	 * Exports filtered audit logs to CSV or JSON format.
	 *
	 * @return void
	 */
	public function handle_audit_log_export() {
		// Check nonce
		if ( ! isset( $_POST['clisyc_audit_export_nonce'] ) || 
			 ! wp_verify_nonce( sanitize_key( $_POST['clisyc_audit_export_nonce'] ), 'clisyc_export_audit_logs' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'client-sync' ) );
		}
		
		// Check permission
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'client-sync' ) );
		}

		// Check if Audit Logger exists
		if ( ! class_exists( '\DependentMedia\ClientSync\Services\Audit_Logger' ) ) {
			wp_die( esc_html__( 'Audit Logger service not available.', 'client-sync' ) );
		}
		
		$audit_logger = \DependentMedia\ClientSync\Services\Audit_Logger::get_instance();
		
		// Build query from filters
		$query_args = [
			'per_page'    => 999999, // Get all matching
			'action'      => isset( $_POST['action_filter'] ) ? sanitize_key( $_POST['action_filter'] ) : '',
			'object_type' => isset( $_POST['object_type'] ) ? sanitize_key( $_POST['object_type'] ) : '',
			'user_id'     => isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0,
			'date_from'   => isset( $_POST['date_from'] ) ? sanitize_text_field( $_POST['date_from'] ) : '',
			'date_to'     => isset( $_POST['date_to'] ) ? sanitize_text_field( $_POST['date_to'] ) : '',
			'search'      => isset( $_POST['search'] ) ? sanitize_text_field( $_POST['search'] ) : '',
		];
		
		$result = $audit_logger->get_logs( $query_args );
		$logs = $result['logs'];
		
		// Log this export action
		\DependentMedia\ClientSync\Services\Audit_Logger::log(
			'export',
			'audit_log',
			0,
			[ 'export_count' => count( $logs ), 'filters' => $query_args ]
		);
		
		$format = isset( $_POST['export_format'] ) ? sanitize_key( $_POST['export_format'] ) : 'csv';
		$filename = 'audit-logs-' . gmdate( 'Y-m-d-His' );
		
		if ( $format === 'json' ) {
			header( 'Content-Type: application/json' );
			header( 'Content-Disposition: attachment; filename="' . $filename . '.json"' );
			echo wp_json_encode( $logs, JSON_PRETTY_PRINT );
			exit;
		}
		
		// CSV export
		header( 'Content-Type: text/csv' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '.csv"' );
		
		$output = fopen( 'php://output', 'w' );
		
		// Header row
		fputcsv( $output, [
			'Log ID',
			'Timestamp (UTC)',
			'User ID',
			'Username',
			'Action',
			'Object Type',
			'Object ID',
			'IP Address',
			'Request URI',
			'Metadata',
		] );
		
		// Data rows
		foreach ( $logs as $log ) {
			fputcsv( $output, [
				$log['log_id'],
				$log['created_at'],
				$log['user_id'],
				$log['username'],
				$log['action'],
				$log['object_type'],
				$log['object_id'],
				$log['ip_address'],
				$log['request_uri'],
				$log['meta_data'],
			] );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		fclose( $output );
		exit;
	}
}