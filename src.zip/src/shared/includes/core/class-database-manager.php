<?php
/**
 * File: src/shared/includes/core/class-database-manager.php
 * Manages all direct database interactions for Client Sync custom tables.
 *
 * UPDATED: Added HIPAA audit logs table support.
 *
 * @package    ClientSync
 * @subpackage ClientSync/Core
 */

namespace DependentMedia\ClientSync\Core;

use DependentMedia\ClientSync\Constants;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Database_Manager {

	const CACHE_GROUP = 'clisyc_slots';

	public function get_slots_table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'clisyc_time_slots';
	}

	public function get_dimensions_table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'clisyc_slot_dimensions';
	}

	public function get_relationships_table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'clisyc_relationships';
	}

	public function get_bookings_table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'clisyc_bookings';
	}

	public function get_graph_nodes_table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'clisyc_graph_nodes';
	}

	/**
	 * Get the audit logs table name.
	 *
	 * @return string The fully-prefixed audit logs table name.
	 */
	public function get_audit_logs_table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'clisyc_audit_logs';
	}

	private function _build_exact_dimension_match_sql_and_params( array $dimensions, string $alias ): array {
		if ( empty( $dimensions ) ) {
			return [ 'sql' => '', 'params' => [] ];
		}

		$dims_table = $this->get_dimensions_table_name();
		$params     = [];
		$dim_count  = count( $dimensions );

		$subquery_parts = [];
		foreach ( $dimensions as $key => $value ) {
			$subquery_parts[] = "(d.dimension_key = %s AND d.dimension_value = %s)";
			$params[]         = sanitize_key( $key );
			$params[]         = sanitize_text_field( $value );
		}

		// This SQL is built safely and will be part of a larger prepared statement.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is safe.
		$sql      = "{$alias}.slot_id IN (
            SELECT d.slot_id FROM {$dims_table} d
            WHERE " . implode( ' OR ', $subquery_parts ) . "
            GROUP BY d.slot_id
            HAVING COUNT(DISTINCT d.dimension_key) = %d
        )";
		$params[] = $dim_count;

		return [ 'sql' => $sql, 'params' => $params ];
	}

	public function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset_collate = $wpdb->get_charset_collate();

		$sql_slots = "CREATE TABLE " . $this->get_slots_table_name() . " (
			slot_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			start_time datetime NOT NULL,
			end_time datetime NOT NULL,
			is_block tinyint(1) NOT NULL DEFAULT 0,
			booking_count int(11) NOT NULL DEFAULT 0,
			PRIMARY KEY  (slot_id),
			KEY start_time (start_time)
		) $charset_collate;";

		$sql_dims = "CREATE TABLE " . $this->get_dimensions_table_name() . " (
            slot_id bigint(20) unsigned NOT NULL,
            dimension_key varchar(191) NOT NULL,
            dimension_value varchar(191) NOT NULL,
            PRIMARY KEY  (slot_id, dimension_key),
            KEY dimension_key_value (dimension_key, dimension_value)
        ) $charset_collate;";

		$sql_relationships = "CREATE TABLE " . $this->get_relationships_table_name() . " (
            relationship_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            parent_object_id bigint(20) unsigned NOT NULL,
            parent_object_type varchar(191) NOT NULL,
            child_object_id bigint(20) unsigned NOT NULL,
            child_object_type varchar(191) NOT NULL,
            PRIMARY KEY  (relationship_id),
			UNIQUE KEY unique_relationship (parent_object_id, child_object_id),
            KEY parent_child_idx (parent_object_id, child_object_type),
            KEY child_parent_idx (child_object_id, parent_object_type)
        ) $charset_collate;";

		$sql_bookings = "CREATE TABLE " . $this->get_bookings_table_name() . " (
            booking_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            slot_id bigint(20) unsigned NOT NULL,
            appointment_id bigint(20) unsigned NOT NULL,
            booking_time_utc datetime NOT NULL,
            PRIMARY KEY  (booking_id),
            KEY slot_id (slot_id),
            KEY appointment_id (appointment_id)
        ) $charset_collate;";

		$sql_graph_nodes = "CREATE TABLE " . $this->get_graph_nodes_table_name() . " (
			node_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			node_hash VARCHAR(255) NOT NULL,
			cpt_slug VARCHAR(191) NOT NULL,
			wp_post_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			node_type VARCHAR(50) NOT NULL,
			label VARCHAR(255) NOT NULL,
			parent_hash VARCHAR(255) DEFAULT NULL,
			last_updated DATETIME NOT NULL,
			PRIMARY KEY (node_id),
			UNIQUE KEY node_hash (node_hash),
			KEY cpt_slug (cpt_slug),
			KEY parent_hash (parent_hash)
		) $charset_collate;";

		dbDelta( $sql_slots );
		dbDelta( $sql_dims );
		dbDelta( $sql_relationships );
		dbDelta( $sql_bookings );
		dbDelta( $sql_graph_nodes );
		
		// =========================================================================
		// HIPAA COMPLIANCE: Create audit logs table
		// =========================================================================
		$this->create_audit_logs_table();
	}

	/**
	 * Create the HIPAA audit logs table.
	 *
	 * This table stores all PHI access and modification events as required
	 * by HIPAA regulations. Logs are immutable and retained for the
	 * configured retention period (default: 7 years).
	 *
	 * @return void
	 */
	public function create_audit_logs_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset_collate = $wpdb->get_charset_collate();

		$sql_audit_logs = "CREATE TABLE " . $this->get_audit_logs_table_name() . " (
			log_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			username VARCHAR(60) NOT NULL DEFAULT '',
			action VARCHAR(50) NOT NULL,
			object_type VARCHAR(50) NOT NULL,
			object_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			ip_address VARCHAR(45) NOT NULL DEFAULT '',
			user_agent VARCHAR(500) NOT NULL DEFAULT '',
			request_uri VARCHAR(2000) NOT NULL DEFAULT '',
			meta_data LONGTEXT,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (log_id),
			KEY idx_user_id (user_id),
			KEY idx_action (action),
			KEY idx_object (object_type, object_id),
			KEY idx_created_at (created_at),
			KEY idx_ip_address (ip_address)
		) $charset_collate;";

		dbDelta( $sql_audit_logs );
	}

	public function migrate_slots_from_option_to_table(): array {
		global $wpdb;
		$stats           = [
			'migrated' => 0,
			'skipped'  => 0,
			'errors'   => 0,
		];
		$old_slots_array = get_option( 'clisyc_available_time_slots' ); // This intentionally uses the OLD prefix for backward compatibility.
		if ( empty( $old_slots_array ) || ! is_array( $old_slots_array ) ) {
			return $stats;
		}

		$site_timezone = wp_timezone();
		$utc_timezone  = new \DateTimeZone( 'UTC' );
		$slots_table   = $this->get_slots_table_name();
		$dims_table    = $this->get_dimensions_table_name();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( 'START TRANSACTION' );
		foreach ( $old_slots_array as $slot_data ) {
			if ( ! is_array( $slot_data ) || empty( $slot_data['date'] ) || empty( $slot_data['start_time'] ) || empty( $slot_data['end_time'] ) ) {
				$stats['skipped']++;
				continue;
			}
			try {
				$start_dt_site = new \DateTime( $slot_data['date'] . ' ' . $slot_data['start_time'], $site_timezone );
				$end_dt_site   = new \DateTime( $slot_data['date'] . ' ' . $slot_data['end_time'], $site_timezone );

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				$insert_result = $wpdb->insert(
					$slots_table,
					[
						'start_time' => $start_dt_site->setTimezone( $utc_timezone )->format( 'Y-m-d H:i:s' ),
						'end_time'   => $end_dt_site->setTimezone( $utc_timezone )->format( 'Y-m-d H:i:s' ),
						'is_block'   => ( isset( $slot_data['is_block'] ) && true === $slot_data['is_block'] ) ? 1 : 0,
					],
					[ '%s', '%s', '%d' ]
				);
				if ( false === $insert_result ) {
					$stats['errors']++;
					continue;
				}
				$new_slot_id = $wpdb->insert_id;
				if ( ! empty( $slot_data['dimensions'] ) && is_array( $slot_data['dimensions'] ) ) {
					foreach ( $slot_data['dimensions'] as $key => $value ) {
						// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
						$wpdb->insert(
							$dims_table,
							[
								'slot_id'         => $new_slot_id,
								'dimension_key'   => sanitize_key( $key ),
								'dimension_value' => sanitize_text_field( $value ),
							],
							[ '%d', '%s', '%s' ]
						);
					}
				}
				$stats['migrated']++;
			} catch ( \Exception $e ) {
				$stats['errors']++;
			}
		}

		if ( $stats['errors'] > 0 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->query( 'ROLLBACK' );
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->query( 'COMMIT' );
			$this->clear_all_slot_cache();
		}

		return $stats;
	}

	public function query_slots( string $start_date_utc, string $end_date_utc, array $dimensions = [] ): array {
		global $wpdb;

		$dimensions_cache_part = ! empty( $dimensions ) ? http_build_query( $dimensions ) : '';
		$cache_key             = self::CACHE_GROUP . '_query_' . md5( $start_date_utc . $end_date_utc . $dimensions_cache_part );
		$cached_data           = get_transient( $cache_key );
		if ( false !== $cached_data ) {
			return $cached_data;
		}

		$slots_table      = $this->get_slots_table_name();
		$dims_table       = $this->get_dimensions_table_name();
		$final_sql_params = [ $start_date_utc, $end_date_utc ];
		$where_clauses    = [ 's.start_time >= %s', 's.start_time < %s' ];

		if ( ! empty( $dimensions ) ) {
			$dim_match_data = $this->_build_exact_dimension_match_sql_and_params( $dimensions, 's' );
			if ( ! empty( $dim_match_data['sql'] ) ) {
				$where_clauses[]  = $dim_match_data['sql'];
				$final_sql_params = array_merge( $final_sql_params, $dim_match_data['params'] );
			}
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where_clauses are built safely with placeholders.
		$sql = "SELECT s.slot_id, s.start_time, s.end_time, s.is_block, s.booking_count,
					   GROUP_CONCAT(DISTINCT CONCAT(d.dimension_key, ':::', d.dimension_value) SEPARATOR '|||') AS dimensions_concat
				FROM {$slots_table} s
				LEFT JOIN {$dims_table} d ON s.slot_id = d.slot_id
				WHERE " . implode( ' AND ', $where_clauses ) . '
				GROUP BY s.slot_id ORDER BY s.start_time ASC';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$results = $wpdb->get_results( $wpdb->prepare( $sql, ...$final_sql_params ), ARRAY_A );

		if ( empty( $results ) ) {
			set_transient( $cache_key, [], HOUR_IN_SECONDS );
			return [];
		}

		$processed_slots = [];
		foreach ( $results as $row ) {
			$dimensions_array = [];
			if ( ! empty( $row['dimensions_concat'] ) ) {
				$pairs = explode( '|||', $row['dimensions_concat'] );
				foreach ( $pairs as $pair ) {
					$parts = explode( ':::', $pair, 2 );
					if ( count( $parts ) === 2 ) {
						list( $key, $value )      = $parts;
						$dimensions_array[ $key ] = $value;
					}
				}
			}
			$processed_slots[] = [
				'slot_id'        => $row['slot_id'],
				'start_time_utc' => $row['start_time'],
				'end_time_utc'   => $row['end_time'],
				'is_block'       => (bool) $row['is_block'],
				'booking_count'  => (int) $row['booking_count'],
				'dimensions'     => $dimensions_array,
			];
		}
		set_transient( $cache_key, $processed_slots, HOUR_IN_SECONDS );
		return $processed_slots;
	}

	public function query_slots_with_combinations( string $start_date_utc, string $end_date_utc, array $dimensions ): array {
		global $wpdb;
		$slots_table = $this->get_slots_table_name();
		$dims_table  = $this->get_dimensions_table_name();

		if ( empty( $dimensions ) ) {
			return $this->query_slots( $start_date_utc, $end_date_utc, [] );
		}

		$valid_combinations = $this->get_valid_dimension_combinations( $dimensions );
		if ( empty( $valid_combinations ) ) {
			return []; // No valid paths exist between the selected filters.
		}

		$overall_where_clauses = [];
		$overall_params        = [];

		foreach ( $valid_combinations as $combo ) {
			if ( empty( $combo ) ) {
				continue;
			}

			$combo_match_data = $this->_build_exact_dimension_match_sql_and_params( $combo, 's' );
			if ( ! empty( $combo_match_data['sql'] ) ) {
				$overall_where_clauses[] = "( {$combo_match_data['sql']} )";
				$overall_params          = array_merge( $overall_params, $combo_match_data['params'] );
			}
		}

		if ( empty( $overall_where_clauses ) ) {
			return [];
		}

		$final_sql_params = [ $start_date_utc, $end_date_utc ];
		$final_sql_params = array_merge( $final_sql_params, $overall_params );

		$where_sql = 's.start_time >= %s AND s.start_time < %s AND (' . implode( ' OR ', $overall_where_clauses ) . ')';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names from internal source, where_sql built with placeholders.
		$sql = "SELECT s.slot_id, s.start_time, s.end_time, s.is_block, s.booking_count,
					   GROUP_CONCAT(DISTINCT CONCAT(d.dimension_key, ':::', d.dimension_value) SEPARATOR '|||') AS dimensions_concat
				FROM {$slots_table} s
				LEFT JOIN {$dims_table} d ON s.slot_id = d.slot_id
				WHERE {$where_sql}
				GROUP BY s.slot_id ORDER BY s.start_time ASC";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Query is prepared above.
		$results = $wpdb->get_results( $wpdb->prepare( $sql, ...$final_sql_params ), ARRAY_A );

		if ( empty( $results ) ) {
			return [];
		}

		$processed_slots = [];
		foreach ( $results as $row ) {
			$dimensions_array = [];
			if ( ! empty( $row['dimensions_concat'] ) ) {
				$pairs = explode( '|||', $row['dimensions_concat'] );
				foreach ( $pairs as $pair ) {
					$parts = explode( ':::', $pair, 2 );
					if ( count( $parts ) === 2 ) {
						list( $key, $value )      = $parts;
						$dimensions_array[ $key ] = $value;
					}
				}
			}
			$processed_slots[] = [
				'slot_id'        => $row['slot_id'],
				'start_time_utc' => $row['start_time'],
				'end_time_utc'   => $row['end_time'],
				'is_block'       => (bool) $row['is_block'],
				'booking_count'  => (int) $row['booking_count'],
				'dimensions'     => $dimensions_array,
			];
		}
		return $processed_slots;
	}

	/**
	 * Computes the Cartesian product of an associative array of arrays.
	 * Includes a safety circuit breaker to prevent memory exhaustion.
	 *
	 * @param array $arrays Input arrays, e.g., ['color' => ['red', 'blue'], 'size' => ['s', 'm']].
	 * @return array The Cartesian product, e.g., [['color' => 'red', 'size' => 's'], ...].
	 */
	private function cartesian_product( array $arrays ): array {
		if ( empty( $arrays ) ) {
			return [];
		}

		// SAFETY CHECK: Estimate total combinations before processing
		$estimated_count = 1;
		foreach ( $arrays as $arr ) {
			$estimated_count *= count( $arr );
		}

		// Hard limit to prevent PHP Memory Exhaustion (OOM)
		// If there are > 2000 combinations, the setup is too complex for runtime calc.
		if ( $estimated_count > 2000 ) {
			return [];
		}

		$result = [ [] ];
		foreach ( $arrays as $key => $values ) {
			$temp = [];
			foreach ( $result as $product ) {
				foreach ( $values as $value ) {
					$product[ $key ] = $value;
					$temp[]          = $product;
				}
			}
			if ( ! empty( $temp ) ) {
				$result = $temp;
			}
		}
		return $result;
	}

	/**
	 * Generates all valid combinations of selected dimensions based on their relationships.
	 *
	 * @param array $dimensions Selected dimensions, e.g., ['service' => [1,2], 'practitioner' => [3,4]].
	 * @return array An array of valid combinations, e.g., [['service' => 1, 'practitioner' => 3]].
	 */
	public function get_valid_dimension_combinations( array $dimensions ): array {
		$cartesian_product  = $this->cartesian_product( $dimensions );
		$valid_combinations = [];

		foreach ( $cartesian_product as $combo ) {
			if ( count( $combo ) <= 1 ) {
				$valid_combinations[] = $combo;
				continue;
			}

			$is_fully_interlinked = true;
			$combo_items          = array_values( $combo );
			$combo_slugs          = array_keys( $combo );

			for ( $i = 0; $i < count( $combo_items ); $i++ ) {
				for ( $j = $i + 1; $j < count( $combo_items ); $j++ ) {
					$item1_id   = $combo_items[ $i ];
					$item1_slug = $combo_slugs[ $i ];
					$item2_id   = $combo_items[ $j ];
					$item2_slug = $combo_slugs[ $j ];

					$linked_to_item1 = $this->get_linked_child_ids( $item1_id, $item2_slug );
					if ( ! in_array( $item2_id, $linked_to_item1, true ) ) {
						$is_fully_interlinked = false;
						break 2; // Break out of both inner loops
					}
				}
			}

			if ( $is_fully_interlinked ) {
				$valid_combinations[] = $combo;
			}
		}

		return $valid_combinations;
	}

	public function get_latest_slot_date_for_dimensions( array $dimensions ): ?string {
		// This method already uses the generic dimensions array, so no changes are needed.
		global $wpdb;
		$wpdb->flush();
		$slots_table                    = $this->get_slots_table_name();
		$dim_match_data                 = $this->_build_exact_dimension_match_sql_and_params( $dimensions, 's' );
		$dimension_sql_condition_string = $dim_match_data['sql'];
		$final_params                   = $dim_match_data['params'];

		if ( empty( $dimension_sql_condition_string ) ) {
			return null;
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name and condition string are safe.
		$sql = "SELECT MAX(s.start_time) FROM {$slots_table} s WHERE s.is_block = 0 AND {$dimension_sql_condition_string}";

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Query is prepared above.
		$latest_datetime = $wpdb->get_var( $wpdb->prepare( $sql, ...$final_params ) );

		if ( $latest_datetime ) {
			try {
				return ( new \DateTime( $latest_datetime, new \DateTimeZone( 'UTC' ) ) )->format( 'Y-m-d' );
			} catch ( \Exception $e ) {
				return null;
			}
		}
		return null;
	}

	public function insert_slots( array $slots ): array {
		global $wpdb;

		if ( empty( $slots ) ) {
			return [ 'inserted' => 0, 'errors' => 0 ];
		}

		$stats       = [ 'inserted' => 0, 'errors' => 0 ];
		$slots_table = $this->get_slots_table_name();
		$dims_table  = $this->get_dimensions_table_name();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Transaction control is a valid use case.
		$wpdb->query( 'START TRANSACTION' );

		try {
			foreach ( $slots as $slot ) {
				if ( empty( $slot['start_time_utc'] ) || empty( $slot['end_time_utc'] ) ) {
					// This is a data validation error, not a DB error.
					// We'll skip this slot and count it as an error, but not roll back the whole batch.
					$stats['errors']++;
					continue;
				}

				$insert_data = [
					'start_time' => $slot['start_time_utc'],
					'end_time'   => $slot['end_time_utc'],
					'is_block'   => isset( $slot['is_block'] ) && $slot['is_block'] ? 1 : 0,
				];

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				if ( false === $wpdb->insert( $slots_table, $insert_data, [ '%s', '%s', '%d' ] ) ) {
					throw new \Exception( 'Failed to insert into slots table. DB Error: ' . $wpdb->last_error );
				}

				$new_slot_id = $wpdb->insert_id;

				if ( ! empty( $slot['dimensions'] ) && is_array( $slot['dimensions'] ) ) {
					foreach ( $slot['dimensions'] as $key => $value ) {
						// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
						if ( false === $wpdb->insert(
							$dims_table,
							[
								'slot_id'         => $new_slot_id,
								'dimension_key'   => sanitize_key( $key ),
								'dimension_value' => sanitize_text_field( $value ),
							],
							[ '%d', '%s', '%s' ]
						) ) {
							throw new \Exception( 'Failed to insert into dimensions table. DB Error: ' . $wpdb->last_error );
						}
					}
				}
				$stats['inserted']++;
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Transaction control.
			$wpdb->query( 'COMMIT' );
			if ( $stats['inserted'] > 0 ) {
				$this->clear_all_slot_cache();
			}
		} catch ( \Exception $e ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Transaction control.
			$wpdb->query( 'ROLLBACK' );
			// The entire batch failed. The number of errors is the total number of slots we tried to insert.
			$stats['errors']   = count( $slots );
			$stats['inserted'] = 0;
		}

		return $stats;
	}

	public function replace_editable_slots_in_range( array $slots_to_insert, string $start_utc, string $end_utc ): array {
		global $wpdb;
		$stats       = [
			'inserted' => 0,
			'deleted'  => 0,
			'errors'   => 0,
		];
		$slots_table = $this->get_slots_table_name();
		$dims_table  = $this->get_dimensions_table_name();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( 'START TRANSACTION' );

		try {
			// Get all editable slot IDs within the date range to be cleared.
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is safe from internal method.
			$query = "SELECT slot_id FROM {$slots_table} WHERE start_time >= %s AND start_time < %s";

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
			$slot_ids_to_delete = $wpdb->get_col(
				$wpdb->prepare(
					$query, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Query string is prepared above.
					$start_utc,
					$end_utc
				)
			);

			if ( ! empty( $slot_ids_to_delete ) ) {
				$ids_placeholder = implode( ',', array_fill( 0, count( $slot_ids_to_delete ), '%d' ) );

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Dynamic IN clause with prepared placeholders.
				$wpdb->query( $wpdb->prepare( "DELETE FROM {$dims_table} WHERE slot_id IN ($ids_placeholder)", $slot_ids_to_delete ) );

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Dynamic IN clause with prepared placeholders.
				$deleted_count = $wpdb->query( $wpdb->prepare( "DELETE FROM {$slots_table} WHERE slot_id IN ($ids_placeholder)", $slot_ids_to_delete ) );
				$stats['deleted'] = ( false === $deleted_count ) ? 0 : $deleted_count;

				if ( false === $deleted_count ) {
					throw new \Exception( 'Failed to delete old slots.' );
				}
			}

			foreach ( $slots_to_insert as $slot ) {
				$insert_data = [
					'start_time' => $slot['start_time_utc'],
					'end_time'   => $slot['end_time_utc'],
					'is_block'   => filter_var( $slot['is_block'] ?? false, FILTER_VALIDATE_BOOLEAN ) ? 1 : 0,
				];

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
				$insert_result = $wpdb->insert( $slots_table, $insert_data, [ '%s', '%s', '%d' ] );
				if ( $insert_result ) {
					$stats['inserted']++;
					$new_slot_id = $wpdb->insert_id;
					$dimensions  = $slot['dimensions'] ?? [];
					if ( ! empty( $dimensions ) && is_array( $dimensions ) ) {
						foreach ( $dimensions as $key => $value ) {
							// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
							$wpdb->insert(
								$dims_table,
								[
									'slot_id'         => $new_slot_id,
									'dimension_key'   => sanitize_key( $key ),
									'dimension_value' => sanitize_text_field( $value ),
								],
								[ '%d', '%s', '%s' ]
							);
						}
					}
				} else {
					$stats['errors']++;
				}
			}

			if ( $stats['errors'] > 0 ) {
				throw new \Exception( 'Errors occurred while inserting new slots.' );
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->query( 'COMMIT' );
			$this->clear_all_slot_cache();

		} catch ( \Exception $e ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->query( 'ROLLBACK' );
			$stats['errors']++;
		}

		return $stats;
	}

	public function delete_slots_for_date_range( string $start_utc, string $end_utc, array $dimensions = [], ?bool $is_block_filter = null, ?array $days_of_week = null, array $exclude_slot_ids = [] ): int {
		global $wpdb;
		$wpdb->flush();
		$slots_table = $this->get_slots_table_name();
		$dims_table  = $this->get_dimensions_table_name();

		$where_clauses = [];
		$params        = [];

		$where_clauses[] = 's.start_time >= %s';
		$params[]        = $start_utc;
		$where_clauses[] = 's.start_time < %s';
		$params[]        = $end_utc;
		if ( null !== $is_block_filter ) {
			$where_clauses[] = 's.is_block = %d';
			$params[]        = $is_block_filter ? 1 : 0;
		}
		if ( ! empty( $dimensions ) ) {
			$dim_match_data = $this->_build_exact_dimension_match_sql_and_params( $dimensions, 's' );
			if ( ! empty( $dim_match_data['sql'] ) ) {
				$where_clauses[] = $dim_match_data['sql'];
				$params          = array_merge( $params, $dim_match_data['params'] );
			}
		}
		if ( ! empty( $days_of_week ) && is_array( $days_of_week ) ) {
			$valid_days = array_filter( array_map( 'intval', $days_of_week ), fn( $day ) => $day >= 0 && $day <= 6 );
			if ( ! empty( $valid_days ) ) {
				$mysql_days       = array_map( fn( $php_day ) => $php_day + 1, $valid_days );
				$day_placeholders = implode( ',', array_fill( 0, count( $mysql_days ), '%d' ) );
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $day_placeholders are safely generated.
				$where_clauses[] = "DAYOFWEEK(s.start_time) IN ({$day_placeholders})";
				$params          = array_merge( $params, $mysql_days );
			}
		}

		if ( ! empty( $exclude_slot_ids ) ) {
			$exclude_slot_ids     = array_map( 'intval', $exclude_slot_ids );
			$exclude_placeholders = implode( ',', array_fill( 0, count( $exclude_slot_ids ), '%d' ) );
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $exclude_placeholders are safely generated.
			$where_clauses[] = "s.slot_id NOT IN ({$exclude_placeholders})";
			$params          = array_merge( $params, $exclude_slot_ids );
		}

		$where_sql = implode( ' AND ', $where_clauses );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- $where_sql is built safely from placeholder-containing parts.
		$sql_select_ids = "SELECT s.slot_id FROM {$slots_table} s WHERE {$where_sql}";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Query is prepared, caching not appropriate for deletion operation.
		$slot_ids_to_delete = $wpdb->get_col( $wpdb->prepare( $sql_select_ids, ...$params ) );

		if ( empty( $slot_ids_to_delete ) ) {
			return 0;
		}

		$ids_placeholder = implode( ',', array_fill( 0, count( $slot_ids_to_delete ), '%d' ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Dynamic IN clause with prepared placeholders.
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$dims_table} WHERE slot_id IN ($ids_placeholder)", $slot_ids_to_delete ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Dynamic IN clause with prepared placeholders.
		$deleted_count_main_table = $wpdb->query( $wpdb->prepare( "DELETE FROM {$slots_table} WHERE slot_id IN ($ids_placeholder)", $slot_ids_to_delete ) );

		if ( $deleted_count_main_table > 0 ) {
			$this->clear_all_slot_cache();
		}
		return (int) $deleted_count_main_table;
	}

	public function delete_past_available_slots(): int {
		$utc_now = gmdate( 'Y-m-d H:i:s' );
		return $this->delete_slots_for_date_range( '1970-01-01 00:00:00', $utc_now, [], false, null );
	}

	public function delete_all_future_available_slots(): int {
		$utc_now = gmdate( 'Y-m-d H:i:s' );
		return $this->delete_slots_for_date_range( $utc_now, '9999-12-31 23:59:59', [], false, null );
	}

	public function get_linked_child_ids( int $parent_id, string $child_cpt_slug ): array {
		global $wpdb;
		$table_name = $this->get_relationships_table_name();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name from internal method.
		$query = "(SELECT child_object_id FROM {$table_name} WHERE parent_object_id = %d AND child_object_type = %s)
			 UNION
			 (SELECT parent_object_id FROM {$table_name} WHERE child_object_id = %d AND parent_object_type = %s)"; 

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$results = $wpdb->get_col(
			$wpdb->prepare(
				$query, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Query string is prepared above.
				$parent_id,
				$child_cpt_slug,
				$parent_id,
				$child_cpt_slug
			)
		);

		return array_map( 'absint', $results );
	}

	public function find_slot_id_by_start_time_and_dimensions( string $start_time_utc, array $dimensions ): ?int {
		global $wpdb;
		$slots_table = $this->get_slots_table_name();

		if ( empty( $dimensions ) ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging, only runs when WP_DEBUG is enabled.
				error_log( '[CLISYC DB DEBUG] find_slot_id_by_start_time_and_dimensions: Empty dimensions passed!' );
			}
			return null;
		}

		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging, only runs when WP_DEBUG is enabled.
			error_log( '[CLISYC DB DEBUG] find_slot_id_by_start_time_and_dimensions called:' );
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging, only runs when WP_DEBUG is enabled.
			error_log( '[CLISYC DB DEBUG] - start_time_utc: ' . $start_time_utc );
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log, WordPress.PHP.DevelopmentFunctions.error_log_print_r -- Debug logging, only runs when WP_DEBUG is enabled.
			error_log( '[CLISYC DB DEBUG] - dimensions: ' . print_r( $dimensions, true ) );
		}

		$dim_match_data = $this->_build_exact_dimension_match_sql_and_params( $dimensions, 's' );
		if ( empty( $dim_match_data['sql'] ) ) {
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging, only runs when WP_DEBUG is enabled.
				error_log( '[CLISYC DB DEBUG] - dimension match SQL is empty, returning null' );
			}
			return null;
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Safe interpolation.
		$sql    = "SELECT s.slot_id FROM {$slots_table} s WHERE s.start_time = %s AND " . $dim_match_data['sql'];
		$params = array_merge( [ $start_time_utc ], $dim_match_data['params'] );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$prepared_sql = $wpdb->prepare( $sql, ...$params );
		
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug logging, only runs when WP_DEBUG is enabled.
			error_log( '[CLISYC DB DEBUG] - Prepared SQL: ' . $prepared_sql );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$slot_id = $wpdb->get_var( $prepared_sql );

		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log, WordPress.PHP.DevelopmentFunctions.error_log_var_export -- Debug logging, only runs when WP_DEBUG is enabled.
			error_log( '[CLISYC DB DEBUG] - Result slot_id: ' . var_export( $slot_id, true ) );
		}

		return $slot_id ? (int) $slot_id : null;
	}

	public function get_booked_appointments_for_date_range( string $start_utc, string $end_utc, ?int $primary_dim_id = null ): array {
		global $wpdb;
		$bookings_table = $this->get_bookings_table_name();
		$slots_table    = $this->get_slots_table_name();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names are safe.
		$query = "SELECT b.appointment_id, s.start_time, s.end_time FROM {$bookings_table} b JOIN {$slots_table} s ON b.slot_id = s.slot_id WHERE s.start_time >= %s AND s.start_time < %s";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$results = $wpdb->get_results( 
			$wpdb->prepare(
				$query, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
				$start_utc, 
				$end_utc 
			),
			ARRAY_A 
		);

		if ( empty( $results ) ) {
			return [];
		}

		$appointments = [];
		foreach ( $results as $row ) {
			$appointments[] = [
				'appointment_id' => (int) $row['appointment_id'],
				'start_time_utc' => $row['start_time'],
				'end_time_utc'   => $row['end_time'],
			];
		}
		return $appointments;
	}


	public function get_slots_for_date_range( string $start_utc, string $end_utc, array $dimensions = [], bool $is_block = false ): array {
		global $wpdb;
		$wpdb->flush();
		$slots_table      = $this->get_slots_table_name();
		$dims_table       = $this->get_dimensions_table_name();
		$final_sql_params = [ $start_utc, $end_utc, (int) $is_block ];

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names are safe.
		$sql = "SELECT s.slot_id, s.start_time, s.end_time, s.is_block, GROUP_CONCAT(DISTINCT CONCAT(d.dimension_key, ':::', d.dimension_value) SEPARATOR '|||') AS dimensions_concat FROM {$slots_table} s LEFT JOIN {$dims_table} d ON s.slot_id = d.slot_id WHERE s.start_time >= %s AND s.start_time < %s AND s.is_block = %d";

		$dim_match_data = $this->_build_exact_dimension_match_sql_and_params( $dimensions, 's' );
		if ( ! empty( trim( $dim_match_data['sql'] ) ) ) {
			$sql             .= ' AND ' . $dim_match_data['sql'];
			$final_sql_params = array_merge( $final_sql_params, $dim_match_data['params'] );
		}
		$sql .= ' GROUP BY s.slot_id ORDER BY s.start_time ASC';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$results = $wpdb->get_results( $wpdb->prepare( $sql, ...$final_sql_params ), ARRAY_A );

		$processed_slots = [];
		if ( ! empty( $results ) ) {
			foreach ( $results as $row ) {
				$dimensions_array = [];
				if ( ! empty( $row['dimensions_concat'] ) ) {
					$pairs = explode( '|||', $row['dimensions_concat'] );
					foreach ( $pairs as $pair ) {
						$parts = explode( ':::', $pair, 2 );
						if ( count( $parts ) === 2 ) {
							list( $key, $value )      = $parts;
							$dimensions_array[ $key ] = $value;
						}
					}
				}
				$processed_slots[] = [
					'start_time_utc' => $row['start_time'],
					'end_time_utc'   => $row['end_time'],
					'dimensions'     => $dimensions_array,
				];
			}
		}
		return $processed_slots;
	}

	public function get_all_blocked_slots_in_range( string $start_utc, string $end_utc ): array {
		global $wpdb;
		$slots_table = $this->get_slots_table_name();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is safe.
		$sql = "SELECT start_time, end_time FROM {$slots_table} WHERE is_block = 1 AND start_time < %s AND end_time > %s";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$results = $wpdb->get_results( 
			$wpdb->prepare(
				$sql, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
				$end_utc, 
				$start_utc
			),
			ARRAY_A 
		);

		if ( empty( $results ) ) {
			return [];
		}

		$processed_slots = [];
		$utc_timezone    = new \DateTimeZone( 'UTC' );
		foreach ( $results as $row ) {
			try {
				$processed_slots[] = [
					'start' => new \DateTime( $row['start_time'], $utc_timezone ),
					'end'   => new \DateTime( $row['end_time'], $utc_timezone ),
				];
			} catch ( \Exception $e ) {
				continue;
			}
		}
		return $processed_slots;
	}

	public function replace_slots_in_range_with_dimensions( array $slots_to_insert, string $start_utc, string $end_utc, array $dimensions ): array {
		global $wpdb;
		$stats = [
			'inserted' => 0,
			'deleted'  => 0,
			'errors'   => 0,
		];
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Transaction control is a valid use case.
		$wpdb->query( 'START TRANSACTION' );
		try {
			$deleted_count = $this->delete_slots_for_date_range( $start_utc, $end_utc, $dimensions );
			if ( false === $deleted_count ) {
				throw new \Exception( 'Error deleting existing slots for specified dimensions.' );
			}
			$stats['deleted'] = $deleted_count;
			if ( ! empty( $slots_to_insert ) ) {
				$insert_stats = $this->insert_slots( $slots_to_insert );
				if ( $insert_stats['errors'] > 0 ) {
					throw new \Exception( 'Errors occurred during slot insertion.' );
				}
				$stats['inserted'] = $insert_stats['inserted'];
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Transaction control is a valid use case.
			$wpdb->query( 'COMMIT' );
			$this->clear_all_slot_cache();
		} catch ( \Exception $e ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Transaction control is a valid use case.
			$wpdb->query( 'ROLLBACK' );
			$stats['errors']++;
		}
		return $stats;
	}

	public function clear_unrepresented_slots_in_range( string $start_utc, string $end_utc, array $represented_dimension_groups ) {
		// This method is dimension-aware and does not need changes.
		global $wpdb;
		$slots_table = $this->get_slots_table_name();
		$dims_table  = $this->get_dimensions_table_name();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names are safe.
		$sql_get_existing_groups = "
            SELECT s.slot_id, GROUP_CONCAT(CONCAT(d.dimension_key, ':::', d.dimension_value) ORDER BY d.dimension_key SEPARATOR '|||') AS dimensions_concat
            FROM {$slots_table} s
            LEFT JOIN {$dims_table} d ON s.slot_id = d.slot_id
            WHERE s.start_time >= %s AND s.start_time < %s
            GROUP BY s.slot_id";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$existing_slots_in_range = $wpdb->get_results( 
			$wpdb->prepare(
				$sql_get_existing_groups, // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
				$start_utc, 
				$end_utc 
			),
			OBJECT_K 
		);

		if ( empty( $existing_slots_in_range ) ) {
			return;
		}

		$represented_hashes = [];
		foreach ( $represented_dimension_groups as $dim_group ) {
			ksort( $dim_group );
			$represented_hashes[ http_build_query( $dim_group ) ] = true;
		}

		$ids_to_delete = [];
		foreach ( $existing_slots_in_range as $slot_id => $slot_data ) {
			$existing_dims_array = [];
			if ( ! empty( $slot_data->dimensions_concat ) ) {
				$pairs = explode( '|||', $slot_data->dimensions_concat );
				foreach ( $pairs as $pair ) {
					$parts = explode( ':::', $pair, 2 );
					if ( 2 === count( $parts ) ) {
						$existing_dims_array[ $parts[0] ] = $parts[1];
					}
				}
			}
			ksort( $existing_dims_array );
			$existing_hash = http_build_query( $existing_dims_array );

			if ( ! isset( $represented_hashes[ $existing_hash ] ) ) {
				$ids_to_delete[] = (int) $slot_id;
			}
		}

		if ( ! empty( $ids_to_delete ) ) {
			$ids_placeholder = implode( ',', array_fill( 0, count( $ids_to_delete ), '%d' ) );

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
			$sql_delete_dims = sprintf( "DELETE FROM %s WHERE slot_id IN (%s)", $dims_table, $ids_placeholder );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter
			$wpdb->query( $wpdb->prepare( $sql_delete_dims, $ids_to_delete ) );

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
			$sql_delete_slots = sprintf( "DELETE FROM %s WHERE slot_id IN (%s)", $slots_table, $ids_placeholder );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter
			$wpdb->query( $wpdb->prepare( $sql_delete_slots, $ids_to_delete ) );

			$this->clear_all_slot_cache();
		}
	}


	public function get_distinct_available_slot_dates(): array {
		$cache_key   = self::CACHE_GROUP . '_distinct_dates';
		$cached_data = get_transient( $cache_key );
		
		if ( false !== $cached_data ) {
			return $cached_data;
		}
		
		global $wpdb;
		$slots_table        = $this->get_slots_table_name();
		$bookings_table     = $this->get_bookings_table_name();
		$dims_table         = $this->get_dimensions_table_name();
		$postmeta_table     = $wpdb->postmeta;
		$site_timezone_name = wp_timezone_string();

		// Get the primary dimension slug for capacity lookup
		$registry         = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
		$primary_dim_slug = null;
		if ( ! empty( $registry['dimensions'] ) ) {
			foreach ( $registry['dimensions'] as $slug => $settings ) {
				if ( ! empty( $settings['primary'] ) ) {
					$primary_dim_slug = $slug;
					break;
				}
			}
		}

		// If no primary dimension configured, fall back to simple query without capacity check
		if ( ! $primary_dim_slug ) {
			return $this->_get_distinct_dates_simple();
		}

		$use_mysql_method = false;
		if ( strpos( $site_timezone_name, '/' ) !== false ) {
			$override_setting  = get_option( Constants::OPTION_MYSQL_CONVERT_TZ_OR, 'auto_detect' );
			$convert_tz_status = get_option( Constants::OPTION_MYSQL_CONVERT_TZ, 'unknown' );

			if ( 'force_mysql' === $override_setting ) {
				$use_mysql_method = true;
			} elseif ( 'auto_detect' === $override_setting && 'fails' !== $convert_tz_status ) {
				$use_mysql_method = true;
			}
		}

		$results = [];
		$current_utc_datetime_str = gmdate( 'Y-m-d H:i:s' );
		
		$meta_capacity = Constants::META_CAPACITY;

		// Actually test if CONVERT_TZ works before using it
		if ( $use_mysql_method ) {
			// Direct test: if CONVERT_TZ returns NULL, the server doesn't have timezone tables
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One-time test query, caching not appropriate.
			$test_result = $wpdb->get_var( 
				$wpdb->prepare( 
					"SELECT CONVERT_TZ(%s, '+00:00', %s)", 
					'2025-01-01 12:00:00', 
					$site_timezone_name 
				) 
			);
			
			if ( null === $test_result ) {
				$use_mysql_method = false;
				if ( 'auto_detect' === get_option( Constants::OPTION_MYSQL_CONVERT_TZ_OR, 'auto_detect' ) ) {
					update_option( Constants::OPTION_MYSQL_CONVERT_TZ, 'fails' );
				}
			} else {
				if ( 'auto_detect' === get_option( Constants::OPTION_MYSQL_CONVERT_TZ_OR, 'auto_detect' ) ) {
					update_option( Constants::OPTION_MYSQL_CONVERT_TZ, 'works' );
				}
			}
		}
		
		// FIX: If resource dimensions exist, use PHP fallback for proper conflict checking
		$registry_check = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
		$has_resource_dims = false;
		foreach ( $registry_check['dimensions'] ?? [] as $slug => $config ) {
			if ( ! empty( $config['is_resource'] ) ) {
				$has_resource_dims = true;
				break;
			}
		}
		
		if ( $has_resource_dims ) {
			$use_mysql_method = false; // Force PHP fallback for resource conflict checking
		}
		
		if ( $use_mysql_method ) {
			// Simpler approach: just query available slots directly without complex subquery
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names from internal methods are safe.
			$sql = "
				SELECT DISTINCT DATE(CONVERT_TZ(s.start_time, '+00:00', %s)) as slot_date
				FROM {$slots_table} s
				JOIN {$dims_table} d_primary
					ON s.slot_id = d_primary.slot_id
					AND d_primary.dimension_key = %s
				LEFT JOIN {$postmeta_table} pm
					ON d_primary.dimension_value = pm.post_id
					AND pm.meta_key = '{$meta_capacity}'
				WHERE s.start_time >= %s
				AND s.is_block = 0
				AND (
					SELECT COUNT(*) FROM {$bookings_table} b WHERE b.slot_id = s.slot_id
				) < COALESCE(pm.meta_value, 1)
				AND CONVERT_TZ(s.start_time, '+00:00', %s) IS NOT NULL
				ORDER BY slot_date ASC
			";
			
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $sql uses interpolated table names from internal methods.
			$prepared_sql = $wpdb->prepare(	$sql, $site_timezone_name, $primary_dim_slug, $current_utc_datetime_str, $site_timezone_name );
			
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Query is prepared above, caching handled via transient.
			$results = $wpdb->get_col( $prepared_sql );
			
			// If query failed with an error, fall back to PHP
			if ( $wpdb->last_error ) {
				$use_mysql_method = false;
			} else {
				$results = $results ?: [];
			}
		}

		if ( ! $use_mysql_method ) {
			// Simpler query for PHP fallback
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names from internal methods are safe.
			$sql_php_fallback = "
				SELECT s.start_time
				FROM {$slots_table} s
				JOIN {$dims_table} d_primary
					ON s.slot_id = d_primary.slot_id
					AND d_primary.dimension_key = %s
				LEFT JOIN {$postmeta_table} pm
					ON d_primary.dimension_value = pm.post_id
					AND pm.meta_key = '{$meta_capacity}'
				WHERE s.start_time >= %s
				AND s.is_block = 0
				AND (
					SELECT COUNT(*) FROM {$bookings_table} b WHERE b.slot_id = s.slot_id
				) < COALESCE(pm.meta_value, 1)
				ORDER BY s.start_time ASC
			";
			
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- $sql_php_fallback uses interpolated table names from internal methods.
			$prepared_sql = $wpdb->prepare( $sql_php_fallback, $primary_dim_slug, $current_utc_datetime_str );
			
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Query is prepared above, caching handled via transient.
			$utc_start_times_from_db = $wpdb->get_col( $prepared_sql );
			
			if ( ! empty( $utc_start_times_from_db ) ) {
				// FIX: Also query slot dimensions and check for resource conflicts
				$slots_table_inner = $this->get_slots_table_name();
				$dims_table_inner  = $this->get_dimensions_table_name();

				// Get the full slot data including dimensions
				$placeholders = implode( ',', array_fill( 0, count( $utc_start_times_from_db ), '%s' ) );
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
				$slots_sql = "
					SELECT s.start_time, 
						   GROUP_CONCAT(DISTINCT CONCAT(d.dimension_key, ':::', d.dimension_value) SEPARATOR '|||') as dims
					FROM {$slots_table_inner} s
					LEFT JOIN {$dims_table_inner} d ON s.slot_id = d.slot_id
					WHERE s.start_time IN ($placeholders)
					AND s.is_block = 0
					GROUP BY s.slot_id, s.start_time
				";
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
				$slots_with_dims = $wpdb->get_results( $wpdb->prepare( $slots_sql, ...$utc_start_times_from_db ), ARRAY_A );

				// Get resource conflicts for the entire range
				$first_time = min( $utc_start_times_from_db );
				$last_time = max( $utc_start_times_from_db );
				// Add a day buffer for safety
				$end_buffer = ( new \DateTime( $last_time ) )->modify( '+1 day' )->format( 'Y-m-d H:i:s' );
				$resource_conflicts = $this->_get_resource_conflicts_for_range( $first_time, $end_buffer );

				$site_slot_dates   = [];
				$site_timezone_obj = wp_timezone();

				foreach ( $slots_with_dims as $slot_row ) {
					$utc_time_str = $slot_row['start_time'];
					
					// Parse dimensions
					$slot_dimensions = [];
					if ( ! empty( $slot_row['dims'] ) ) {
						$pairs = explode( '|||', $slot_row['dims'] );
						foreach ( $pairs as $pair ) {
							$parts = explode( ':::', $pair, 2 );
							if ( count( $parts ) === 2 ) {
								$slot_dimensions[ $parts[0] ] = $parts[1];
							}
						}
					}

					// FIX: Skip slots with resource conflicts
					if ( $this->_has_resource_conflict( $utc_time_str, $slot_dimensions, $resource_conflicts ) ) {
						if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
							// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
							error_log( '[CLISYC SMART-START] Skipping slot at ' . $utc_time_str . ' due to resource conflict' );
						}
						continue;
					}

					try {
						$utc_dt  = new \DateTime( $utc_time_str, new \DateTimeZone( 'UTC' ) );
						$site_dt = new \DateTime( 'now', $site_timezone_obj );
						$site_dt->setTimestamp( $utc_dt->getTimestamp() );

						$site_slot_dates[ $site_dt->format( 'Y-m-d' ) ] = true;
					} catch ( \Exception $e ) {
						// Fall through
					}
				}
				$results = array_keys( $site_slot_dates );
				sort( $results );
			}
		}
		
		// Cache for 5 minutes
		set_transient( $cache_key, $results, 5 * MINUTE_IN_SECONDS );
		
		return $results;
	}

	/**
	 * Check if a slot has a resource conflict.
	 * A resource conflict occurs when a dimension marked as is_resource=true
	 * is already booked at the same time by another appointment.
	 *
	 * @param string $start_time_utc The slot start time in UTC.
	 * @param array  $slot_dimensions The dimensions of the slot (dimension_key => dimension_value).
	 * @param array  $resource_conflicts Pre-fetched array of resource conflicts.
	 * @return bool True if there is a conflict.
	 */
	private function _has_resource_conflict( string $start_time_utc, array $slot_dimensions, array $resource_conflicts ): bool {
		if ( empty( $resource_conflicts ) || empty( $slot_dimensions ) ) {
			return false;
		}

		$registry = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
		$resource_dims = [];
		foreach ( $registry['dimensions'] ?? [] as $slug => $config ) {
			if ( ! empty( $config['is_resource'] ) ) {
				$resource_dims[] = $slug;
			}
		}

		if ( empty( $resource_dims ) ) {
			return false;
		}

		foreach ( $resource_dims as $res_dim ) {
			if ( isset( $slot_dimensions[ $res_dim ] ) ) {
				$res_value = (int) $slot_dimensions[ $res_dim ];
				$conflict_key = $start_time_utc . '|' . $res_dim . ':' . $res_value;
				if ( isset( $resource_conflicts[ $conflict_key ] ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Get all resource conflicts for a date range.
	 * Returns array keyed by "time|resource_key:resource_value" => appointment_id.
	 *
	 * @param string $start_utc Start of range.
	 * @param string $end_utc End of range.
	 * @return array
	 */
	private function _get_resource_conflicts_for_range( string $start_utc, string $end_utc ): array {
		global $wpdb;

		$registry = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
		$resource_dims = [];
		foreach ( $registry['dimensions'] ?? [] as $slug => $config ) {
			if ( ! empty( $config['is_resource'] ) ) {
				$resource_dims[] = $slug;
			}
		}

		if ( empty( $resource_dims ) ) {
			return [];
		}

		// Query appointments in the date range
		$post_type = Constants::POST_TYPE_APPOINTMENT;
		$meta_time_slot = Constants::META_TIME_SLOT;
		$meta_slot_dimensions = Constants::META_SLOT_DIMENSIONS;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$appointments = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT
					p.ID as appointment_id,
					pm_time.meta_value as time_slot,
					pm_dims.meta_value as slot_dimensions
				FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} pm_time ON p.ID = pm_time.post_id AND pm_time.meta_key = '{$meta_time_slot}'
				LEFT JOIN {$wpdb->postmeta} pm_dims ON p.ID = pm_dims.post_id AND pm_dims.meta_key = '{$meta_slot_dimensions}'
				WHERE p.post_type = '{$post_type}'
				AND p.post_status IN ('publish', 'confirmed', 'clisyc_pending_payment', 'clisyc_paid_on_day', 'wc-processing', 'wc-completed')
				AND pm_time.meta_value >= %s
				AND pm_time.meta_value < %s",
				$start_utc,
				$end_utc
			),
			ARRAY_A
		);

		$conflicts = [];

		foreach ( $appointments as $appt ) {
			$time_slot = $appt['time_slot'];
			$dimensions = [];

			if ( ! empty( $appt['slot_dimensions'] ) ) {
				$dims_data = maybe_unserialize( $appt['slot_dimensions'] );
				if ( is_array( $dims_data ) ) {
					$dimensions = $dims_data;
				}
			}

			foreach ( $resource_dims as $res_dim ) {
				if ( isset( $dimensions[ $res_dim ] ) ) {
					$conflict_key = $time_slot . '|' . $res_dim . ':' . (int) $dimensions[ $res_dim ];
					$conflicts[ $conflict_key ] = (int) $appt['appointment_id'];
				}
			}
		}

		return $conflicts;
	}

	/**
	 * Simple fallback for getting distinct dates without capacity check.
	 * Used when no primary dimension is configured.
	 */
	private function _get_distinct_dates_simple(): array {
		global $wpdb;
		$slots_table              = $this->get_slots_table_name();
		$current_utc_datetime_str = gmdate( 'Y-m-d H:i:s' );
		$site_timezone_obj        = wp_timezone();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is safe.
		$sql = "SELECT DISTINCT s.start_time 
				FROM {$slots_table} s 
				WHERE s.is_block = 0 AND s.start_time >= %s 
				ORDER BY s.start_time ASC";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$utc_start_times = $wpdb->get_col( $wpdb->prepare( $sql, $current_utc_datetime_str ) );

		$site_slot_dates = [];
		foreach ( $utc_start_times as $utc_time_str ) {
			try {
				$utc_dt  = new \DateTime( $utc_time_str, new \DateTimeZone( 'UTC' ) );
				$site_dt = new \DateTime( 'now', $site_timezone_obj );
				$site_dt->setTimestamp( $utc_dt->getTimestamp() );
				$site_slot_dates[ $site_dt->format( 'Y-m-d' ) ] = true;
			} catch ( \Exception $e ) {
				// Skip invalid dates
			}
		}

		$results = array_keys( $site_slot_dates );
		sort( $results );

		set_transient( self::CACHE_GROUP . '_distinct_dates', $results, 5 * MINUTE_IN_SECONDS );
		return $results;
	}

	public function has_slots_for_service_in_range( string $start_utc, string $end_utc, int $service_id ): bool {
		global $wpdb;
		$slots_table = $this->get_slots_table_name();
		$dims_table  = $this->get_dimensions_table_name();

		// REFACTORED: Query the dimensions table instead of the slots table.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names are safe.
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM {$slots_table} s JOIN {$dims_table} d ON s.slot_id = d.slot_id WHERE d.dimension_key = 'service_id' AND d.dimension_value = %d AND s.start_time >= %s AND s.start_time < %s LIMIT 1", $service_id, $start_utc, $end_utc ) );
	}

	private function add_admin_notice_for_convert_tz_issue() {
		// *** REFACTORED ***: Updated transient name.
		if ( get_transient( 'clisyc_convert_tz_notice_shown' ) ) {
			return;
		}
		add_action(
			'admin_notices',
			function () {
				?>
				<div class="notice notice-warning is-dismissible cs-convert-tz-warning">
					<p>
						<strong><?php esc_html_e( 'Client Sync Optimization Notice:', 'client-sync' ); ?></strong>
						<?php
						/*
						 * translators: 1: An HTML link with the text 'Learn more here'. 2: The website's configured timezone string (e.g., "America/New_York").
						 */
						$notice_text = __( 'Client Sync has detected that your MySQL server might not be fully configured for optimal timezone conversions with named timezones (like "%2$s"). While the plugin will continue to function using a fallback method, performance for calendar operations can be improved if your MySQL timezone information tables are populated. %1$s for more information.', 'client-sync' );

						$learn_more_link = sprintf(
							'<a href="%s" target="_blank" rel="noopener noreferrer">%s</a>',
							'https://dev.mysql.com/doc/refman/8.0/en/time-zone-support.html#time-zone-installation',
							esc_html__( 'Learn more here', 'client-sync' )
						);

						echo wp_kses(
							sprintf(
								$notice_text,
								$learn_more_link,
								esc_html( wp_timezone_string() )
							),
							[
								'strong' => [],
								'a'      => [
									'href'   => [],
									'target' => [],
									'rel'    => [],
								],
							]
						);
						?>
					</p>
				</div>
				<?php
			}
		);
		// *** REFACTORED ***: Updated transient name.
		set_transient( 'clisyc_convert_tz_notice_shown', true, WEEK_IN_SECONDS );
	}

	public function clear_all_slot_cache() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Cannot prepare LIKE with wildcard on both sides this way, but the value is hardcoded and safe.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_' . self::CACHE_GROUP ) . '%'
			)
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Cannot prepare LIKE with wildcard on both sides this way, but the value is hardcoded and safe.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_timeout_' . self::CACHE_GROUP ) . '%'
			)
		);
	}

	public function count_future_slots_for_dimensions( array $dimensions ): int {
		global $wpdb;

		$slots_table    = $this->get_slots_table_name();
		$dims_table     = $this->get_dimensions_table_name();
		$bookings_table = $this->get_bookings_table_name();
		$postmeta_table = $wpdb->postmeta;

		$params = [ gmdate( 'Y-m-d H:i:s' ) ];

		// Find the Primary Dimension slug
		// *** REFACTORED ***: Updated option name.
		$registry         = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
		$primary_dim_slug = null;
		if ( ! empty( $registry['dimensions'] ) ) {
			foreach ( $registry['dimensions'] as $slug => $settings ) {
				if ( ! empty( $settings['primary'] ) ) {
					$primary_dim_slug = $slug;
					break;
				}
			}
		}
		if ( ! $primary_dim_slug ) {
			return 0;
		}

		$dim_match_data = $this->_build_exact_dimension_match_sql_and_params( $dimensions, 's' );
		if ( empty( $dim_match_data['sql'] ) ) {
			return 0;
		}

		$params = array_merge( $params, $dim_match_data['params'] );

		// *** REFACTORED ***: Updated meta key name.
		$meta_capacity = Constants::META_CAPACITY;
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table names are safe.
		$sql_count = "
			SELECT COUNT(t.slot_id)
			FROM (
				SELECT
					s.slot_id,
					(SELECT COUNT(*) FROM {$bookings_table} b WHERE b.slot_id = s.slot_id) as booked_count,
					COALESCE(pm.meta_value, 1) as capacity
				FROM
					{$slots_table} s
				JOIN {$dims_table} d_primary ON s.slot_id = d_primary.slot_id AND d_primary.dimension_key = %s
				LEFT JOIN {$postmeta_table} pm ON d_primary.dimension_value = pm.post_id AND pm.meta_key = '{$meta_capacity}'
				WHERE
					s.start_time >= %s
					AND s.is_block = 0
					AND {$dim_match_data['sql']}
			) AS t
			WHERE
				t.booked_count < t.capacity
		";

		array_unshift( $params, $primary_dim_slug );

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.DirectQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$count = $wpdb->get_var( $wpdb->prepare( $sql_count, ...$params ) );

		return (int) $count;
	}

	// START: NEW METHOD FOR TWO-WAY SYNC
	/**
	 * Finds and marks as 'blocked' any available slots that overlap with a given time range and dimension set.
	 *
	 * @param string $start_utc_str The start of the blocking period (Y-m-d H:i:s).
	 * @param string $end_utc_str   The end of the blocking period (Y-m-d H:i:s).
	 * @param array  $dimensions    The dimensions to match (e.g., ['clisyc_employee' => 123]).
	 * @return int|false The number of rows updated, or false on error.
	 */
	public function block_overlapping_slots( string $start_utc_str, string $end_utc_str, array $dimensions ) {
		global $wpdb;

		$slots_table   = $this->get_slots_table_name();
		$where_clauses = [
			's.is_block = 0',       // Only find available slots
			's.start_time < %s',    // Slot starts before the Google event ends
			's.end_time > %s',      // Slot ends after the Google event starts
		];
		$params        = [ $end_utc_str, $start_utc_str ];

		// Use the exact match helper to find slots associated with the specific employee/resource
		$dim_match_data = $this->_build_exact_dimension_match_sql_and_params( $dimensions, 's' );
		if ( ! empty( $dim_match_data['sql'] ) ) {
			$where_clauses[] = $dim_match_data['sql'];
			$params          = array_merge( $params, $dim_match_data['params'] );
		} else {
			return 0; // Don't block slots if we can't identify the specific resource
		}

		$where_sql = implode( ' AND ', $where_clauses );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name and where_sql built safely from internal methods.
		$sql_select_ids = "SELECT s.slot_id FROM {$slots_table} s WHERE {$where_sql}";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Query is prepared, caching not appropriate for blocking operation.
		$slot_ids_to_block = $wpdb->get_col( $wpdb->prepare( $sql_select_ids, ...$params ) );

		if ( empty( $slot_ids_to_block ) ) {
			return 0;
		}

		$ids_placeholder = implode( ',', array_fill( 0, count( $slot_ids_to_block ), '%d' ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name from internal method.
		$query = "UPDATE {$slots_table} SET is_block = 1 WHERE slot_id IN ($ids_placeholder)";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Dynamic IN clause with prepared placeholders.
		$update_result = $wpdb->query( $wpdb->prepare( $query, ...$slot_ids_to_block ) );

		if ( $update_result ) {
			$this->clear_all_slot_cache();
		}
		return $update_result;
	}
	// END: NEW METHOD

	public function repair_missing_relationship_types(): array {
		global $wpdb;
		$rels_table = $this->get_relationships_table_name();

		// Find all rows with missing type information
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name from internal method, no user input.
		$corrupt_rows = $wpdb->get_results( "SELECT * FROM {$rels_table} WHERE parent_object_type = '' OR child_object_type = ''" );

		if ( empty( $corrupt_rows ) ) {
			return [ 'repaired' => 0, 'unrepaired' => 0 ];
		}

		$repaired_count   = 0;
		$unrepaired_count = 0;
		$post_type_cache  = [];

		foreach ( $corrupt_rows as $row ) {
			$parent_type = $row->parent_object_type;
			$child_type  = $row->child_object_type;
			$update_data = [];

			if ( empty( $parent_type ) ) {
				if ( ! isset( $post_type_cache[ $row->parent_object_id ] ) ) {
					$post_type_cache[ $row->parent_object_id ] = get_post_type( $row->parent_object_id );
				}
				$found_parent_type = $post_type_cache[ $row->parent_object_id ];
				if ( $found_parent_type ) {
					$update_data['parent_object_type'] = $found_parent_type;
				}
			}

			if ( empty( $child_type ) ) {
				if ( ! isset( $post_type_cache[ $row->child_object_id ] ) ) {
					$post_type_cache[ $row->child_object_id ] = get_post_type( $row->child_object_id );
				}
				$found_child_type = $post_type_cache[ $row->child_object_id ];
				if ( $found_child_type ) {
					$update_data['child_object_type'] = $found_child_type;
				}
			}

			if ( ! empty( $update_data ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->update( $rels_table, $update_data, [ 'relationship_id' => $row->relationship_id ] );
				$repaired_count++;
			} else {
				$unrepaired_count++;
			}
		}

		return [ 'repaired' => $repaired_count, 'unrepaired' => $unrepaired_count ];
	}

	/**
	 * Finds all primary dimension items that are fully available for a given date range.
	 *
	 * @param string $start_date_str    The desired check-in date (Y-m-d).
	 * @param string $end_date_str      The desired check-out date (Y-m-d).
	 * @param array  $attribute_filters Optional. An associative array of attribute filters (meta_key => meta_value).
	 * @return array An array of WP_Post objects for the available items.
	 */
	public function get_available_dimension_items_for_range( string $start_date_str, string $end_date_str, array $attribute_filters = [] ): array {
		$registry         = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
		$primary_dim_slug = null;
		if ( ! empty( $registry['dimensions'] ) ) {
			foreach ( $registry['dimensions'] as $slug => $settings ) {
				if ( ! empty( $settings['primary'] ) ) {
					$primary_dim_slug = $slug;
					break;
				}
			}
		}

		if ( ! $primary_dim_slug ) {
			return [];
		}

		// START: NEW - Build meta query for attribute filters
		$meta_query = [
			'relation' => 'AND',
			[
				'key'   => Constants::META_BOOKING_MODE,
				'value' => 'date_range',
			],
		];

		if ( ! empty( $attribute_filters ) ) {
			foreach ( $attribute_filters as $key => $value ) {
				if ( ! empty( $value ) ) {
					$prefixed_key = '_clisyc_' . sanitize_key( $key ); // Construct the prefixed key
					$meta_query[] = [
						'key'     => $prefixed_key, // Use the prefixed key in the query
						'value'   => $value,
						'compare' => '=',
					];
				}
			}
		}
		// END: NEW

		$all_items = get_posts(
			[
				'post_type'      => $primary_dim_slug,
				'posts_per_page' => -1,
				'post_status'    => 'publish',
				'meta_query'     => $meta_query, // Use the newly built meta query
			]
		);

		if ( empty( $all_items ) ) {
			return [];
		}

		$available_item_ids = [];

		foreach ( $all_items as $item ) {
			$capacity = (int) get_post_meta( $item->ID, Constants::META_CAPACITY, true ) ?: 1;

			$args = [
				'post_type'      => Constants::POST_TYPE_APPOINTMENT,
				'post_status'    => [ 'publish', Constants::STATUS_CONFIRMED, 'clisyc_paid_on_day', 'wc-completed', 'wc-processing' ],
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => [
					'relation' => 'AND',
					[
						'key'     => Constants::META_SLOT_DIMENSIONS,
						'value'   => '"' . $primary_dim_slug . '";i:' . $item->ID . ';',
						'compare' => 'LIKE',
					],
					[
						'key'     => Constants::META_END_DATE,
						'value'   => $start_date_str,
						'compare' => '>',
						'type'    => 'DATE',
					],
					[
						'key'     => Constants::META_START_DATE,
						'value'   => $end_date_str,
						'compare' => '<',
						'type'    => 'DATE',
					],
				],
			];

			$conflicting_bookings_query = new \WP_Query( $args );
			$conflicting_count          = $conflicting_bookings_query->post_count;

			if ( $conflicting_count < $capacity ) {
				$available_item_ids[] = $item->ID;
			}
		}

		if ( empty( $available_item_ids ) ) {
			return [];
		}

		return get_posts(
			[
				'post_type'      => $primary_dim_slug,
				'posts_per_page' => -1,
				'post__in'       => $available_item_ids,
				'orderby'        => 'title',
				'order'          => 'ASC',
			]
		);
	}

}