<?php
/**
 * File: src/shared/includes/core/notification-channels/class-email-channel.php
 * Implements the default notification channel for sending standard WordPress emails.
 *
 * @package    ClientSync
 * @subpackage ClientSync/Core/NotificationChannels
 */
namespace DependentMedia\ClientSync\Core\NotificationChannels;

use DependentMedia\ClientSync\Core\Interfaces\Notification_Channel_Interface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Email_Channel implements Notification_Channel_Interface {

	/**
	 * {@inheritdoc}
	 */
	public function get_id(): string {
		return 'email';
	}

	/**
	 * {@inheritdoc}
	 */
	public function get_label(): string {
		return __( 'Email', 'client-sync' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function send( string $event_type, array $placeholder_data, array $recipients ): bool {
		$all_settings   = get_option( 'clisyc_notification_settings', [] );
		$event_settings = $all_settings[ $event_type ] ?? [];
		$email_sent     = false;

		foreach ( $recipients as $recipient ) {
			if ( empty( $recipient['email'] ) || empty( $recipient['type'] ) ) {
				continue;
			}

			$recipient_type = $recipient['type'];
			if ( empty( $event_settings[ $recipient_type . '_enabled' ] ) ) {
				continue;
			}

			$subject_template = $event_settings[ $recipient_type . '_subject' ] ?? '';
			$body_template    = $event_settings[ $recipient_type . '_body' ] ?? '';

			$subject = $this->process_placeholders( $subject_template, $placeholder_data );
			$body    = wpautop( $this->process_placeholders( $body_template, $placeholder_data ) );
			$headers = $this->get_email_headers();

			if ( ! empty( $subject ) && ! empty( trim( $body ) ) ) {
				if ( wp_mail( $recipient['email'], $subject, $body, $headers ) ) {
					$email_sent = true;
				}
			}
		}
		return $email_sent;
	}

	/**
	 * Replaces placeholder tags with actual data.
	 */
	private function process_placeholders( string $template, array $data ): string {
		$clean_data = [];
		foreach ( $data as $key => $value ) {
			if ( is_scalar( $value ) || ( is_object( $value ) && method_exists( $value, '__toString' ) ) ) {
				$clean_data[ $key ] = (string) $value;
			}
		}

		if ( ! empty( $clean_data ) ) {
			$template = str_replace( array_keys( $clean_data ), array_values( $clean_data ), $template );
		}

		// Clean up any remaining, un-replaced placeholders.
		$template = preg_replace( '/\{[a-zA-Z0-9_]+\}/', '', $template );
		return $template;
	}

	/**
	 * Gets the standard email headers.
	 */
	private function get_email_headers(): array {
		$from_name  = get_option( 'clisyc_email_from_name', get_bloginfo( 'name' ) );
		$from_email = get_option( 'clisyc_email_from_address', get_option( 'admin_email' ) );
		if ( ! is_email( $from_email ) ) {
			$from_email = get_option( 'admin_email' );
		}
		return [
			'Content-Type: text/html; charset=UTF-8',
			'From: ' . $from_name . ' <' . $from_email . '>',
		];
	}
}