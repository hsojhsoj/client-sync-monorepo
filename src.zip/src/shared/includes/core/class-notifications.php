<?php
/**
 * File: src/shared/includes/core/class-notifications.php
 * Orchestrates all notifications for the Client Sync plugin.
 *
 * This class handles triggering notification events and dispatching them to
 * all registered channels (e.g., Email, SMS, Webhooks).
 *
 * UPDATED: Added HIPAA compliance - sanitizes PHI in notification placeholders
 * when HIPAA mode is active to prevent PHI exposure in external communications.
 *
 * @package    ClientSync
 * @subpackage ClientSync/Core
 */
namespace DependentMedia\ClientSync\Core;

use DependentMedia\ClientSync\Core\Interfaces\Notification_Channel_Interface;
use DependentMedia\ClientSync\Constants;

if ( ! defined( 'ABSPATH' ) ) exit;

class Notifications {

	private $channels = [];

	public function __construct() {
		$this->channels['email'] = new \DependentMedia\ClientSync\Core\NotificationChannels\Email_Channel();

		$pro_channels = apply_filters( 'clisyc_notification_channels', [] );

		foreach ( $pro_channels as $channel ) {
			if ( $channel instanceof Notification_Channel_Interface ) {
				$this->channels[ $channel->get_id() ] = $channel;
			}
		}
	}

	/**
	 * Register all hooks related to notification functionality.
	 */
	public function register_hooks() {
		// Hooks that trigger notifications from appointment status changes
		add_action( 'transition_post_status', [ $this, 'trigger_appointment_status_change_notifications' ], 10, 3 );
		// Hooks that trigger notifications for new user registration
		add_action( 'user_register', [ $this, 'trigger_new_user_notifications' ], 10, 1 );
	}

	/**
	 * The main method for sending a notification.
	 *
	 * @param string $event_type A unique key for the notification event.
	 * @param int    $object_id  The primary object ID (e.g., Appointment ID, User ID).
	 * @param array  $data       Optional additional data for placeholders.
	 * @return bool True if at least one notification was sent successfully, false otherwise.
	 */
	public function send( $event_type, $object_id, $data = [] ) {
		$placeholder_data = $this->prepare_placeholder_data( $event_type, $object_id, $data );
		if ( ! $placeholder_data ) {
			return false;
		}

		$recipients = $this->get_recipients_for_event( $event_type, $object_id, $data );
		if ( empty( $recipients ) ) {
			return false;
		}

		$sent_successfully = false;
		foreach ( $this->channels as $channel ) {
			if ( $channel->send( $event_type, $placeholder_data, $recipients ) ) {
				$sent_successfully = true;
			}
		}
		return $sent_successfully;
	}

	/**
	 * Triggers notifications when an appointment's status changes.
	 * @param string  $new_status New post status.
	 * @param string  $old_status Old post status.
	 * @param \WP_Post $post       Post object.
	 */
	public function trigger_appointment_status_change_notifications( $new_status, $old_status, $post ) {
		// *** REFACTORED ***: Updated CPT name
		if ( Constants::POST_TYPE_APPOINTMENT !== $post->post_type ) {
			return;
		}
		if ( $old_status === 'new' || $old_status === 'auto-draft' || $new_status === 'auto-draft' || $new_status === $old_status ) {
			return;
		}

		if ( $new_status === 'trash' && $old_status !== 'trash' ) {
			// Note: This is for admin-initiated cancellations. Client-initiated cancellations are handled separately.
			$this->send( 'appointment_cancelled_admin', $post->ID );
		}
		if ( $new_status === 'pending' && $old_status !== 'pending' ) {
			$this->send( 'appointment_pending_admin', $post->ID );
		}
		// *** REFACTORED ***: Updated custom status names
		if ( $new_status === 'clisyc_pending_payment' && $old_status !== 'clisyc_pending_payment' ) {
			$this->send( 'appointment_payment_due_client', $post->ID );
			$this->send( 'appointment_updated_admin', $post->ID );
		}
		// *** REFACTORED ***: Updated custom status names
		if ( $new_status === 'clisyc_paid_on_day' && $old_status !== 'clisyc_paid_on_day' ) {
			$this->send( 'payment_successful_client', $post->ID );
			$this->send( 'payment_successful_admin', $post->ID );
		}
		// *** REFACTORED ***: Updated custom status names
		if ( $new_status === 'clisyc_failed_on_day' && $old_status !== 'clisyc_failed_on_day' ) {
			$this->send( 'scheduled_payment_failure_client', $post->ID );
			$this->send( 'scheduled_payment_failure_admin', $post->ID );
		}
	}

	/**
	 * Triggers notifications when a new user registers.
	 * @param int $user_id The new user's ID.
	 */
	public function trigger_new_user_notifications( $user_id ) {
		$this->send( 'new_client_registration_admin', $user_id );
		$this->send( 'new_client_registration_client', $user_id );
	}

	/**
	 * Retrieves the settings for a specific notification event, merged with defaults.
	 * @param string $event_type The key of the event.
	 * @return array|null The settings array for the event, or null.
	 */
	private function get_notification_settings( $event_type ) {
		// *** REFACTORED ***: Updated option name
		$all_settings   = get_option( Constants::OPTION_NOTIFICATION_SETTINGS, [] );
		$defaults       = $this->get_default_templates_for_event( $event_type );
		$event_settings = isset( $all_settings[ $event_type ] ) ? $all_settings[ $event_type ] : [];

		return wp_parse_args( $event_settings, $defaults );
	}

	/**
	 * Determines the email recipients for a given event.
	 * @param string $event_type The event key.
	 * @param int    $object_id  The object ID.
	 * @param array  $data       Additional data.
	 * @return array An array of recipient arrays, each with 'type' and 'email'.
	 */
	private function get_recipients_for_event( $event_type, $object_id, $data ) {
		$recipients        = [];
		$event_definitions = $this->get_event_types();
		if ( ! isset( $event_definitions[ $event_type ] ) ) {
			return [];
		}

		$recipient_types = $event_definitions[ $event_type ]['recipient_types'];

		if ( in_array( 'admin', $recipient_types, true ) ) {
			// *** REFACTORED ***: Updated option name
			$admin_emails = get_option( Constants::OPTION_NOTIFICATION_ADMINS, get_option( 'admin_email' ) );
			$emails_array = array_map( 'trim', explode( ',', $admin_emails ) );
			foreach ( $emails_array as $email ) {
				if ( is_email( $email ) ) {
					$recipients[] = [ 'type' => 'admin', 'email' => $email ];
				}
			}
		}

		if ( in_array( 'client', $recipient_types, true ) ) {
			$client_email = $this->get_client_email_for_event( $event_type, $object_id, $data );
			if ( is_email( $client_email ) ) {
				$recipients[] = [ 'type' => 'client', 'email' => $client_email ];
			}
		}
		return $recipients;
	}

	/**
	 * Helper to get the client's email based on the event context.
	 * @param string $event_type The event key.
	 * @param int    $object_id  The object ID.
	 * @return string|null The client's email or null.
	 */
	private function get_client_email_for_event( $event_type, $object_id, $data = [] ) {
		$user_id = null;
		switch ( $event_type ) {
			case 'new_appointment_client':
			case 'new_appointment_admin':
			case 'appointment_updated_admin':
			case 'appointment_cancelled_admin':
			case 'appointment_cancelled_by_client': // ** NEW **
			case 'appointment_reminder':
			case 'payment_successful_client':
			case 'payment_successful_admin':
			case 'scheduled_payment_failure_client':
			case 'scheduled_payment_failure_admin':
				$appointment = get_post( $object_id );
				// *** REFACTORED ***: Updated CPT name
				if ( $appointment && Constants::POST_TYPE_APPOINTMENT === $appointment->post_type ) {
					$user_id = $appointment->post_author;
				}
				break;
			case 'new_client_registration_client':
			case 'new_client_registration_admin':
				$user_id = $object_id;
				break;
		}
		if ( $user_id ) {
			$user_data = get_userdata( $user_id );
			return $user_data ? $user_data->user_email : null;
		}
		return null;
	}

	/**
	 * Prepares the data array for placeholder replacement.
	 * @return array The data array.
	 */
	private function prepare_placeholder_data( $event_type, $object_id, $data ) {
		$placeholder_data = [
			'{site_name}'                  => get_bloginfo( 'name' ),
			'{site_url}'                   => home_url(),
			'{appointment_id}'             => '',
			'{appointment_date}'           => '',
			'{appointment_date_formatted}' => '',
			'{appointment_time}'           => '',
			'{appointment_time_slot}'      => '',
			'{appointment_duration}'       => '',
			'{appointment_notes}'          => '',
			'{appointment_edit_link_admin}' => '',
			'{appointment_view_link}'      => '',
			'{client_id}'                  => '',
			'{client_name}'                => '',
			'{client_email}'               => '',
			'{phone_number}'               => '',
			'{client_username}'            => '',
			'{client_first_name}'          => '',
			'{client_last_name}'           => '',
			'{client_display_name}'        => '',
			'{order_id}'                   => '',
			'{order_total}'                => '',
			'{order_link_admin}'           => '',
			'{order_payment_method_title}' => '',
			'{failure_reason}'             => '',
		];

		$appointment = null;
		$client_user = null;

		if ( in_array(
			$event_type,
			[
				'new_appointment_client',
				'new_appointment_admin',
				'appointment_updated_admin',
				'appointment_cancelled_admin',
				'appointment_cancelled_by_client',
				'appointment_reminder',
				'payment_successful_client',
				'payment_successful_admin',
				'scheduled_payment_failure_client',
				'scheduled_payment_failure_admin',
			]
		) ) {
			$appointment = get_post( $object_id );
			// *** REFACTORED ***: Updated CPT name
			if ( $appointment && Constants::POST_TYPE_APPOINTMENT === $appointment->post_type ) {
				$placeholder_data['{appointment_id}'] = $appointment->ID;
				// *** REFACTORED ***: Updated meta key
				$appt_date_str                       = get_post_meta( $appointment->ID, Constants::META_APPOINTMENT_DATE, true );
				$placeholder_data['{appointment_date}'] = $appt_date_str;
				// *** REFACTORED ***: Updated constant name
				$appt_slot_str                           = get_post_meta( $appointment->ID, Constants::META_TIME_SLOT, true );
				$placeholder_data['{appointment_time_slot}'] = $appt_slot_str;

				if ( $appt_date_str && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $appt_date_str ) ) {
					$placeholder_data['{appointment_date_formatted}'] = wp_date( get_option( 'date_format' ), strtotime( $appt_date_str ) );
				}
				if ( $appt_slot_str ) {
					try {
						$dt_utc = new \DateTime($appt_slot_str, new \DateTimeZone('UTC'));
						$dt_site = $dt_utc->setTimezone(wp_timezone());
						$placeholder_data['{appointment_time}'] = $dt_site->format(get_option('time_format'));
					} catch (\Exception $e) {
						$placeholder_data['{appointment_time}'] = '';
					}
				}

				// *** REFACTORED ***: Updated meta key
				$placeholder_data['{appointment_duration}']      = get_post_meta( $appointment->ID, 'clisyc_appointment_duration', true );
				$placeholder_data['{appointment_notes}']         = wp_strip_all_tags( $appointment->post_content );
				$placeholder_data['{appointment_edit_link_admin}'] = get_edit_post_link( $appointment->ID, '' );
				$view_page_id                                    = get_option( Constants::OPTION_APPOINTMENT_VIEW_PAGE, 0 );
				if ( $view_page_id ) {
					$placeholder_data['{appointment_view_link}'] = add_query_arg( 'view_id', $appointment->ID, get_permalink( $view_page_id ) );
				}

				if ( $appointment->post_author > 0 ) {
					$client_user = get_userdata( $appointment->post_author );
				}
			} else {
				return null;
			}
		}

		if ( in_array( $event_type, [ 'new_client_registration_client', 'new_client_registration_admin' ] ) && ! $client_user ) {
			$client_user = get_userdata( $object_id );
		}

		if ( $client_user instanceof \WP_User ) {
			$placeholder_data['{client_id}']           = $client_user->ID;
			$placeholder_data['{client_email}']        = $client_user->user_email;
			$placeholder_data['{client_username}']     = $client_user->user_login;
			$placeholder_data['{client_first_name}']   = $client_user->first_name;
			$placeholder_data['{client_last_name}']    = $client_user->last_name;
			$placeholder_data['{client_display_name}'] = $client_user->display_name;
			$placeholder_data['{client_name}']         = ! empty( $client_user->first_name ) ? $client_user->first_name : $client_user->display_name;
			$placeholder_data['{phone_number}']        = get_user_meta( $client_user->ID, 'phone_number', true );
		} elseif ( empty( $placeholder_data['{client_name}'] ) ) {
			$placeholder_data['{client_name}'] = __( 'Valued Client', 'client-sync' ); // FIXED
		}

		$wc_order = null;
		if ( in_array( $event_type, [ 'payment_successful_client', 'payment_successful_admin', 'scheduled_payment_failure_client', 'scheduled_payment_failure_admin' ] ) && class_exists( 'WooCommerce' ) ) {
			if ( isset( $data['wc_order'] ) && $data['wc_order'] instanceof \WC_Order ) {
				$wc_order                       = $data['wc_order'];
				$placeholder_data['{order_id}'] = $wc_order->get_id();
			} elseif ( isset( $data['wc_order_id'] ) && is_numeric( $data['wc_order_id'] ) ) {
				$placeholder_data['{order_id}'] = $data['wc_order_id'];
				$wc_order                       = wc_get_order( $placeholder_data['{order_id}'] );
			} elseif ( $appointment ) {
				// *** REFACTORED ***: Updated constant name
				$order_id_from_meta = get_post_meta( $appointment->ID, Constants::META_WC_ORDER_ID, true );
				if ( $order_id_from_meta ) {
					$placeholder_data['{order_id}'] = $order_id_from_meta;
					$wc_order                       = wc_get_order( $order_id_from_meta );
				}
			}

			if ( $wc_order instanceof \WC_Order ) {
				$placeholder_data['{order_total}']                  = $wc_order->get_formatted_order_total();
				$placeholder_data['{order_link_admin}']             = esc_url( $wc_order->get_edit_order_url() );
				$placeholder_data['{order_payment_method_title}'] = $wc_order->get_payment_method_title();
			}
		}

		if ( $appointment ) {
			// *** REFACTORED ***: Updated option name
			$appointment_fields = get_option( Constants::OPTION_APPOINTMENT_FIELDS, [] );
			foreach ( $appointment_fields as $field_key => $field_config ) {
				$meta_key        = $field_key;
				$placeholder_key = '{appointment_field_' . $field_key . '}';
				$meta_value      = get_post_meta( $appointment->ID, $meta_key, true );
				if ( is_array( $meta_value ) ) {
					$placeholder_data[ $placeholder_key ] = implode( ', ', $meta_value );
				} elseif ( isset( $field_config['type'] ) && $field_config['type'] === 'image_map' && is_string( $meta_value ) ) {
					$placeholder_data[ $placeholder_key ] = __( '[Image Map Data]', 'client-sync' ); // FIXED
				} else {
					$placeholder_data[ $placeholder_key ] = $meta_value;
				}
			}
		}

		if ( in_array( $event_type, [ 'scheduled_payment_failure_client', 'scheduled_payment_failure_admin' ] ) && isset( $data['failure_reason'] ) ) {
			$placeholder_data['{failure_reason}'] = sanitize_text_field( $data['failure_reason'] );
		} elseif ( isset( $placeholder_data['{failure_reason}'] ) && empty( $placeholder_data['{failure_reason}'] ) ) {
			$placeholder_data['{failure_reason}'] = __( 'Unknown reason', 'client-sync' ); // FIXED
		}

		$placeholder_data = array_merge( $placeholder_data, $data );

		// =========================================================================
		// HIPAA COMPLIANCE: Sanitize PHI placeholders for external notifications
		// =========================================================================
		$placeholder_data = $this->maybe_anonymize_placeholders_for_hipaa( $placeholder_data, $event_type );

		// *** REFACTORED ***: Updated filter name
		return apply_filters( 'clisyc_notification_placeholder_data', $placeholder_data, $event_type, $object_id, $data );
	}

	/**
	 * Anonymize PHI placeholders when HIPAA mode is active.
	 * 
	 * When HIPAA mode is enabled and external anonymization is on, this method
	 * replaces sensitive placeholder values with generic text to prevent PHI
	 * from being exposed in emails, SMS, or other external notifications.
	 * 
	 * @param array  $placeholder_data The placeholder data array.
	 * @param string $event_type       The notification event type.
	 * @return array The (possibly anonymized) placeholder data.
	 */
	private function maybe_anonymize_placeholders_for_hipaa( array $placeholder_data, string $event_type ): array {
		// Check if HIPAA anonymization is required
		if ( ! $this->should_anonymize_for_hipaa() ) {
			return $placeholder_data;
		}

		// Define which placeholders contain PHI and should be anonymized
		$phi_placeholders = [
			// Client identifying information
			'{client_name}'         => __( 'Valued Client', 'client-sync' ),
			'{client_first_name}'   => __( 'Client', 'client-sync' ),
			'{client_last_name}'    => '',
			'{client_display_name}' => __( 'Client', 'client-sync' ),
			'{client_username}'     => __( '[Protected]', 'client-sync' ),
			'{phone_number}'        => __( '[Login to view]', 'client-sync' ),
			
			// Sensitive content
			'{appointment_notes}'   => __( '[Protected Content - Login to view]', 'client-sync' ),
		];

		// Apply anonymization to PHI placeholders
		foreach ( $phi_placeholders as $placeholder => $replacement ) {
			if ( isset( $placeholder_data[ $placeholder ] ) && ! empty( $placeholder_data[ $placeholder ] ) ) {
				$placeholder_data[ $placeholder ] = $replacement;
			}
		}

		// Anonymize custom field placeholders that may contain PHI
		// Check each appointment_field_ placeholder
		foreach ( $placeholder_data as $key => $value ) {
			if ( strpos( $key, '{appointment_field_' ) === 0 && ! empty( $value ) ) {
				// Check if this field is marked as sensitive
				$field_key = str_replace( [ '{appointment_field_', '}' ], '', $key );
				if ( $this->is_sensitive_custom_field( $field_key ) ) {
					$placeholder_data[ $key ] = __( '[Protected Content]', 'client-sync' );
				}
			}
		}

		// Note: We intentionally keep {client_email} intact for admin notifications
		// so admins can still contact clients. The email is only visible to admins
		// in the email body, not exposed to third parties.
		
		// For SMS specifically, we may want stricter controls
		// This is handled by marking the placeholder data with a flag
		$placeholder_data['_hipaa_anonymized'] = true;

		return $placeholder_data;
	}

	/**
	 * Check if HIPAA anonymization should be applied to notifications.
	 * 
	 * @return bool True if PHI should be anonymized in notifications.
	 */
	private function should_anonymize_for_hipaa(): bool {
		// Check if the HIPAA helper function exists
		if ( ! function_exists( '\DependentMedia\ClientSync\Services\clisyc_is_hipaa_mode' ) ) {
			return false;
		}
		
		// Check if HIPAA mode is active
		if ( ! \DependentMedia\ClientSync\Services\clisyc_is_hipaa_mode() ) {
			return false;
		}
		
		// Check if external notification anonymization is enabled
		// Default is true when HIPAA mode is on
		$anonymize_notifications = get_option( Constants::OPTION_ANONYMIZE_EXTERNAL_SYNC, true );
		
		return (bool) $anonymize_notifications;
	}

	/**
	 * Check if a custom field is marked as sensitive/PHI.
	 * 
	 * @param string $field_key The custom field key.
	 * @return bool True if the field should be considered sensitive.
	 */
	private function is_sensitive_custom_field( string $field_key ): bool {
		$field_defs = get_option( Constants::OPTION_APPOINTMENT_FIELDS, [] );
		
		// Check if field is explicitly marked as sensitive
		if ( isset( $field_defs[ $field_key ]['sensitive'] ) && $field_defs[ $field_key ]['sensitive'] ) {
			return true;
		}
		
		// Check if Encryption_Service considers this field sensitive
		if ( class_exists( '\DependentMedia\ClientSync\Services\Encryption_Service' ) ) {
			$encryption = \DependentMedia\ClientSync\Services\Encryption_Service::get_instance();
			if ( $encryption->should_encrypt_field( $field_key ) ) {
				return true;
			}
		}
		
		return false;
	}

	/**
	 * Returns the full array of defined notification events.
	 * This is the single source of truth for events.
	 * @return array
	 */
	public function get_event_types() {
		$events = [
			'new_appointment_client'          => [
				'label'           => __( 'New Appointment (Booked by Client)', 'client-sync' ), // FIXED
				'recipient_types' => [ 'admin', 'client' ],
				'placeholders'    => [
					'{site_name}',
					'{site_url}',
					'{client_id}',
					'{client_name}',
					'{client_email}',
					'{client_username}',
					'{client_first_name}',
					'{client_last_name}',
					'{client_display_name}',
					'{appointment_id}',
					'{appointment_date}',
					'{appointment_date_formatted}',
					'{appointment_time}',
					'{appointment_time_slot}',
					'{appointment_duration}',
					'{appointment_notes}',
					'{appointment_edit_link_admin}',
				],
			],
			'new_appointment_admin'           => [
				'label'           => __( 'New Appointment (Created by Admin)', 'client-sync' ), // FIXED
				'recipient_types' => [ 'client' ],
				'placeholders'    => [
					'{site_name}',
					'{site_url}',
					'{client_id}',
					'{client_name}',
					'{client_email}',
					'{client_username}',
					'{client_first_name}',
					'{client_last_name}',
					'{client_display_name}',
					'{appointment_id}',
					'{appointment_date}',
					'{appointment_date_formatted}',
					'{appointment_time}',
					'{appointment_time_slot}',
					'{appointment_duration}',
					'{appointment_notes}',
				],
			],
			'appointment_updated_admin'       => [
				'label'           => __( 'Appointment Updated (By Admin)', 'client-sync' ), // FIXED
				'recipient_types' => [ 'client' ],
				'placeholders'    => [
					'{site_name}',
					'{site_url}',
					'{client_id}',
					'{client_name}',
					'{client_email}',
					'{client_username}',
					'{client_first_name}',
					'{client_last_name}',
					'{client_display_name}',
					'{appointment_id}',
					'{appointment_date}',
					'{appointment_date_formatted}',
					'{appointment_time}',
					'{appointment_time_slot}',
					'{appointment_duration}',
					'{appointment_notes}',
				],
			],
			'appointment_cancelled_admin'     => [
				'label'           => __( 'Appointment Cancelled (By Admin)', 'client-sync' ), // FIXED
				'recipient_types' => [ 'client' ],
				'placeholders'    => [
					'{site_name}',
					'{site_url}',
					'{client_id}',
					'{client_name}',
					'{client_email}',
					'{client_username}',
					'{client_first_name}',
					'{client_last_name}',
					'{client_display_name}',
					'{appointment_id}',
					'{appointment_date}',
					'{appointment_date_formatted}',
					'{appointment_time}',
					'{appointment_time_slot}',
				],
			],
			// ** NEW EVENT **
			'appointment_cancelled_by_client' => [
				'label'           => __( 'Appointment Cancelled (By Client)', 'client-sync' ), // FIXED
				'recipient_types' => [ 'admin', 'client' ],
				'placeholders'    => [
					'{site_name}',
					'{site_url}',
					'{client_id}',
					'{client_name}',
					'{client_email}',
					'{appointment_id}',
					'{appointment_date_formatted}',
					'{appointment_time}',
					'{appointment_edit_link_admin}',
				],
			],
			'new_client_registration_client'  => [
				'label'           => __( 'New Client Registration (Welcome Email)', 'client-sync' ), // FIXED
				'recipient_types' => [ 'client' ],
				'placeholders'    => [
					'{site_name}',
					'{site_url}',
					'{client_id}',
					'{client_name}',
					'{client_email}',
					'{client_username}',
					'{client_first_name}',
					'{client_last_name}',
					'{client_display_name}',
				],
			],
			'new_client_registration_admin'   => [
				'label'           => __( 'New Client Registration (Admin Notification)', 'client-sync' ), // FIXED
				'recipient_types' => [ 'admin' ],
				'placeholders'    => [
					'{site_name}',
					'{site_url}',
					'{client_id}',
					'{client_name}',
					'{client_email}',
					'{client_username}',
					'{client_first_name}',
					'{client_last_name}',
					'{client_display_name}',
				],
			],
			'payment_successful_client'       => [
				'label'           => __( 'Payment Successful (Client)', 'client-sync' ), // FIXED
				'recipient_types' => [ 'client' ],
				'placeholders'    => [
					'{site_name}',
					'{site_url}',
					'{client_id}',
					'{client_name}',
					'{client_email}',
					'{appointment_id}',
					'{appointment_date_formatted}',
					'{appointment_time}',
					'{order_id}',
					'{order_total}',
					'{order_payment_method_title}',
				],
			],
			'payment_successful_admin'        => [
				'label'           => __( 'Payment Successful (Admin)', 'client-sync' ), // FIXED
				'recipient_types' => [ 'admin' ],
				'placeholders'    => [
					'{site_name}',
					'{site_url}',
					'{client_name}',
					'{client_email}',
					'{appointment_id}',
					'{appointment_date_formatted}',
					'{appointment_time}',
					'{appointment_edit_link_admin}',
					'{order_id}',
					'{order_total}',
					'{order_link_admin}',
					'{order_payment_method_title}',
				],
			],
			'scheduled_payment_failure_client' => [
				'label'           => __( 'Scheduled Payment Failed (Client)', 'client-sync' ), // FIXED
				'recipient_types' => [ 'client' ],
				'placeholders'    => [
					'{site_name}',
					'{site_url}',
					'{client_name}',
					'{appointment_date_formatted}',
					'{appointment_time}',
					'{failure_reason}',
					'{order_id}',
				],
			],
			'scheduled_payment_failure_admin' => [
				'label'           => __( 'Scheduled Payment Failed (Admin)', 'client-sync' ), // FIXED
				'recipient_types' => [ 'admin' ],
				'placeholders'    => [
					'{site_name}',
					'{site_url}',
					'{client_name}',
					'{client_email}',
					'{appointment_id}',
					'{appointment_date_formatted}',
					'{appointment_time}',
					'{appointment_edit_link_admin}',
					'{failure_reason}',
					'{order_id}',
					'{order_link_admin}',
				],
			],
			'appointment_reminder'            => [
				'label'           => __( 'Appointment Reminder (Client)', 'client-sync' ), // FIXED
				'recipient_types' => [ 'client' ],
				'placeholders'    => [
					'{site_name}',
					'{site_url}',
					'{client_id}',
					'{client_name}',
					'{client_email}',
					'{client_first_name}',
					'{client_last_name}',
					'{client_display_name}',
					'{appointment_id}',
					'{appointment_date}',
					'{appointment_date_formatted}',
					'{appointment_time}',
					'{appointment_time_slot}',
					'{appointment_duration}',
					'{appointment_view_link}',
				],
			],
		];

		// *** REFACTORED ***: Updated option name
		$appointment_fields = get_option( Constants::OPTION_APPOINTMENT_FIELDS, [] );
		$appt_event_keys    = [
			'new_appointment_client',
			'new_appointment_admin',
			'appointment_updated_admin',
			'payment_successful_client',
			'payment_successful_admin',
			'appointment_reminder',
		];
		foreach ( $events as $event_key => $event_data ) {
			if ( in_array( $event_key, $appt_event_keys ) ) {
				foreach ( $appointment_fields as $field_key => $field_config ) {
					$placeholder = '{appointment_field_' . $field_key . '}';
					if ( ! in_array( $placeholder, $events[ $event_key ]['placeholders'] ) ) {
						$events[ $event_key ]['placeholders'][] = $placeholder;
					}
				}
				sort( $events[ $event_key ]['placeholders'] );
			}
		}

		// *** REFACTORED ***: Updated filter name
		 return apply_filters( 'clisyc_notification_event_types', $events );
	}

	/**
	 * Gets the default subject and body templates for a specific event.
	 * @param string $event_type The event key.
	 * @return array An array containing default templates.
	 */
	private function get_default_templates_for_event( $event_type ) {
		$defaults        = [];
		$recipient_types = $this->get_event_types()[ $event_type ]['recipient_types'] ?? [];

		foreach ( $recipient_types as $type ) {
			$defaults[ $type . '_enabled' ] = ( $type === 'client' ); // Enable client by default
			$defaults[ $type . '_subject' ] = $this->get_default_notification_subject( $event_type, $type );
			$defaults[ $type . '_body' ]    = $this->get_default_notification_body( $event_type, $type );
		}

		return $defaults;
	}

	/**
	 * Gets default subject lines.
	 * @param string $event_type The event key.
	 * @param string $recipient_type 'client' or 'admin'.
	 * @return string Default subject.
	 */
	private function get_default_notification_subject( $event_type, $recipient_type ) {
		$subjects = [
			'new_appointment_client'           => [
				'client' => __( 'Your Appointment Confirmation - {site_name}', 'client-sync' ), // FIXED
				'admin'  => __( 'New Appointment Booking - {site_name}', 'client-sync' ), // FIXED
			],
			'new_appointment_admin'            => [ 'client' => __( 'An Appointment Was Scheduled For You - {site_name}', 'client-sync' ) ], // FIXED
			'appointment_updated_admin'        => [ 'client' => __( 'Your Appointment Details Have Been Updated - {site_name}', 'client-sync' ) ], // FIXED
			'appointment_cancelled_admin'      => [ 'client' => __( 'Your Appointment Has Been Cancelled - {site_name}', 'client-sync' ) ], // FIXED
			'appointment_cancelled_by_client'  => [ // ** NEW **
				'client' => __( 'Appointment Cancellation Confirmation - {site_name}', 'client-sync' ), // FIXED
				'admin'  => __( 'Client Cancellation: Appointment #{appointment_id} - {site_name}', 'client-sync' ), // FIXED
			],
			'new_client_registration_client'   => [ 'client' => __( 'Welcome to {site_name}!', 'client-sync' ) ], // FIXED
			'new_client_registration_admin'    => [ 'admin' => __( 'New Client Registration - {site_name}', 'client-sync' ) ], // FIXED
			'payment_successful_client'        => [ 'client' => __( 'Payment Received for Your Appointment - {site_name}', 'client-sync' ) ], // FIXED
			'payment_successful_admin'         => [ 'admin' => __( 'Payment Received for Appointment #{appointment_id} - {site_name}', 'client-sync' ) ], // FIXED
			'scheduled_payment_failure_client' => [ 'client' => __( 'Action Required: Problem Charging for Your Appointment - {site_name}', 'client-sync' ) ], // FIXED
			'scheduled_payment_failure_admin'  => [ 'admin' => __( 'Scheduled Payment FAILED for Appointment #{appointment_id} - {site_name}', 'client-sync' ) ], // FIXED
			'appointment_reminder'             => [ 'client' => __( 'Appointment Reminder for {appointment_date_formatted} at {appointment_time} - {site_name}', 'client-sync' ) ], // FIXED
		];
		return $subjects[ $event_type ][ $recipient_type ] ?? __( 'Notification from {site_name}', 'client-sync' ); // FIXED
	}

	/**
	 * Gets default email bodies.
	 * @param string $event_type The event key.
	 * @param string $recipient_type 'client' or 'admin'.
	 * @return string Default body.
	 */
	private function get_default_notification_body( $event_type, $recipient_type ) {
		$bodies = [
			'new_appointment_client'           => [
				'client' => __( "Hi {client_name},\n\nYour appointment is confirmed:\n\nDate: {appointment_date_formatted}\nTime: {appointment_time}\n\nThanks,\n{site_name}", 'client-sync' ), // FIXED
				'admin'  => __( "A new appointment has been booked:\n\nClient: {client_display_name} ({client_email})\nDate: {appointment_date_formatted}\nTime: {appointment_time}\n\nView/Edit: {appointment_edit_link_admin}", 'client-sync' ), // FIXED
			],
			'new_appointment_admin'            => [ 'client' => __( "Hi {client_name},\n\nAn administrator has scheduled an appointment for you:\n\nDate: {appointment_date_formatted}\nTime: {appointment_time}\n\nIf you have questions, please contact us.\n\nThanks,\n{site_name}", 'client-sync' ) ], // FIXED
			'appointment_updated_admin'        => [ 'client' => __( "Hi {client_name},\n\nYour appointment scheduled for {appointment_date_formatted} at {appointment_time} has been updated by an administrator.\n\nPlease contact us if you have any questions.\n\nThanks,\n{site_name}", 'client-sync' ) ], // FIXED
			'appointment_cancelled_admin'      => [ 'client' => __( "Hi {client_name},\n\nYour appointment scheduled for {appointment_date_formatted} at {appointment_time} has been cancelled by an administrator.\n\nPlease contact us if you believe this was in error or if you need to reschedule.\n\nThanks,\n{site_name}", 'client-sync' ) ], // FIXED
			'appointment_cancelled_by_client'  => [ // ** NEW **
				'client' => __( "Hi {client_name},\n\nThis confirms that your appointment scheduled for {appointment_date_formatted} at {appointment_time} has been successfully cancelled.\n\nIf you need to reschedule, please visit our booking page.\n\nThanks,\n{site_name}", 'client-sync' ), // FIXED
				'admin'  => __( "Client Cancellation Notice:\n\nThe following appointment has been cancelled by the client:\n\nClient: {client_display_name} ({client_email})\nAppointment ID: {appointment_id}\nOriginal Date & Time: {appointment_date_formatted} at {appointment_time}\n\nThe time slot has been made available again automatically.", 'client-sync' ), // FIXED
			],
			'new_client_registration_client'   => [ 'client' => __( "Hi {client_name},\n\nThank you for registering at {site_name}!\n\nYou can manage your account here: {site_url}/wp-admin/profile.php\n\nThanks,\nThe {site_name} Team", 'client-sync' ) ], // FIXED
			'new_client_registration_admin'    => [ 'admin' => __( "A new client has registered:\n\nUsername: {client_username}\nEmail: {client_email}\nName: {client_display_name}\n\nView Profile: {site_url}/wp-admin/user-edit.php?user_id={client_id}", 'client-sync' ) ], // FIXED
			'payment_successful_client'        => [ 'client' => __( "Hi {client_name},\n\nWe have successfully received payment ({order_total}) for your upcoming appointment:\n\nDate: {appointment_date_formatted}\nTime: {appointment_time}\n\nOrder Number: {order_id}\n\nWe look forward to seeing you!\n\nThanks,\n{site_name}", 'client-sync' ) ], // FIXED
			'payment_successful_admin'         => [ 'admin' => __( "Payment ({order_total}) received for appointment #{appointment_id}.\n\nClient: {client_display_name} ({client_email})\nDate: {appointment_date_formatted}\nTime: {appointment_time}\n\nWooCommerce Order: #{order_id}\nPayment Method: {order_payment_method_title}\n\nView Order: {order_link_admin}\nView Appointment: {appointment_edit_link_admin}", 'client-sync' ) ], // FIXED
			'scheduled_payment_failure_client' => [ 'client' => __( "Hi {client_name},\n\nWe encountered an issue attempting to process the scheduled payment for your upcoming appointment on {appointment_date_formatted} at {appointment_time}.\n\nReason: {failure_reason}\n\nPlease update your payment information in your account or contact us to arrange payment.\n\nThanks,\n{site_name}", 'client-sync' ) ], // FIXED
			'scheduled_payment_failure_admin'  => [ 'admin' => __( "ALERT: Scheduled payment failed for appointment #{appointment_id}.\n\nClient: {client_display_name} ({client_email})\nDate: {appointment_date_formatted}\nTime: {appointment_time}\n\nReason: {failure_reason}\n\nWooCommerce Order (Attempted): #{order_id}\nView Order: {order_link_admin}\nView Appointment: {appointment_edit_link_admin}", 'client-sync' ) ], // FIXED
			'appointment_reminder'             => [ 'client' => __( "Hi {client_name},\n\nThis is a friendly reminder for your upcoming appointment:\n\nDate: {appointment_date_formatted}\nTime: {appointment_time}\n\nIf you need to view or manage your appointment, you can do so here: {appointment_view_link}\n\nWe look forward to seeing you!\n\nThanks,\n{site_name}", 'client-sync' ) ], // FIXED
		];
		 return $bodies[ $event_type ][ $recipient_type ] ?? __( 'You have a new notification.', 'client-sync' ); // FIXED
	}

} // End of class