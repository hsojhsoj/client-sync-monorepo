<?php
/**
 * File: src/shared/includes/core/class-post-type-manager.php -> client-sync/includes/core/class-post-type-manager.php
 * Manages the registration and administrative handling of Custom Post Types.
 *
 * UPDATED: Added HIPAA compliance - encryption/decryption for sensitive custom fields.
 *
 * @package    ClientSync
 * @subpackage ClientSync/Core
 */
namespace DependentMedia\ClientSync\Core;
use DependentMedia\ClientSync\Constants;
use DependentMedia\ClientSync\Admin\Relationship_Manager;
use DependentMedia\ClientSync\Services\FormRenderer;
use DependentMedia\ClientSync\Services\Encryption_Service;
use DependentMedia\ClientSync\Utility\Sanitizer;
use DependentMedia\ClientSync\Utility\SlotCalculator;
use DependentMedia\ClientSync\Core\Cancellation_Manager;
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
class PostType_Manager {
	public function register_hooks() {
		add_action( 'init', [ $this, 'register_cpt' ] );
		add_action( 'init', [ $this, 'register_custom_statuses' ] );
		add_action( 'init', [ $this, 'register_meta_for_rest_api' ], 20 );
		if ( is_admin() ) {
			add_action( 'add_meta_boxes_clisyc_appointment', [ $this, 'add_appointment_meta_boxes' ] );
			add_action( 'save_post_clisyc_appointment', [ $this, 'save_appointment_meta_data' ], 10, 2 );
			add_action( 'add_meta_boxes', [ $this, 'add_dimension_meta_boxes' ], 10, 2 );
			add_action( 'add_meta_boxes', [ $this, 'add_dynamic_attribute_meta_boxes' ], 20, 2 );
			$registry = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
			$enabled_dimensions = $registry['dimensions'] ?? [];
			foreach ( array_keys( $enabled_dimensions ) as $cpt_slug ) {
				add_action( 'save_post_' . $cpt_slug, [ $this, 'save_dimension_meta_data' ], 10, 2 );
			}
			add_filter( 'default_content', [ $this, 'set_default_editor_content' ], 10, 2 );
			add_filter( 'display_post_states', [ $this, 'add_post_status_to_display_states' ], 10, 2 );
			add_filter( 'manage_clisyc_appointment_posts_columns', [ $this, 'add_custom_columns' ] );
			add_action( 'manage_clisyc_appointment_posts_custom_column', [ $this, 'render_custom_column_content' ], 10, 2 );
			add_filter( 'manage_edit-clisyc_appointment_sortable_columns', [ $this, 'make_columns_sortable' ] );
			add_action( 'restrict_manage_posts', [ $this, 'add_admin_list_filters' ] );
			add_action( 'pre_get_posts', [ $this, 'modify_admin_list_query' ] );
			add_action( 'wp_trash_post', [ $this, 'handle_appointment_deletion' ] );
			add_action( 'before_delete_post', [ $this, 'handle_appointment_deletion' ] );
			add_action( 'add_meta_boxes_product', [ $this, 'add_pricing_rules_meta_box' ] );
			add_action( 'save_post_product', [ $this, 'save_pricing_rules_meta_data' ] );
			
			// AJAX handler for syncing price from WooCommerce product
			add_action( 'wp_ajax_clisyc_get_product_price', [ $this, 'ajax_get_product_price' ] );
			
			// START: NEW BULK ACTIONS LOGIC
			add_filter( 'bulk_actions-edit-clisyc_appointment', [ $this, 'register_bulk_actions' ] );
			add_filter( 'handle_bulk_actions-edit-clisyc_appointment', [ $this, 'handle_bulk_actions' ], 10, 3 );
			add_action( 'admin_notices', [ $this, 'display_bulk_action_admin_notice' ] );
			// END: NEW BULK ACTIONS LOGIC
		}
	}
    // ... [Previous Bulk Actions Methods remain unchanged] ...
	public function register_bulk_actions( $bulk_actions ) {
		$bulk_actions['clisyc_mark_completed'] = __( 'Mark as Completed (Draft)', 'client-sync' );
		$bulk_actions['clisyc_cancel']         = __( 'Cancel & Restore Slot (Trash)', 'client-sync' );
		return $bulk_actions;
	}
	public function handle_bulk_actions( $redirect_to, $doaction, $post_ids ) {
		if ( 'clisyc_mark_completed' !== $doaction && 'clisyc_cancel' !== $doaction ) {
			return $redirect_to;
		}
		$updated = 0;
		$cancelled = 0;
		
		foreach ( (array) $post_ids as $post_id ) {
			if ( Constants::POST_TYPE_APPOINTMENT !== get_post_type( $post_id ) ) {
				continue;
			}
			
			if ( 'clisyc_mark_completed' === $doaction ) {
				wp_update_post( [ 'ID' => $post_id, 'post_status' => 'draft' ] );
				$updated++;
			} elseif ( 'clisyc_cancel' === $doaction ) {
				$manager = new Cancellation_Manager( $post_id );
				$result = $manager->process_cancellation( true );
				if ( $result['success'] ) {
					$cancelled++;
				}
			}
		}
		$feedback = [];
		if ( $updated > 0 ) {
			$feedback['clisyc_updated'] = $updated;
		}
		if ( $cancelled > 0 ) {
			$feedback['clisyc_cancelled'] = $cancelled;
		}
		
		return add_query_arg( $feedback, $redirect_to );
	}
	
	public function display_bulk_action_admin_notice() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! empty( $_REQUEST['clisyc_updated'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$count = absint( $_REQUEST['clisyc_updated'] );
			/* translators: %d: The number of appointments updated. */
			$message = sprintf( _n( '%d appointment marked as completed.', '%d appointments marked as completed.', $count, 'client-sync' ), $count );
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
		}
		
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! empty( $_REQUEST['clisyc_cancelled'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$count = absint( $_REQUEST['clisyc_cancelled'] );
			/* translators: %d: The number of appointments cancelled. */
			$message = sprintf( _n( '%d appointment cancelled and its slot made available.', '%d appointments cancelled and their slots made available.', $count, 'client-sync' ), $count );
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
		}
	}
    // ... [End Bulk Actions Methods] ...

	/**
	 * AJAX handler for syncing price from a WooCommerce product.
	 */
	public function ajax_get_product_price() {
		check_ajax_referer( 'clisyc_sync_price_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( [ 'message' => __( 'Permission denied.', 'client-sync' ) ] );
		}

		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;

		if ( ! $product_id ) {
			wp_send_json_error( [ 'message' => __( 'Invalid product ID.', 'client-sync' ) ] );
		}

		if ( ! class_exists( 'WooCommerce' ) || ! function_exists( 'wc_get_product' ) ) {
			wp_send_json_error( [ 'message' => __( 'WooCommerce is not active.', 'client-sync' ) ] );
		}

		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			wp_send_json_error( [ 'message' => __( 'Product not found.', 'client-sync' ) ] );
		}

		$price = $product->get_price();

		wp_send_json_success( [ 'price' => $price ] );
	}

	public function register_meta_for_rest_api() {
        // ... [No changes needed here] ...
		$registry   = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
		$post_types = [];
		if ( ! empty( $registry['dimensions'] ) ) {
			foreach ( $registry['dimensions'] as $slug => $settings ) {
				if ( ! empty( $settings['enabled'] ) ) {
					$post_types[] = $slug;
				}
			}
		}
		if ( empty( $post_types ) ) {
			$custom_types = get_option( Constants::OPTION_CUSTOM_DIMENSION_TYPES, [] );
			if ( is_array( $custom_types ) ) {
				$post_types = array_keys( $custom_types );
			}
		}
		$sanitize_callback = function( $value ) {
			if ( empty( $value ) ) {
				return '';
			}
			$decoded = json_decode( $value, true );
			return ( json_last_error() === JSON_ERROR_NONE ) ? $value : '';
		};
		foreach ( $post_types as $post_type ) {
			if ( ! post_type_exists( $post_type ) ) {
				continue;
			}
			register_post_meta(
				$post_type,
				Constants::META_SCHEDULE,
				[
					'type'              => 'string',
					'description'       => 'Weekly schedule data in JSON format',
					'single'            => true,
					'show_in_rest'      => true,
					'auth_callback'     => function () {
						return current_user_can( 'edit_posts' );
					},
					'sanitize_callback' => $sanitize_callback,
				]
			);
			register_post_meta(
				$post_type,
				Constants::META_SCHEDULE_OVERRIDES,
				[
					'type'              => 'string',
					'description'       => 'Date-specific schedule overrides in JSON format',
					'single'            => true,
					'show_in_rest'      => true,
					'auth_callback'     => function () {
						return current_user_can( 'edit_posts' );
					},
					'sanitize_callback' => $sanitize_callback,
				]
			);
		}
	}
	public function handle_appointment_deletion( int $post_id ) {
		if ( Constants::POST_TYPE_APPOINTMENT !== get_post_type( $post_id ) ) {
			return;
		}
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Custom table cleanup required.
		$wpdb->delete( $wpdb->prefix . 'clisyc_bookings', [ 'appointment_id' => $post_id ], [ '%d' ] );
	}
	public function add_dimension_meta_boxes( string $post_type, \WP_Post $post ) {
        // ... [No changes needed in the setup logic] ...
		$registry             = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
		$enabled_dimensions   = $registry['dimensions'] ?? [];
		$primary_dimension_slug = null;
		foreach ( $enabled_dimensions as $slug => $settings ) {
			if ( ! empty( $settings['primary'] ) ) {
				$primary_dimension_slug = $slug;
				break;
			}
		}
		if ( isset( $enabled_dimensions[ $post_type ] ) && $enabled_dimensions[ $post_type ]['enabled'] ) {
			Relationship_Manager::render_relationship_meta_boxes( $post, $registry );
			add_meta_box( 'clisyc-dimension-attributes-metabox', __( 'Attributes', 'client-sync' ), [ $this, 'render_color_attribute_meta_box' ], $post_type, 'side', 'default' );
			
			$sync_enabled = ! empty( $enabled_dimensions[ $post_type ]['enable_sync'] );
			
			$is_primary_or_resource = ( 
				$post_type === $primary_dimension_slug || 
				! empty( $enabled_dimensions[ $post_type ]['is_resource'] )
			);
			if ( $post_type === $primary_dimension_slug ) {
				add_meta_box( 'clisyc-primary-attributes-metabox', __( 'Primary Attributes', 'client-sync' ), [ $this, 'render_primary_dimension_attributes_meta_box' ], $post_type, 'normal', 'high' );
				add_meta_box( 'clisyc-linking-metabox', __( 'Direct Link & Shortcode', 'client-sync' ), [ $this, 'render_service_linking_meta_box' ], $post_type, 'side', 'low' );
			}
			// NOTE: Moved out of the $primary_dimension_slug block to support linking WC products to any dimension
			if ( class_exists( 'WooCommerce' ) && get_option( Constants::OPTION_WC_ENABLED ) ) {
				add_meta_box( 'clisyc-woocommerce-metabox', __( 'WooCommerce Integration', 'client-sync' ), [ $this, 'render_woocommerce_meta_box' ], $post_type, 'normal', 'high' );
			}
			if ( $is_primary_or_resource ) {
				$schedule_box_title = ( $post_type === $primary_dimension_slug ) ? __( 'Base Weekly Schedule', 'client-sync' ) : __( 'Resource Availability Schedule', 'client-sync' );
				add_meta_box( 'clisyc-service-schedule-metabox', $schedule_box_title, [ $this, 'render_service_schedule_meta_box' ], $post_type, 'normal', 'high' );
				add_meta_box( 'clisyc-schedule-pattern-metabox', __( 'Schedule Pattern (Rotation)', 'client-sync' ), [ $this, 'render_schedule_pattern_meta_box' ], $post_type, 'side', 'default' );
				add_meta_box( 'clisyc-schedule-overrides-metabox', __( 'Schedule Overrides', 'client-sync' ), [ $this, 'render_schedule_overrides_meta_box' ], $post_type, 'normal', 'default' );
			}
			
			if ( $sync_enabled ) {
				add_meta_box(
					'clisyc-employee-user-link-metabox',
					__( 'Link WordPress User', 'client-sync' ),
					[ $this, 'render_employee_user_link_meta_box' ],
					$post_type,
					'side',
					'high'
				);
				if ( function_exists( 'clisyc_pro_is_license_active' ) && clisyc_pro_is_license_active() ) {
					add_meta_box(
						'clisyc-google-sync-metabox',
						__( 'Calendar Sync', 'client-sync' ),
						[ $this, 'render_google_sync_meta_box' ],
						$post_type,
						'side',
						'default'
					);
				}
			}
			
			global $wpdb;
			$rels_table = $wpdb->prefix . 'clisyc_relationships';
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $rels_table is safely constructed from $wpdb->prefix.
			$sql = "SELECT COUNT(*) FROM {$rels_table} WHERE parent_object_id = %d OR child_object_id = %d";
			
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Custom query for relationship count. $sql contains valid SQL.
			$connection_count = $wpdb->get_var( $wpdb->prepare( $sql, $post->ID, $post->ID ) );
			if ( (int) $connection_count === 0 ) {
				add_meta_box(
					'clisyc-no-relationships-notice',
					__( 'Configuration Notice', 'client-sync' ),
					function() {
						$graph_url = esc_url( admin_url( 'admin.php?page=clisyc-dimensions&tab=graph' ) );
						/* translators: %s: URL to the relationship graph. */
						$notice_text = __( 'This item is not connected to any other dimensions. It may not be bookable until you link it to other items (like a Practitioner or Room) in the <a href="%s">Relationship Graph</a>.', 'client-sync' );
						echo '<p>' . wp_kses( sprintf( $notice_text, $graph_url ), [ 'a' => [ 'href' => [] ] ] ) . '</p>';
					},
					$post_type,
					'side',
					'high'
				);
			}
		}
	}
    // ... [add_dynamic_attribute_meta_boxes, render_dynamic_attribute_meta_box, render_schedule_overrides_meta_box remain unchanged] ...
	public function add_dynamic_attribute_meta_boxes( string $post_type, \WP_Post $post ) {
		$dimension_fields = get_option( Constants::OPTION_DIMENSION_FIELDS, [] );
		if ( empty( $dimension_fields ) ) {
			return;
		}
		foreach ( $dimension_fields as $key => $field ) {
			if ( in_array( $post_type, $field['applies_to'], true ) ) {
				add_meta_box(
					'clisyc_attr_' . $key,
					esc_html( $field['label'] ),
					[ $this, 'render_dynamic_attribute_meta_box' ],
					$post_type,
					'side',
					'default',
					[ 'field_key' => $key, 'field_def' => $field ]
				);
			}
		}
	}
	public function render_dynamic_attribute_meta_box( \WP_Post $post, array $metabox ) {
		$field_key    = $metabox['args']['field_key'];
		$field_def    = $metabox['args']['field_def'];
		$prefixed_key = '_clisyc_' . $field_key;
		$value        = get_post_meta( $post->ID, $prefixed_key, true );
		wp_nonce_field( 'clisyc_save_dynamic_attributes_nonce', 'clisyc_dynamic_attributes_nonce' );
		switch ( $field_def['type'] ) {
			case 'number':
				echo '<input type="number" name="' . esc_attr( $field_key ) . '" value="' . esc_attr( $value ) . '" class="widefat">';
				break;
			case 'select':
				$options = array_map( 'trim', explode( ',', $field_def['options'] ) );
				echo '<select name="' . esc_attr( $field_key ) . '" class="widefat">';
				echo '<option value="">—</option>';
				foreach ( $options as $option ) {
					echo '<option value="' . esc_attr( $option ) . '" ' . selected( $value, $option, false ) . '>' . esc_html( $option ) . '</option>';
				}
				echo '</select>';
				break;
			case 'text':
			default:
				echo '<input type="text" name="' . esc_attr( $field_key ) . '" value="' . esc_attr( $value ) . '" class="widefat">';
				break;
		}
	}
	public function render_schedule_overrides_meta_box( \WP_Post $post ) {
		$overrides_json = get_post_meta( $post->ID, Constants::META_SCHEDULE_OVERRIDES, true );
		?>
		<div class="clisyc-admin-instructions-metabox">
			<p><?php esc_html_e( 'Use this calendar to override the base weekly schedule for specific dates.', 'client-sync' ); ?></p>
			<ol>
				<li><?php esc_html_e( 'Click any date to set an override.', 'client-sync' ); ?></li>
				<li><?php esc_html_e( 'You can mark the day as "Closed" or define custom hours just for that day.', 'client-sync' ); ?></li>
				<li><?php esc_html_e( 'Dates with an active override are highlighted in yellow.', 'client-sync' ); ?></li>
			</ol>
			<p><em><?php esc_html_e( 'Note: Changes made here are saved when you click the main "Update" button for this post.', 'client-sync' ); ?></em></p>
		</div>
		<div id="clisyc-override-datepicker"></div>
		<textarea name="_clisyc_schedule_overrides" id="clisyc_schedule_overrides_json" style="display:none;"><?php echo esc_textarea( $overrides_json ); ?></textarea>
		<div id="clisyc-override-dialog" title="Set Date Override" style="display:none;">
			<form id="clisyc-override-dialog-form">
				<fieldset>
					<p><strong><?php esc_html_e( 'Override for:', 'client-sync' ); ?> <span id="clisyc-override-dialog-date"></span></strong></p>
					<div class="clisyc-override-option">
						<input type="radio" name="override_type" id="override_type_default" value="default" checked="checked">
						<label for="override_type_default"><?php esc_html_e( 'Default (Use Base Weekly Schedule)', 'client-sync' ); ?></label>
					</div>
					<div class="clisyc-override-option">
						<input type="radio" name="override_type" id="override_type_closed" value="closed">
						<label for="override_type_closed"><?php esc_html_e( 'Closed / Day Off', 'client-sync' ); ?></label>
					</div>
					<div class="clisyc-override-option">
						<input type="radio" name="override_type" id="override_type_custom" value="custom">
						<label for="override_type_custom"><?php esc_html_e( 'Custom Hours', 'client-sync' ); ?></label>
					</div>
					<div id="clisyc-override-custom-hours-editor" style="display:none; margin-top: 1em;">
						<div id="clisyc-override-calendar-instance">
							<p style="text-align:center; padding: 30px;"><?php esc_html_e( 'Loading Editor...', 'client-sync' ); ?></p>
						</div>
					</div>
				</fieldset>
			</form>
		</div>
		<?php
	}

	/**
	 * Renders the Attributes meta box (sidebar) - Color only.
	 * UPDATED: Removed Display Price field - now consolidated in WooCommerce Integration meta box.
	 */
	public function render_color_attribute_meta_box( \WP_Post $post ) {
		wp_nonce_field( 'clisyc_save_color_meta_nonce_' . $post->ID, 'clisyc_color_meta_nonce' );
		$color = get_post_meta( $post->ID, Constants::META_COLOR, true );
		?>
		<p>
			<label for="clisyc_color"><?php esc_html_e( 'Calendar Color', 'client-sync' ); ?></label><br>
			<input type="text" id="clisyc_color" name="clisyc_color" value="<?php echo esc_attr( $color ); ?>" class="clisyc-color-picker">
		</p>
		<p class="description"><?php esc_html_e( 'Choose a color to represent this item on calendars and in dropdowns.', 'client-sync' ); ?></p>
		<?php
		// REMOVED: Display Price field - now in WooCommerce Integration meta box for all dimensions
	}

	/**
	 * Renders the Primary Attributes meta box (main content area for primary dimension).
	 * UPDATED: Removed Display Price field - now consolidated in WooCommerce Integration meta box.
	 */
	public function render_primary_dimension_attributes_meta_box( \WP_Post $post ) {
		wp_nonce_field( 'clisyc_save_service_meta_nonce_' . $post->ID, 'clisyc_service_meta_nonce' );
		$buffer_before      = get_post_meta( $post->ID, Constants::META_BUFFER_BEFORE, true );
		$buffer_after       = get_post_meta( $post->ID, Constants::META_BUFFER_AFTER, true );
		$capacity           = get_post_meta( $post->ID, Constants::META_CAPACITY, true );
		$booking_mode       = get_post_meta( $post->ID, Constants::META_BOOKING_MODE, true ) ?: 'slot';
		$duration_minutes_raw = get_post_meta( $post->ID, Constants::META_DURATION_MINUTES, true );
		$duration_minutes     = ( '' !== $duration_minutes_raw && false !== $duration_minutes_raw ) ? $duration_minutes_raw : 60;
		$padding_minutes      = get_post_meta( $post->ID, Constants::META_PADDING_MINUTES, true );
		// REMOVED: Price retrieval - now in WooCommerce Integration meta box
		?>
		<div class="clisyc-admin-instructions-metabox">
			<p><?php echo wp_kses_post( __( 'Set the duration and capacity for this service. In the <strong>Base Weekly Schedule</strong> box below, you can either draw large blocks of availability (e.g., 9am-5pm) which will be auto-filled with slots of the duration you set, or draw the exact individual slots you want to offer.', 'client-sync' ) ); ?></p>
		</div>
		<table class="form-table">
			<!-- REMOVED: Display Price Field - now in WooCommerce Integration meta box -->
			<tr>
				<th><label for="clisyc_capacity"><?php esc_html_e( 'Capacity', 'client-sync' ); ?></label></th>
				<td>
					<input type="number" id="clisyc_capacity" name="clisyc_capacity" value="<?php echo esc_attr( $capacity ); ?>" class="small-text" placeholder="1" min="1" step="1">
					<p class="description"><?php esc_html_e( 'Number of simultaneous bookings for a single slot (e.g., for a class). Leave as 1 for individual appointments.', 'client-sync' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label><?php esc_html_e( 'Booking Mode', 'client-sync' ); ?></label></th>
				<td>
					<fieldset>
						<legend class="screen-reader-text"><span><?php esc_html_e( 'Booking Mode', 'client-sync' ); ?></span></legend>
						<label style="display: block; margin-bottom: 5px;"><input type="radio" name="clisyc_booking_mode" value="slot" <?php checked( $booking_mode, 'slot' ); ?>> <?php esc_html_e( 'Time Slot (Fixed duration appointments)', 'client-sync' ); ?></label>
						<label style="display: block;"><input type="radio" name="clisyc_booking_mode" value="date_range" <?php checked( $booking_mode, 'date_range' ); ?>> <?php esc_html_e( 'Date Range (Per day/night bookings)', 'client-sync' ); ?></label>
						<p class="description"><?php esc_html_e( 'Choose "Date Range" for multi-day bookings like rentals or hotel stays.', 'client-sync' ); ?></p>
					</fieldset>
				</td>
			</tr>
			<tr class="clisyc-time-slot-setting">
				<th><label for="clisyc_duration_minutes"><?php esc_html_e( 'Appointment Duration', 'client-sync' ); ?></label></th>
				<td>
					<input type="number" id="clisyc_duration_minutes" name="clisyc_duration_minutes" value="<?php echo esc_attr( $duration_minutes ); ?>" class="small-text" placeholder="60" min="1" step="1">
					<p class="description"><?php esc_html_e( 'The duration of a single appointment in minutes. This is used to automatically generate slots from your weekly schedule.', 'client-sync' ); ?></p>
				</td>
			</tr>
			<tr class="clisyc-time-slot-setting">
				<th><label for="clisyc_padding_minutes"><?php esc_html_e( 'Padding / Cleanup Time', 'client-sync' ); ?></label></th>
				<td>
					<input type="number" id="clisyc_padding_minutes" name="clisyc_padding_minutes" value="<?php echo esc_attr( $padding_minutes ); ?>" class="small-text" placeholder="0" min="0" step="1">
					<p class="description"><?php esc_html_e( 'Time in minutes to block off *after* an appointment for preparation. This is not visible to clients.', 'client-sync' ); ?></p>
				</td>
			</tr>
			<tr class="clisyc-time-slot-setting">
				<th><label><?php esc_html_e( 'Buffers (minutes)', 'client-sync' ); ?></label></th>
				<td>
					<label for="clisyc_buffer_before" style="margin-right:15px;"><?php esc_html_e( 'Before:', 'client-sync' ); ?> <input type="number" id="clisyc_buffer_before" name="clisyc_buffer_before" value="<?php echo esc_attr( $buffer_before ); ?>" class="small-text" placeholder="0" min="0"></label>
					<label for="clisyc_buffer_after"><?php esc_html_e( 'After:', 'client-sync' ); ?> <input type="number" id="clisyc_buffer_after" name="clisyc_buffer_after" value="<?php echo esc_attr( $buffer_after ); ?>" class="small-text" placeholder="0" min="0"></label>
				</td>
			</tr>
			<tr class="clisyc-date-range-setting">
				<th><label><?php esc_html_e( 'Multi-Day Booking Rules', 'client-sync' ); ?></label></th>
				<td>
					<fieldset>
						<legend class="screen-reader-text"><span><?php esc_html_e( 'Multi-Day Booking Rules', 'client-sync' ); ?></span></legend>
						<p style="margin-top:0;"><label for="clisyc_min_stay" style="display:inline-block; width: 150px;"><?php esc_html_e( 'Minimum Stay (nights)', 'client-sync' ); ?></label> <input type="number" id="clisyc_min_stay" name="clisyc_min_stay" value="<?php echo esc_attr( get_post_meta( $post->ID, Constants::META_MIN_STAY, true ) ); ?>" class="small-text" placeholder="1" min="0" step="1"></p>
						<p><label for="clisyc_max_stay" style="display:inline-block; width: 150px;"><?php esc_html_e( 'Maximum Stay (nights)', 'client-sync' ); ?></label> <input type="number" id="clisyc_max_stay" name="clisyc_max_stay" value="<?php echo esc_attr( get_post_meta( $post->ID, Constants::META_MAX_STAY, true ) ); ?>" class="small-text" placeholder="30" min="0" step="1"></p>
						<p><label for="clisyc_buffer_days" style="display:inline-block; width: 150px;"><?php esc_html_e( 'Turnover/Buffer Days', 'client-sync' ); ?></label> <input type="number" id="clisyc_buffer_days" name="clisyc_buffer_days" value="<?php echo esc_attr( get_post_meta( $post->ID, Constants::META_BUFFER_DAYS, true ) ); ?>" class="small-text" placeholder="0" min="0" step="1"> <span class="description"><?php esc_html_e( 'Days to block off for cleaning/prep after a booking ends.', 'client-sync' ); ?></span></p>
					</fieldset>
				</td>
			</tr>
			<tr class="clisyc-date-range-setting">
				<th><label><?php esc_html_e( 'Booking Day Rules', 'client-sync' ); ?></label></th>
				<td>
					<?php
					$days_of_week = [ 0 => 'Sun', 1 => 'Mon', 2 => 'Tue', 3 => 'Wed', 4 => 'Thu', 5 => 'Fri', 6 => 'Sat' ];
					$saved_checkin_days     = get_post_meta( $post->ID, Constants::META_ALLOWED_CHECKIN, true );
					$saved_checkout_days    = get_post_meta( $post->ID, Constants::META_ALLOWED_CHECKOUT, true );
					
					$allowed_checkin_days  = ( '' === $saved_checkin_days ) ? array_keys( $days_of_week ) : (array) $saved_checkin_days;
					$allowed_checkout_days = ( '' === $saved_checkout_days ) ? array_keys( $days_of_week ) : (array) $saved_checkout_days;
					?>
					<fieldset style="margin-bottom: 1em;">
						<legend><strong><?php esc_html_e( 'Allowed Start Days', 'client-sync' ); ?></strong></legend>
						<?php foreach ( $days_of_week as $day_index => $day_abbr ) : ?>
							<label style="display:inline-block; margin-right: 15px;"><input type="checkbox" name="_clisyc_allowed_checkin_days[]" value="<?php echo esc_attr( $day_index ); ?>" <?php checked( in_array( $day_index, $allowed_checkin_days, true ) ); ?>> <?php echo esc_html( $day_abbr ); ?></label>
						<?php endforeach; ?>
					</fieldset>
					<fieldset>
						<legend><strong><?php esc_html_e( 'Allowed End Days', 'client-sync' ); ?></strong></legend>
						<?php foreach ( $days_of_week as $day_index => $day_abbr ) : ?>
							<label style="display:inline-block; margin-right: 15px;"><input type="checkbox" name="_clisyc_allowed_checkout_days[]" value="<?php echo esc_attr( $day_index ); ?>" <?php checked( in_array( $day_index, $allowed_checkout_days, true ) ); ?>> <?php echo esc_html( $day_abbr ); ?></label>
						<?php endforeach; ?>
					</fieldset>
					<p class="description"><?php esc_html_e( 'Uncheck a day to prevent users from beginning or ending bookings on that day.', 'client-sync' ); ?></p>
				</td>
			</tr>
		</table>
		<?php
	}
	public function render_schedule_pattern_meta_box( \WP_Post $post ) {
		require clisyc_PLUGIN_DIR . 'includes/admin/views/template-parts/part-schedule-pattern.php';
	}
	public function save_dimension_meta_data( int $post_id, \WP_Post $post ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$registry       = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
		$unslashed_post = wp_unslash( $_POST );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce check is handled within the called method if nonce is present.
		if ( isset( $unslashed_post['clisyc_relationships_nonce'] ) && wp_verify_nonce( sanitize_key( $unslashed_post['clisyc_relationships_nonce'] ), 'clisyc_save_relationships_' . $post_id ) ) {
			Relationship_Manager::save_relationships( $post_id, $registry );
		}
		// Save WooCommerce integration data (including Display Price for ALL dimensions)
		if ( isset( $unslashed_post['clisyc_wc_meta_nonce'] ) && wp_verify_nonce( sanitize_key( $unslashed_post['clisyc_wc_meta_nonce'] ), 'clisyc_save_wc_meta_nonce_' . $post_id ) ) {
			// Save standard linked product
			$product_id = isset( $unslashed_post['clisyc_wc_product_id'] ) ? absint( $unslashed_post['clisyc_wc_product_id'] ) : 0;
			update_post_meta( $post_id, Constants::META_WC_PRODUCT_ID, $product_id );
			
			// Save calculation type
			$calc_type = isset( $unslashed_post['clisyc_addon_calc_type'] ) ? sanitize_key( $unslashed_post['clisyc_addon_calc_type'] ) : 'per_night';
			update_post_meta( $post_id, Constants::META_ADDON_CALC_TYPE, $calc_type );
			
			// Save Additional Products Repeater
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$raw_additional = isset( $unslashed_post['_clisyc_additional_products'] ) ? $unslashed_post['_clisyc_additional_products'] : [];
			$sanitized_additional = [];
			
			foreach ( (array) $raw_additional as $item ) {
				if ( ! empty( $item['product_id'] ) ) {
					$sanitized_additional[] = [
						'product_id' => absint( $item['product_id'] ),
						'calc_type'  => sanitize_key( $item['calc_type'] ?? 'flat' )
					];
				}
			}
			update_post_meta( $post_id, Constants::META_ADDITIONAL_PRODUCTS, $sanitized_additional );

			// CONSOLIDATED: Save Display Price for ALL dimensions (primary and secondary)
			if ( isset( $unslashed_post['clisyc_price'] ) ) {
				update_post_meta( $post_id, Constants::META_PRICE, sanitize_text_field( $unslashed_post['clisyc_price'] ) );
			}
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce check is handled within the called method if nonce is present.
		if ( isset( $unslashed_post['clisyc_service_meta_nonce'] ) && wp_verify_nonce( sanitize_key( $unslashed_post['clisyc_service_meta_nonce'] ), 'clisyc_save_service_meta_nonce_' . $post_id ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			update_post_meta( $post_id, Constants::META_CAPACITY, isset( $unslashed_post['clisyc_capacity'] ) ? max( 1, absint( $unslashed_post['clisyc_capacity'] ) ) : 1 );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			update_post_meta( $post_id, Constants::META_BUFFER_BEFORE, isset( $unslashed_post['clisyc_buffer_before'] ) ? absint( $unslashed_post['clisyc_buffer_before'] ) : 0 );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			update_post_meta( $post_id, Constants::META_BUFFER_AFTER, isset( $unslashed_post['clisyc_buffer_after'] ) ? absint( $unslashed_post['clisyc_buffer_after'] ) : 0 );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			$duration_raw = isset( $unslashed_post['clisyc_duration_minutes'] ) ? trim( $unslashed_post['clisyc_duration_minutes'] ) : '';
			$duration     = ( '' !== $duration_raw ) ? absint( $duration_raw ) : null;
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			$padding  = isset( $unslashed_post['clisyc_padding_minutes'] ) ? absint( $unslashed_post['clisyc_padding_minutes'] ) : 0;
			// Only persist duration if a value was explicitly provided (not blank placeholder).
			if ( null !== $duration ) {
				update_post_meta( $post_id, Constants::META_DURATION_MINUTES, $duration );
			}
			update_post_meta( $post_id, Constants::META_PADDING_MINUTES, $padding );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			update_post_meta( $post_id, Constants::META_MIN_STAY, isset( $unslashed_post['clisyc_min_stay'] ) ? absint( $unslashed_post['clisyc_min_stay'] ) : 0 );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			update_post_meta( $post_id, Constants::META_MAX_STAY, isset( $unslashed_post['clisyc_max_stay'] ) ? absint( $unslashed_post['clisyc_max_stay'] ) : 0 );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			update_post_meta( $post_id, Constants::META_BUFFER_DAYS, isset( $unslashed_post['clisyc_buffer_days'] ) ? absint( $unslashed_post['clisyc_buffer_days'] ) : 0 );
			
			// REMOVED: Display Price save - now handled in WC nonce block above
			
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			$booking_mode = sanitize_key( $unslashed_post['clisyc_booking_mode'] ?? 'slot' );
			if ( in_array( $booking_mode, [ 'slot', 'date_range' ], true ) ) {
				update_post_meta( $post_id, Constants::META_BOOKING_MODE, $booking_mode );
			}
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			$checkin_days = isset( $unslashed_post['_clisyc_allowed_checkin_days'] ) && is_array( $unslashed_post['_clisyc_allowed_checkin_days'] )
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
				? array_map( 'absint', $unslashed_post['_clisyc_allowed_checkin_days'] )
				: [];
			update_post_meta( $post_id, Constants::META_ALLOWED_CHECKIN, $checkin_days );
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			$checkout_days = isset( $unslashed_post['_clisyc_allowed_checkout_days'] ) && is_array( $unslashed_post['_clisyc_allowed_checkout_days'] )
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
				? array_map( 'absint', $unslashed_post['_clisyc_allowed_checkout_days'] )
				: [];
			update_post_meta( $post_id, Constants::META_ALLOWED_CHECKOUT, $checkout_days );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce check is handled within the called method if nonce is present.
		if ( isset( $unslashed_post['clisyc_color_meta_nonce'] ) && wp_verify_nonce( sanitize_key( $unslashed_post['clisyc_color_meta_nonce'] ), 'clisyc_save_color_meta_nonce_' . $post_id ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			if ( isset( $unslashed_post['clisyc_color'] ) ) {
				// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
				update_post_meta( $post_id, Constants::META_COLOR, sanitize_hex_color( $unslashed_post['clisyc_color'] ) );
			}
			// REMOVED: Display Price save - now handled in WC nonce block above
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce check is handled within the called method if nonce is present.
		if ( isset( $unslashed_post['clisyc_employee_user_link_nonce'] ) && wp_verify_nonce( sanitize_key( $unslashed_post['clisyc_employee_user_link_nonce'] ), 'clisyc_save_employee_user_link_nonce_' . $post_id ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			$user_id_to_link = isset( $unslashed_post['_clisyc_employee_user_id'] ) ? absint( $unslashed_post['_clisyc_employee_user_id'] ) : 0;
			update_post_meta( $post_id, Constants::META_EMPLOYEE_USER_ID, $user_id_to_link );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce check is handled within the called method if nonce is present.
		if ( isset( $_POST['clisyc_dynamic_attributes_nonce'] ) && wp_verify_nonce( sanitize_key( wp_unslash( $_POST['clisyc_dynamic_attributes_nonce'] ) ), 'clisyc_save_dynamic_attributes_nonce' ) ) {
			$dimension_fields = get_option( Constants::OPTION_DIMENSION_FIELDS, [] );
			foreach ( $dimension_fields as $key => $field ) {
				if ( in_array( $post->post_type, $field['applies_to'], true ) ) {
					$prefixed_key = '_clisyc_' . $key;
					// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
					if ( isset( $_POST[ $key ] ) ) {
						// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
						$value = sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
						update_post_meta( $post_id, $prefixed_key, $value );
					} else {
						delete_post_meta( $post_id, $prefixed_key );
					}
				}
			}
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified in specific blocks above, or this is open meta saving.
		if ( isset( $unslashed_post['_clisyc_schedule_json'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified in specific blocks above, or this is open meta saving.
			$schedule_json = $unslashed_post['_clisyc_schedule_json'];
			$decoded = json_decode( $schedule_json, true );
			if ( json_last_error() === JSON_ERROR_NONE && is_array( $decoded ) ) {
				update_post_meta( $post_id, Constants::META_SCHEDULE, $schedule_json );
			}
		} else {
			if ( ! get_post_meta( $post_id, Constants::META_SCHEDULE, true ) ) {
				update_post_meta( $post_id, Constants::META_SCHEDULE, '{"templates":{"A":{}}}' );
			}
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified in specific blocks above, or this is open meta saving.
		if ( isset( $unslashed_post['_clisyc_schedule_overrides'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified in specific blocks above, or this is open meta saving.
			$overrides_json = sanitize_textarea_field( $unslashed_post['_clisyc_schedule_overrides'] );
			update_post_meta( $post_id, Constants::META_SCHEDULE_OVERRIDES, $overrides_json );
		}
	}
    // ... [add_appointment_meta_boxes, render_reference_calendar, render_appointment_context_meta_box, render_assign_client_meta_box, render_time_slot_meta_box, render_service_schedule_meta_box, render_appointment_details_meta_box, save_appointment_meta_data remain unchanged] ...
	public function add_appointment_meta_boxes() {
		add_meta_box( 'clisyc-assign-client-metabox', __( 'Assign Client', 'client-sync' ), [ $this, 'render_assign_client_meta_box' ], Constants::POST_TYPE_APPOINTMENT, 'side', 'high' );
		add_meta_box( 'clisyc-time-slot-metabox', __( 'Appointment Time Slot', 'client-sync' ), [ $this, 'render_time_slot_meta_box' ], Constants::POST_TYPE_APPOINTMENT, 'side', 'high' );
        
        add_meta_box( 'clisyc-appointment-context-metabox', __( 'Appointment Context', 'client-sync' ), [ $this, 'render_appointment_context_meta_box' ], Constants::POST_TYPE_APPOINTMENT, 'normal', 'high' );
		// NEW: Add context calendar
		add_meta_box( 
			'clisyc-appointment-reference-calendar', 
			__( 'Reference Calendar', 'client-sync' ), 
			[ $this, 'render_reference_calendar' ], 
			Constants::POST_TYPE_APPOINTMENT,
			'normal',
			'default'
		);
		add_meta_box( 'clisyc-appointment-details-metabox', __( 'Appointment Custom Details', 'client-sync' ), [ $this, 'render_appointment_details_meta_box' ], Constants::POST_TYPE_APPOINTMENT, 'normal', 'high' );
	}
	public function render_reference_calendar( \WP_Post $post ) {
		// 1. Find which item is booked in this appointment
		$dimensions = get_post_meta( $post->ID, Constants::META_SLOT_DIMENSIONS, true );

		// Find primary dimension from registry to filter the calendar
		$registry = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
		$primary_slug = null;
		foreach ( $registry['dimensions'] ?? [] as $slug => $settings ) {
			if ( ! empty( $settings['primary'] ) ) {
				$primary_slug = $slug;
				break;
			}
		}
		
		$linked_item_id = $dimensions[$primary_slug] ?? 0;
		
		// Reuse the container structure so the same JS can pick it up, 
		// BUT overwrite the JS data variable for this page context.
		?>
		<div id="clisyc-item-availability-calendar">
			<div id="clisyc-admin-item-calendar" style="min-height: 500px;"></div>
		</div>
		<script>
			// Manually inject config for this specific appointment context
			window.clisycItemCalendarData = <?php echo wp_json_encode( [
				'postId'      => (int) $linked_item_id,
				'postType'    => $primary_slug,
				'restUrl'     => esc_url_raw( rest_url( 'clisyc/v1/slots' ) ),
				'nonce'       => wp_create_nonce( 'wp_rest' ),
				'editUrlBase' => admin_url( 'post.php?action=edit&post=' ),
			] ); ?>;
		</script>
		<?php
	}
    public function render_appointment_context_meta_box( \WP_Post $post ) {
        $dimensions   = get_post_meta( $post->ID, Constants::META_SLOT_DIMENSIONS, true );
        $custom_types = get_option( Constants::OPTION_CUSTOM_DIMENSION_TYPES, [] );
        // For auto-draft posts (newly created from Slots List), read dimensions from URL params
        if ( ( empty( $dimensions ) || ! is_array( $dimensions ) ) && 'auto-draft' === $post->post_status ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading URL params to pre-fill form fields, not processing submission.
            $unslashed_get = wp_unslash( $_GET );
            $dimensions    = [];
            
            foreach ( $unslashed_get as $key => $value ) {
                if ( strpos( $key, 'clisyc_dim_' ) === 0 ) {
                    $dim_key = str_replace( 'clisyc_dim_', '', $key );
                    $dim_key = sanitize_key( $dim_key );
                    $dimensions[ $dim_key ] = absint( $value );
                }
            }
        }
        if ( empty( $dimensions ) || ! is_array( $dimensions ) ) {
            echo '<p><em>' . esc_html__( 'No dimension details found for this appointment.', 'client-sync' ) . '</em></p>';
            return;
        }
        echo '<table class="form-table"><tbody>';
        foreach ( $dimensions as $slug => $dim_post_id ) {
            $cpt_label  = $custom_types[ $slug ]['singular'] ?? ucfirst( str_replace( [ 'clisyc_', '_' ], [ '', ' ' ], $slug ) );
            $item_title = get_the_title( $dim_post_id );
            $edit_link  = get_edit_post_link( $dim_post_id, 'raw' );
            ?>
            <tr>
                <th scope="row"><?php echo esc_html( $cpt_label ); ?></th>
                <td>
                    <?php if ( $item_title && $edit_link ) : ?>
                        <a href="<?php echo esc_url( $edit_link ); ?>" target="_blank">
                            <?php echo esc_html( $item_title ); ?>
                            <span class="dashicons dashicons-external" style="font-size: 14px; vertical-align: text-top;"></span>
                        </a>
                    <?php elseif ( $item_title ) : ?>
                        <?php echo esc_html( $item_title ); ?>
                    <?php else : ?>
                        <em><?php esc_html_e( 'Item not found', 'client-sync' ); ?> (ID: <?php echo esc_html( $dim_post_id ); ?>)</em>
                    <?php endif; ?>
                    <!-- Hidden field to preserve dimension data for saving -->
                    <input type="hidden" name="clisyc_slot_dimensions[<?php echo esc_attr( $slug ); ?>]" value="<?php echo esc_attr( $dim_post_id ); ?>">
                </td>
            </tr>
            <?php
        }
        echo '</tbody></table>';
    }
	/**
	 * Renders the Assign Client metabox with searchable autocomplete.
	 *
	 * @param \WP_Post $post The current post object.
	 */
	public function render_assign_client_meta_box( \WP_Post $post ) {
		// Get current author (client) ID
		$current_client_id = $post->post_author;
		$client_roles      = apply_filters( 'clisyc_client_user_roles_admin', [ 'subscriber', 'customer', 'administrator', 'editor', 'author' ] );
		
		?>
		<div class="clisyc-client-search-container">
			<!-- Selected client display (populated via JS if client is pre-selected) -->
			<div class="clisyc-client-selected" id="clisyc-client-selected"></div>
			<!-- Search input wrapper -->
			<div class="clisyc-client-search-input-wrapper">
				<span class="dashicons dashicons-search"></span>
				<input 
					type="text" 
					id="clisyc-client-search-input"
					class="clisyc-client-search-input"
					placeholder="<?php esc_attr_e( 'Type to search clients by name or email...', 'client-sync' ); ?>"
					autocomplete="off"
				/>
			</div>
			<!-- Hidden field to store the selected user ID -->
			<input 
				type="hidden" 
				id="clisyc-client-id"
				name="clisyc_client_id" 
				value="<?php echo esc_attr( $current_client_id ); ?>"
			/>
			<!-- Search results dropdown -->
			<div id="clisyc-client-search-results" class="clisyc-client-search-results"></div>
			<p class="clisyc-client-search-help">
				<?php
				/* translators: %s: A comma-separated list of user roles (e.g., "subscriber, customer"). */
				$description_text = __( 'Assign this appointment to a user with the role(s): %s.', 'client-sync' );
				echo esc_html( sprintf( $description_text, implode( ', ', $client_roles ) ) );
				?>
			</p>
		</div>
		<?php
	}
	public function render_time_slot_meta_box( \WP_Post $post ) {
		$booking_mode = get_post_meta( $post->ID, Constants::META_BOOKING_MODE, true ) ?: 'slot';
		if ( 'date_range' === $booking_mode ) {
			$start_date = get_post_meta( $post->ID, Constants::META_START_DATE, true );
			$end_date   = get_post_meta( $post->ID, Constants::META_END_DATE, true );
			?>
			<p><strong><?php esc_html_e( 'Booking Type:', 'client-sync' ); ?></strong> <?php esc_html_e( 'Multi-Day Rental', 'client-sync' ); ?></p>
			<p>
				<label><strong><?php esc_html_e( 'Check-in:', 'client-sync' ); ?></strong></label><br>
				<input type="date" name="clisyc_start_date" value="<?php echo esc_attr( $start_date ); ?>" class="widefat">
			</p>
			<p>
				<label><strong><?php esc_html_e( 'Check-out:', 'client-sync' ); ?></strong></label><br>
				<input type="date" name="clisyc_end_date" value="<?php echo esc_attr( $end_date ); ?>" class="widefat">
			</p>
			<p class="description"><?php esc_html_e( 'Note: Changing these dates manually requires ensuring the new dates are available.', 'client-sync' ); ?></p>
			<?php
		} else {
			$slot_identifier = get_post_meta( $post->ID, Constants::META_TIME_SLOT, true );
			$date_value      = '';
			$duration        = get_post_meta( $post->ID, 'clisyc_appointment_duration', true );
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading URL params to pre-fill form fields, not processing submission.
			$unslashed_get   = wp_unslash( $_GET );
			if ( 'auto-draft' === $post->post_status && isset( $unslashed_get['clisyc_slot'] ) ) {
				// Use the value from the URL if this is a new post
				$slot_identifier = sanitize_text_field( $unslashed_get['clisyc_slot'] );
				$duration        = isset( $unslashed_get['clisyc_duration'] ) ? absint( $unslashed_get['clisyc_duration'] ) : $duration;
				
				// =================== START: CRITICAL FIX ===================
				// FIX: Convert the FULL UTC datetime to local time, then extract the date.
				// This handles cases where UTC date differs from local date 
				// (e.g., 2am UTC = 7pm previous day in Pacific)
				try {
					$utc_dt     = new \DateTime( $slot_identifier, new \DateTimeZone( 'UTC' ) );
					$date_value = $utc_dt->setTimezone( wp_timezone() )->format( 'Y-m-d' );
				} catch ( \Exception $e ) {
					// Fallback: try to extract just the date if full parsing fails
					if ( preg_match( '/^(\d{4}-\d{2}-\d{2})/', $slot_identifier, $matches ) ) {
						$date_value = $matches[1];
					} else {
						$date_value = '';
					}
				}
				// =================== END: CRITICAL FIX ===================
				
			} else {
				$date_value = get_post_meta( $post->ID, Constants::META_APPOINTMENT_DATE, true );
			}
			?>
			<div id="clisyc-time-slot-selector">
				<p>
					<label for="clisyc_slot_selection_date"><strong><?php esc_html_e( 'Select Date:', 'client-sync' ); ?></strong></label><br>
					<input type="text" id="clisyc_slot_selection_date" name="clisyc_slot_selection_date" value="<?php echo esc_attr( $date_value ); ?>" style="width: 100%;" autocomplete="off">
				</p>
				<div id="clisyc-available-slots-container" style="max-height: 200px; overflow-y: auto; border: 1px solid #ddd; padding: 5px; background: #f9f9f9; margin-bottom: 10px;">
					<p><em><?php esc_html_e( 'Please select a date above to see available slots.', 'client-sync' ); ?></em></p>
				</div>
				<p>
					<strong><?php esc_html_e( 'Selected:', 'client-sync' ); ?></strong>
					<span id="clisyc-selected-slot-time"><?php esc_html_e( 'None', 'client-sync' ); ?></span>
					<span class="spinner" style="float: none; vertical-align: middle;"></span>
				</p>
				<input type="hidden" id="clisyc_selected_slot_date_hidden" name="clisyc_selected_slot_date_hidden" value="<?php echo esc_attr( $date_value ); ?>">
				<input type="hidden" id="clisyc_selected_slot_identifier_hidden" name="clisyc_selected_slot_identifier_hidden" value="<?php echo esc_attr( $slot_identifier ); ?>">
				<input type="hidden" id="clisyc_selected_slot_duration_hidden" name="clisyc_selected_slot_duration_hidden" value="<?php echo esc_attr( $duration ); ?>">
				<?php
				// Output hidden fields for dimension data (for auto-title and context saving)
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading URL params to pre-fill form fields, not processing submission.
				$unslashed_get_dims = wp_unslash( $_GET );
				if ( 'auto-draft' === $post->post_status ) {
					foreach ( $unslashed_get_dims as $key => $value ) {
						if ( strpos( $key, 'clisyc_dim_' ) === 0 ) {
							$dim_key = sanitize_key( str_replace( 'clisyc_dim_', '', $key ) );
							$sanitized_value = absint( $value );
							echo '<input type="hidden" name="clisyc_slot_dimensions[' . esc_attr( $dim_key ) . ']" value="' . esc_attr( $sanitized_value ) . '">';
						}
					}
				} else {
					// For existing appointments, persist the saved dimensions
					$saved_dimensions = get_post_meta( $post->ID, Constants::META_SLOT_DIMENSIONS, true );
					if ( is_array( $saved_dimensions ) ) {
						foreach ( $saved_dimensions as $dim_key => $dim_value ) {
							echo '<input type="hidden" name="clisyc_slot_dimensions[' . esc_attr( sanitize_key( $dim_key ) ) . ']" value="' . esc_attr( absint( $dim_value ) ) . '">';
						}
					}
				}
				?>
			</div>
			<?php
		}
	}
	public function render_service_schedule_meta_box( \WP_Post $post ) {
		$schedule_meta = get_post_meta( $post->ID, Constants::META_SCHEDULE, true );
		$schedule_data = json_decode( $schedule_meta, true );
		if ( json_last_error() !== JSON_ERROR_NONE || ! is_array( $schedule_data ) ) {
			$schedule_data = [];
		}
		if ( empty( $schedule_data ) ) {
			$schedule_data = [];
		}
		$start_time_setting = get_option( 'clisyc_standard_schedule_calendar_start_time', '09:00' );
		$end_time_setting   = get_option( 'clisyc_standard_schedule_calendar_end_time', '17:00' );
		$slot_max_time_fc   = ( '23:59' === $end_time_setting || '24:00' === $end_time_setting ) ? '24:00:00' : $end_time_setting . ':00';
		wp_localize_script(
			'admin-standard-schedule-fc',
			'csStandardScheduleData',
			[
				'post_id'         => $post->ID,
				'scheduleData'    => $schedule_data,
				'calendarOptions' => [
					'initialView'   => 'timeGridDay',
					'initialDate'   => '1970-01-05',
					'headerToolbar' => false,
					'dayHeaders'    => false,
					'allDaySlot'    => false,
					'height'        => 'auto',
					'slotMinTime'   => $start_time_setting . ':00',
					'slotMaxTime'   => $slot_max_time_fc,
				],
				'l10n'            => [
					'confirmDelete' => __( 'Are you sure you want to delete this time slot?', 'client-sync' ),
					'saving'        => __( 'Saving...', 'client-sync' ),
				],
			]
		);
		echo '<div class="clisyc-service-schedule-metabox-wrapper" data-service-id="' . esc_attr( $post->ID ) . '">';
		echo '<textarea name="_clisyc_schedule_json" id="clisyc_schedule_json_output" style="display:none;"></textarea>';
		include clisyc_PLUGIN_DIR . 'includes/admin/views/template-parts/part-schedule-editor.php';
		echo '</div>';
	}
	public function render_appointment_details_meta_box( \WP_Post $post ) {
		wp_nonce_field( 'clisyc_save_appointment_meta_nonce', 'clisyc_appointment_meta_nonce' );
		$custom_fields = get_option( 'clisyc_appointment_custom_fields', [] );
		$field_order   = get_option( 'clisyc_appointment_custom_fields_order', array_keys( $custom_fields ) );
		if ( empty( $field_order ) ) {
			echo '<p>' . esc_html__( 'No appointment custom fields defined.', 'client-sync' ) . ' <a href="' . esc_url( admin_url( 'admin.php?page=clisyc-custom-fields&cf_tab=appointments-cf' ) ) . '">' . esc_html__( 'Define them now', 'client-sync' ) . '</a>.</p>';
			return;
		}
		$prefilled_values = [];
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading URL params to pre-fill form fields, not processing submission.
		$unslashed_get    = wp_unslash( $_GET );
		if ( 'auto-draft' === $post->post_status ) {
			foreach ( $unslashed_get as $key => $value ) {
				if ( strpos( $key, 'clisyc_dim_' ) === 0 ) {
					$dim_key                            = str_replace( 'clisyc_dim_', '', $key );
					$prefilled_values[ sanitize_key( $dim_key ) ] = sanitize_text_field( $value );
				}
			}
		}
		$form_renderer = new FormRenderer();
		
		// =========================================================================
		// HIPAA COMPLIANCE: Get encryption service for decrypting sensitive fields
		// =========================================================================
		$encryption = null;
		if ( class_exists( '\DependentMedia\ClientSync\Services\Encryption_Service' ) ) {
			$encryption = Encryption_Service::get_instance();
		}
		
		echo '<table class="form-table clisyc-appointment-meta-table">';
		foreach ( $field_order as $field_key ) {
			if ( ! isset( $custom_fields[ $field_key ] ) ) {
				continue;
			}
			$field_definition = $custom_fields[ $field_key ];
			$current_value    = get_post_meta( $post->ID, $field_key, true );
			
			// =========================================================================
			// HIPAA COMPLIANCE: Decrypt encrypted field values for display
			// =========================================================================
			if ( $encryption && ! empty( $current_value ) && is_string( $current_value ) ) {
				$current_value = $encryption->maybe_decrypt( $current_value, $field_key );
			}
			
			if ( 'auto-draft' === $post->post_status && isset( $prefilled_values[ $field_key ] ) ) {
				$current_value = $prefilled_values[ $field_key ];
			}
			echo '<tr class="clisyc-meta-field-type-' . esc_attr( $field_definition['type'] ?? 'text' ) . '">';
			echo '<th scope="row"><label for="clisyc_field_' . esc_attr( $field_key ) . '">' . esc_html( $field_definition['label'] ) . '</label></th>';
			echo '<td class="clisyc-field-type-' . esc_attr( $field_definition['type'] ?? 'text' ) . '">';
			$form_renderer->render_frontend_custom_field( $field_key, $field_definition, $current_value, 'admin' );
			echo '</td>';
			echo '</tr>';
		}
		echo '</table>';
	}
	public function save_appointment_meta_data( int $post_id, \WP_Post $post ) {
		if ( ! isset( $_POST['clisyc_appointment_meta_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['clisyc_appointment_meta_nonce'] ) ), 'clisyc_save_appointment_meta_nonce' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$unslashed_post = wp_unslash( $_POST );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		if ( isset( $unslashed_post['clisyc_selected_slot_identifier_hidden'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			$utc_time_slot_str = sanitize_text_field( $unslashed_post['clisyc_selected_slot_identifier_hidden'] );
			update_post_meta( $post_id, Constants::META_TIME_SLOT, $utc_time_slot_str );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		if ( isset( $unslashed_post['clisyc_selected_slot_date_hidden'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			update_post_meta( $post_id, Constants::META_APPOINTMENT_DATE, sanitize_text_field( $unslashed_post['clisyc_selected_slot_date_hidden'] ) );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		if ( isset( $unslashed_post['clisyc_selected_slot_duration_hidden'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			update_post_meta( $post_id, 'clisyc_appointment_duration', absint( $unslashed_post['clisyc_selected_slot_duration_hidden'] ) );
		}
		// =================== Save Slot Dimensions ===================
		// Check for dimensions from hidden fields in Appointment Context metabox
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		if ( isset( $unslashed_post['clisyc_slot_dimensions'] ) && is_array( $unslashed_post['clisyc_slot_dimensions'] ) ) {
			$slot_dimensions = [];
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			foreach ( $unslashed_post['clisyc_slot_dimensions'] as $dim_key => $dim_value ) {
				$dim_key   = sanitize_key( $dim_key );
				$dim_value = absint( $dim_value );
				if ( $dim_value > 0 ) {
					$slot_dimensions[ $dim_key ] = $dim_value;
				}
			}
			
			if ( ! empty( $slot_dimensions ) ) {
				update_post_meta( $post_id, Constants::META_SLOT_DIMENSIONS, $slot_dimensions );
				
				// =================== Auto-generate Title ===================
				// Only auto-generate title if the current title is empty or is the default
				$current_title = $post->post_title;
				if ( empty( $current_title ) || $current_title === __( 'Auto Draft', 'client-sync' ) || $current_title === 'Auto Draft' ) {
					$title_parts        = [];
					$custom_types       = get_option( Constants::OPTION_CUSTOM_DIMENSION_TYPES, [] );
					$registry           = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
					$enabled_dimensions = $registry['dimensions'] ?? [];
					
					// Find the primary dimension (service) first
					$primary_slug = null;
					foreach ( $enabled_dimensions as $slug => $settings ) {
						if ( ! empty( $settings['primary'] ) ) {
							$primary_slug = $slug;
							break;
							}
						}
					
					// Build title: Primary dimension first, then others
					if ( $primary_slug && isset( $slot_dimensions[ $primary_slug ] ) ) {
						$primary_title = get_the_title( $slot_dimensions[ $primary_slug ] );
						if ( $primary_title ) {
							$title_parts[] = $primary_title;
						}
					}
					
					// Add other dimensions (practitioners, rooms, etc.)
					foreach ( $slot_dimensions as $dim_slug => $dim_post_id ) {
						if ( $dim_slug === $primary_slug ) {
							continue; // Already added
						}
						$dim_title = get_the_title( $dim_post_id );
						if ( $dim_title ) {
							$title_parts[] = $dim_title;
						}
					}
					
					// Add the date
					// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
					$appt_date = isset( $unslashed_post['clisyc_selected_slot_date_hidden'] ) 
						// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
						? sanitize_text_field( $unslashed_post['clisyc_selected_slot_date_hidden'] ) 
						: get_post_meta( $post_id, Constants::META_APPOINTMENT_DATE, true );
					
					if ( $appt_date ) {
						try {
							$date_obj      = new \DateTime( $appt_date );
							$title_parts[] = $date_obj->format( 'M j, Y' );
						} catch ( \Exception $e ) {
							$title_parts[] = $appt_date;
						}
					}
					
					// Create the title
					if ( ! empty( $title_parts ) ) {
						$new_title = implode( ' - ', $title_parts );
						
						// Update the post title (unhook to prevent infinite loop)
						remove_action( 'save_post_clisyc_appointment', [ $this, 'save_appointment_meta_data' ], 10 );
						wp_update_post(
							[
								'ID'         => $post_id,
								'post_title' => $new_title,
							]
						);
						add_action( 'save_post_clisyc_appointment', [ $this, 'save_appointment_meta_data' ], 10, 2 );
					}
				}
			}
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		if ( isset( $unslashed_post['clisyc_start_date'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			update_post_meta( $post_id, Constants::META_START_DATE, sanitize_text_field( $unslashed_post['clisyc_start_date'] ) );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		if ( isset( $unslashed_post['clisyc_end_date'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			update_post_meta( $post_id, Constants::META_END_DATE, sanitize_text_field( $unslashed_post['clisyc_end_date'] ) );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		if ( isset( $unslashed_post['clisyc_client_id'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
			$client_id = absint( $unslashed_post['clisyc_client_id'] );
			if ( $client_id > 0 && get_user_by( 'ID', $client_id ) && $post->post_author != $client_id ) {
				wp_update_post(
					[
						'ID'          => $post_id,
						'post_author' => $client_id,
					]
				);
			}
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce verified above.
		$submitted_data = $unslashed_post['clisyc_custom_field'] ?? [];
		$field_defs     = get_option( 'clisyc_appointment_custom_fields', [] );
		$field_order    = get_option( 'clisyc_appointment_custom_fields_order', array_keys( $field_defs ) );

		// =========================================================================
		// HIPAA COMPLIANCE: Get encryption service for sensitive field encryption
		// =========================================================================
		$encryption = null;
		if ( class_exists( '\DependentMedia\ClientSync\Services\Encryption_Service' ) ) {
			$encryption = Encryption_Service::get_instance();
		}

		foreach ( $field_order as $field_key ) {
			if ( ! isset( $field_defs[ $field_key ] ) ) {
				continue;
			}
			$field_definition = $field_defs[ $field_key ];
			$raw_value        = $submitted_data[ $field_key ] ?? null;
			$sanitized_value  = Sanitizer::sanitize_custom_field_value( $raw_value, $field_definition, $field_key );

			// =========================================================================
			// HIPAA COMPLIANCE: Encrypt sensitive fields if HIPAA mode is active
			// =========================================================================
			if ( $encryption ) {
				$should_encrypt = $encryption->should_encrypt_field( $field_key );
				if ( ! $should_encrypt && ! empty( $field_definition['sensitive'] ) ) {
					$should_encrypt = true;
				}
				if ( $should_encrypt && ! empty( $sanitized_value ) ) {
					$sanitized_value = $encryption->maybe_encrypt( $sanitized_value, $field_key );
				}
			}

			update_post_meta( $post_id, $field_key, $sanitized_value );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above.
		if ( isset( $_POST['_clisyc_pricing_rules'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Nonce verified above.
			$clisyc_pricing_rules = wp_unslash( $_POST['_clisyc_pricing_rules'] );
			$clisyc_sanitized_rules = [];
			if ( is_array( $clisyc_pricing_rules ) ) {
				foreach ( $clisyc_pricing_rules as $clisyc_rule ) {
					if ( empty( $clisyc_rule['type'] ) ) continue;
					$clisyc_sane_rule = [
						'type'  => sanitize_key( $clisyc_rule['type'] ),
						'mode'  => sanitize_key( $clisyc_rule['mode'] ?? 'set' ),
						'value' => sanitize_text_field( $clisyc_rule['value'] ?? '' ),
					];
					switch ( $clisyc_sane_rule['type'] ) {
						case 'seasonal':
							$clisyc_sane_rule['start'] = sanitize_text_field( $clisyc_rule['start'] ?? '' );
							$clisyc_sane_rule['end']   = sanitize_text_field( $clisyc_rule['end'] ?? '' );
							break;
						case 'dow':
							$clisyc_sane_rule['days'] = isset( $clisyc_rule['days'] ) && is_array( $clisyc_rule['days'] ) ? array_map( 'absint', $clisyc_rule['days'] ) : [];
							break;
						case 'los':
							$clisyc_sane_rule['min_days'] = absint( $clisyc_rule['min_days'] ?? 0 );
							$clisyc_sane_rule['max_days'] = absint( $clisyc_rule['max_days'] ?? 0 );
							break;
					}
					$clisyc_sanitized_rules[] = $clisyc_sane_rule;
				}
			}
			update_post_meta( $post_id, Constants::META_PRICING_RULES, $clisyc_sanitized_rules );
		}
	}
	public function register_cpt() {
		$labels = [
			'name'                  => _x( 'Appointments', 'Post type general name', 'client-sync' ),
			'singular_name'         => _x( 'Appointment', 'Post type singular name', 'client-sync' ),
			'menu_name'             => _x( 'Appointments', 'Admin Menu text', 'client-sync' ),
			'name_admin_bar'        => _x( 'Appointment', 'Add New on Toolbar', 'client-sync' ),
			'add_new'               => __( 'Add New', 'client-sync' ),
			'add_new_item'          => __( 'Add New Appointment', 'client-sync' ),
			'new_item'              => __( 'New Appointment', 'client-sync' ),
			'edit_item'             => __( 'Edit Appointment', 'client-sync' ),
			'view_item'             => __( 'View Appointment', 'client-sync' ),
			'all_items'             => __( 'All Appointments', 'client-sync' ),
			'search_items'          => __( 'Search Appointments', 'client-sync' ),
			'parent_item_colon'     => __( 'Parent Appointments:', 'client-sync' ),
			'not_found'             => __( 'No appointments found.', 'client-sync' ),
			'not_found_in_trash'    => __( 'No appointments found in Trash.', 'client-sync' ),
			'archives'              => _x( 'Appointment archives', 'The post type archive label.', 'client-sync' ),
			'insert_into_item'      => _x( 'Insert into appointment', 'Insert into post phrase.', 'client-sync' ),
			'uploaded_to_this_item' => _x( 'Uploaded to this appointment', 'Uploaded to this post phrase.', 'client-sync' ),
			'filter_items_list'     => _x( 'Filter appointments list', 'Filter posts list phrase.', 'client-sync' ),
			'items_list_navigation' => _x( 'Appointments list navigation', 'Posts list navigation phrase.', 'client-sync' ),
			'items_list'            => _x( 'Appointments list', 'Posts list phrase.', 'client-sync' ),
		];
		$args   = [
			'labels'             => $labels,
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'show_in_menu'       => false,
			'capability_type'    => 'post',
			'map_meta_cap'       => true,
			'has_archive'        => false,
			'hierarchical'       => false,
			'menu_position'      => null,
			'supports'           => [ 'title', 'editor', 'author', 'custom-fields' ],
			'menu_icon'          => 'dashicons-calendar-alt',
			'show_in_rest'       => true,
		];
		register_post_type( Constants::POST_TYPE_APPOINTMENT, $args );
	}
	public function register_custom_statuses() {
		$statuses = [
			'clisyc_pending_payment' => [
				'label'       => _x( 'Pending Payment', 'post status', 'client-sync' ),
				/* translators: %s: The number of posts with this status. */
				'label_count' => _n_noop( 'Pending Payment <span class="count">(%s)</span>', 'Pending Payment <span class="count">(%s)</span>', 'client-sync' ),
			],
			'clisyc_paid_on_day'     => [
				'label'       => _x( 'Paid (Scheduled)', 'post status', 'client-sync' ),
				/* translators: %s: The number of posts with this status. */
				'label_count' => _n_noop( 'Paid (Scheduled) <span class="count">(%s)</span>', 'Paid (Scheduled) <span class="count">(%s)</span>', 'client-sync' ),
			],
			'clisyc_failed_on_day'   => [
				'label'       => _x( 'Payment Failed (Scheduled)', 'post status', 'client-sync' ),
				/* translators: %s: The number of posts with this status. */
				'label_count' => _n_noop( 'Payment Failed (Sch) <span class="count">(%s)</span>', 'Payment Failed (Sch) <span class="count">(%s)</span>', 'client-sync' ),
			],
		];
		foreach ( $statuses as $status_key => $details ) {
			register_post_status(
				$status_key,
				[
					'label'                     => $details['label'],
					'public'                    => false,
					'exclude_from_search'       => true,
					'show_in_admin_all_list'    => true,
					'show_in_admin_status_list' => true,
					'label_count'               => $details['label_count'],
				]
			);
		}
	}
	public function add_post_status_to_display_states( array $states, \WP_Post $post ): array {
		if ( Constants::POST_TYPE_APPOINTMENT === get_post_type( $post ) ) {
			$status_obj = get_post_status_object( $post->post_status );
			if ( $status_obj && ! $status_obj->_builtin ) {
				$states[ $post->post_status ] = $status_obj->label;
			}
		}
		return $states;
	}
	public function set_default_editor_content( string $content, \WP_Post $post ): string {
		if ( Constants::POST_TYPE_APPOINTMENT === $post->post_type && empty( $content ) ) {
			return __( 'Place your private notes for the appointment here. This content is not typically shown to the client unless explicitly configured.', 'client-sync' );
		}
		return $content;
	}
	public function add_custom_columns( array $columns ): array {
		$new_columns                 = [];
		$new_columns['clisyc_appt_date'] = __( 'Appt Date', 'client-sync' );
		$new_columns['clisyc_appt_time'] = __( 'Appt Time', 'client-sync' );
		$registry        = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
		$primary_dim_slug  = null;
		if ( ! empty( $registry['dimensions'] ) ) {
			foreach ( $registry['dimensions'] as $slug => $settings ) {
				if ( ! empty( $settings['primary'] ) ) {
					$primary_dim_slug = $slug;
					break;
				}
			}
		}
		if ( $primary_dim_slug ) {
			$cpt_object               = get_post_type_object( $primary_dim_slug );
			$primary_dim_label        = $cpt_object ? $cpt_object->labels->singular_name : __( 'Primary Item', 'client-sync' );
			$new_columns[ $primary_dim_slug ] = esc_html( $primary_dim_label );
		}
		$position = array_search( 'author', array_keys( $columns ), true );
		if ( false !== $position ) {
			return array_slice( $columns, 0, $position + 1, true ) + $new_columns + array_slice( $columns, $position + 1, null, true );
		}
		return array_merge( $columns, $new_columns );
	}
	public function render_custom_column_content( string $column_name, int $post_id ) {
		if ( 'clisyc_appt_date' === $column_name || 'clisyc_appt_time' === $column_name ) {
			$booking_mode = get_post_meta( $post_id, Constants::META_BOOKING_MODE, true );
			if ( 'date_range' === $booking_mode ) {
				if ( 'clisyc_appt_date' === $column_name ) {
					$start = get_post_meta( $post_id, Constants::META_START_DATE, true );
					$end   = get_post_meta( $post_id, Constants::META_END_DATE, true );
					if ( $start && $end ) {
						echo esc_html( $start . ' to ' . $end );
					} else {
						echo '—';
					}
				} elseif ( 'clisyc_appt_time' === $column_name ) {
					esc_html_e( 'Multi-Day', 'client-sync' );
				}
				return;
			}
			$time_slot_utc_str = get_post_meta( $post_id, Constants::META_TIME_SLOT, true );
			if ( empty( $time_slot_utc_str ) ) {
				echo '—';
				return;
			}
			try {
				$datetime_utc  = new \DateTime( $time_slot_utc_str, new \DateTimeZone( 'UTC' ) );
				$datetime_site = $datetime_utc->setTimezone( wp_timezone() );
				$timestamp     = $datetime_site->getTimestamp();
				if ( 'clisyc_appt_date' === $column_name ) {
					echo esc_html( wp_date( get_option( 'date_format' ), $timestamp ) );
				} else {
					echo esc_html( wp_date( get_option( 'time_format' ), $timestamp ) );
				}
			} catch ( \Exception $e ) {
				echo '—';
			}
		} elseif ( strpos( $column_name, 'clisyc_' ) === 0 ) {
			$dimensions = get_post_meta( $post_id, Constants::META_SLOT_DIMENSIONS, true );
			if ( is_array( $dimensions ) && isset( $dimensions[ $column_name ] ) ) {
				$item_id = $dimensions[ $column_name ];
				$title   = get_the_title( $item_id );
				echo $title ? esc_html( $title ) : '—';
			} else {
				echo '—';
			}
		}
	}
	public function make_columns_sortable( array $columns ): array {
		$columns['clisyc_appt_date'] = 'clisyc_time_slot';
		$columns['clisyc_appt_time'] = 'clisyc_time_slot';
		return $columns;
	}
	public function add_admin_list_filters() {
		if ( Constants::POST_TYPE_APPOINTMENT !== ( $GLOBALS['typenow'] ?? null ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading URL filters.
		$unslashed_get = wp_unslash( $_GET );
		$start_date = isset( $unslashed_get['clisyc_filter_date_start'] ) ? sanitize_text_field( $unslashed_get['clisyc_filter_date_start'] ) : '';
		$end_date   = isset( $unslashed_get['clisyc_filter_date_end'] ) ? sanitize_text_field( $unslashed_get['clisyc_filter_date_end'] ) : '';
		echo '<input type="text" name="clisyc_filter_date_start" class="clisyc-admin-datepicker" placeholder="' . esc_attr__( 'Start Date', 'client-sync' ) . '" value="' . esc_attr( $start_date ) . '" autocomplete="off">';
		echo '<input type="text" name="clisyc_filter_date_end" class="clisyc-admin-datepicker" placeholder="' . esc_attr__( 'End Date', 'client-sync' ) . '" value="' . esc_attr( $end_date ) . '" autocomplete="off">';
	}
	public function modify_admin_list_query( \WP_Query $query ) {
		if ( ! is_admin() || ! $query->is_main_query() || 'edit.php' !== ( $GLOBALS['pagenow'] ?? null ) || Constants::POST_TYPE_APPOINTMENT !== $query->get( 'post_type' ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading URL filters.
		$unslashed_get = wp_unslash( $_GET );
		$meta_query = $query->get( 'meta_query' );
		if ( ! is_array( $meta_query ) ) {
			$meta_query = [];
		}
		if ( ! empty( $unslashed_get['clisyc_filter_date_start'] ) ) {
			$start_date_local_str = sanitize_text_field( $unslashed_get['clisyc_filter_date_start'] );
			try {
				$start_dt_utc = ( new \DateTime( $start_date_local_str . ' 00:00:00', wp_timezone() ) )->setTimezone( new \DateTimeZone( 'UTC' ) );
				$meta_query[] = [
					'key'     => 'clisyc_time_slot',
					'value'   => $start_dt_utc->format( 'Y-m-d H:i:s' ),
					'compare' => '>=',
				];
			} catch ( \Exception $e ) {
				// Do nothing
			}
		}
		if ( ! empty( $unslashed_get['clisyc_filter_date_end'] ) ) {
			$end_date_local_str = sanitize_text_field( $unslashed_get['clisyc_filter_date_end'] );
			try {
				$end_dt_utc   = ( new \DateTime( $end_date_local_str . ' 23:59:59', wp_timezone() ) )->setTimezone( new \DateTimeZone( 'UTC' ) );
				$meta_query[] = [
					'key'     => 'clisyc_time_slot',
					'value'   => $end_dt_utc->format( 'Y-m-d H:i:s' ),
					'compare' => '<=',
				];
			} catch ( \Exception $e ) {
				// Do nothing
			}
		}
		if ( count( $meta_query ) > 1 && ! isset( $meta_query['relation'] ) ) {
			$meta_query['relation'] = 'AND';
		}
		if ( ! empty( $meta_query ) ) {
			$query->set( 'meta_query', $meta_query );
		}
		$orderby             = $query->get( 'orderby' );
		$primary_service_key = get_option( 'clisyc_primary_service_dimension_key', '' );
		if ( 'clisyc_time_slot' === $orderby ) {
			$query->set( 'meta_key', 'clisyc_time_slot' );
			$query->set( 'orderby', 'meta_value' );
		} elseif ( ! empty( $primary_service_key ) && $primary_service_key === $orderby ) {
			$query->set( 'meta_key', $primary_service_key );
			$query->set( 'orderby', 'meta_value' );
		}
	}
	public function render_service_linking_meta_box( \WP_Post $post ) {
		$booking_page_id = (int) get_option( Constants::OPTION_BOOKING_PAGE_ID, 0 );
		if ( ! $booking_page_id || 'page' !== get_post_type( $booking_page_id ) ) {
			$settings_url = esc_url( admin_url( 'admin.php?page=clisyc-settings&tab=behavior' ) );
			/* translators: %s: URL to the settings page. */
			$message = sprintf( __( 'Please <a href="%s">select a Booking Page</a> in the Behavior settings to generate direct links.', 'client-sync' ), $settings_url );
			echo '<p>' . wp_kses_post( $message ) . '</p>';
			return;
		}
		$primary_dim_key = $post->post_type;
		$booking_page_url = get_permalink( $booking_page_id );
		$direct_link_url  = add_query_arg( $primary_dim_key, $post->ID, $booking_page_url );
		$color            = get_post_meta( $post->ID, Constants::META_COLOR, true );
		$html_snippet     = sprintf(
			'<a href="#" class="clisyc-service-filter-link button cs-service-filter-key-item" data-service-id="%1$s">%2$s<span class="clisyc-key-item-label">%3$s</span></a>',
			esc_attr( $post->ID ),
			$color ? '<span class="clisyc-key-color-dot" style="background-color: ' . esc_attr( $color ) . ';"></span>' : '',
			esc_html( $post->post_title )
		);
		?>
		<div class="clisyc-linking-info">
			<p class="description">
				<?php esc_html_e( 'Use these links to direct users to the booking page with this item pre-selected.', 'client-sync' ); ?>
			</p>
			<p>
				<label for="clisyc-direct-link-url"><strong><?php esc_html_e( 'Direct URL', 'client-sync' ); ?></strong></label>
				<input type="text" id="clisyc-direct-link-url" value="<?php echo esc_attr( $direct_link_url ); ?>" readonly style="width:100%; margin-top: 4px;">
			</p>
			<p>
				<label for="clisyc-html-snippet"><strong><?php esc_html_e( 'HTML Snippet for Page Builders', 'client-sync' ); ?></strong></label>
				<textarea id="clisyc-html-snippet" readonly style="width:100%; margin-top: 4px; font-family: monospace; height: 5em;"><?php echo esc_textarea( $html_snippet ); ?></textarea>
			</p>
		</div>
		<?php
	}

	/**
	 * Renders the WooCommerce Integration meta box.
	 * UPDATED: Now includes Display Price field with Sync button for ALL dimension types.
	 */
	public function render_woocommerce_meta_box( \WP_Post $post ) {
		wp_nonce_field( 'clisyc_save_wc_meta_nonce_' . $post->ID, 'clisyc_wc_meta_nonce' );
		
		$product_id    = get_post_meta( $post->ID, Constants::META_WC_PRODUCT_ID, true );
		$calc_type     = get_post_meta( $post->ID, Constants::META_ADDON_CALC_TYPE, true ) ?: 'per_night';
		$additional    = get_post_meta( $post->ID, Constants::META_ADDITIONAL_PRODUCTS, true ) ?: [];
		$display_price = get_post_meta( $post->ID, Constants::META_PRICE, true );

		// Registry check to see if this is the primary dimension
		$registry   = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
		$is_primary = ! empty( $registry['dimensions'][ $post->post_type ]['primary'] );
		?>
		<div class="clisyc-admin-instructions-metabox">
			<p><?php esc_html_e( 'Connect this item to a WooCommerce product to handle pricing and payments.', 'client-sync' ); ?></p>
		</div>
		<table class="form-table">
			<tr>
				<th scope="row"><label><?php esc_html_e( 'Linked Product', 'client-sync' ); ?></label></th>
				<td>
					<select id="clisyc_wc_product_id" name="clisyc_wc_product_id" class="wc-product-search" data-placeholder="<?php esc_attr_e( 'Search for a product…', 'client-sync' ); ?>" data-action="woocommerce_json_search_products_and_variations" data-allow_clear="true" style="width: 50%;">
						<?php if ( $product_id && ( $product = wc_get_product( $product_id ) ) ) : ?>
							<option value="<?php echo esc_attr( $product_id ); ?>" selected="selected"><?php echo wp_kses_post( $product->get_formatted_name() ); ?></option>
						<?php endif; ?>
					</select>
					
					<div id="clisyc-wc-product-actions" style="display: inline-block; vertical-align: middle; margin-left: 10px;">
						<?php if ( $product_id && ( $edit_url = get_edit_post_link( $product_id, 'raw' ) ) ) : ?>
							<a href="<?php echo esc_url( $edit_url ); ?>" class="button button-secondary">
								<?php esc_html_e( 'View / Edit Product', 'client-sync' ); ?>
								<span class="dashicons dashicons-external" style="vertical-align: text-bottom;"></span>
							</a>
						<?php else : ?>
							<button type="button" id="clisyc-create-wc-product-btn" class="button button-secondary" data-post-title="<?php echo esc_attr( $post->post_title ); ?>">
								<?php esc_html_e( 'Create & Link Product', 'client-sync' ); ?>
							</button>
						<?php endif; ?>
					</div>
				</td>
			</tr>
			<!-- CONSOLIDATED: Display Price field now appears for ALL dimensions -->
			<tr>
				<th scope="row"><label for="clisyc_price"><?php esc_html_e( 'Display Price', 'client-sync' ); ?></label></th>
				<td>
					<div style="display: flex; gap: 10px; align-items: center;">
						<input type="number" id="clisyc_price" name="clisyc_price" value="<?php echo esc_attr( $display_price ); ?>" class="small-text" placeholder="0.00" min="0" step="0.01" style="width: 100px;">
						<button type="button" id="clisyc-sync-price-btn" class="button button-secondary" <?php echo ! $product_id ? 'disabled' : ''; ?> title="<?php esc_attr_e( 'Pull price from the linked WooCommerce product', 'client-sync' ); ?>">
							<span class="dashicons dashicons-update" style="vertical-align: text-bottom; font-size: 16px; width: 16px; height: 16px;"></span>
							<?php esc_html_e( 'Sync from Product', 'client-sync' ); ?>
						</button>
					</div>
					<p class="description"><?php esc_html_e( 'This is the price shown on the calendar. Click "Sync" to pull the current price from the linked WooCommerce product.', 'client-sync' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label><?php esc_html_e( 'Calculation Method', 'client-sync' ); ?></label></th>
				<td>
					<select name="clisyc_addon_calc_type" class="widefat" style="max-width: 300px;">
						<option value="per_night" <?php selected( $calc_type, 'per_night' ); ?>><?php esc_html_e( 'Per Night / Day', 'client-sync' ); ?></option>
						<option value="per_hour" <?php selected( $calc_type, 'per_hour' ); ?>><?php esc_html_e( 'Per Hour', 'client-sync' ); ?></option>
						<option value="per_minute" <?php selected( $calc_type, 'per_minute' ); ?>><?php esc_html_e( 'Per Minute', 'client-sync' ); ?></option>
						<option value="flat" <?php selected( $calc_type, 'flat' ); ?>><?php esc_html_e( 'Flat Fee (One-time Charge)', 'client-sync' ); ?></option>
					</select>
					<!-- NEW DOCUMENTATION BLOCK -->
					<div style="margin-top: 10px; padding: 10px; background: #f0f0f1; border-left: 4px solid #2271b1; font-size: 12px; line-height: 1.4;">
						<strong><?php esc_html_e( 'Which should I choose?', 'client-sync' ); ?></strong><br>
						<ul style="margin: 5px 0 0 15px; list-style: disc;">
							<li>
								<strong><?php esc_html_e( 'Per Night / Day:', 'client-sync' ); ?></strong> 
								<?php esc_html_e( 'The WooCommerce price is multiplied by the number of nights (Date Range) or attendees (Time Slot). Use this for daily rentals or per-person classes.', 'client-sync' ); ?>
							</li>
							<li>
								<strong><?php esc_html_e( 'Flat Fee:', 'client-sync' ); ?></strong> 
								<?php esc_html_e( 'The WooCommerce price is added once, regardless of the duration or quantity. Use this for cleaning fees, insurance, or fixed-price appointments.', 'client-sync' ); ?>
							</li>
						</ul>
					</div>
				</td>
			</tr>
		</table>
		<?php if ( $is_primary ) : ?>
			<hr>
			<div style="margin-top: 20px;">
				<h4><?php esc_html_e( 'Additional Required Products (Mandatory Fees)', 'client-sync' ); ?></h4>
				<p class="description"><?php esc_html_e( 'Use this to add mandatory fees like cleaning, fuel, or insurance that will be added to the cart alongside the primary booking.', 'client-sync' ); ?></p>
				
				<div id="clisyc-additional-products-list" style="margin-top: 15px; background: #f6f7f7; padding: 15px; border: 1px solid #ddd;">
					<?php 
					if ( ! empty( $additional ) ) {
						foreach ( $additional as $index => $item ) {
							$this->render_additional_product_row( $index, $item );
						}
					} else {
						echo '<p class="clisyc-no-addons-msg">' . esc_html__( 'No mandatory fees added yet.', 'client-sync' ) . '</p>';
					}
					?>
				</div>
				
				<p><button type="button" class="button button-secondary" id="clisyc-add-required-product"><?php esc_html_e( '+ Add Required Fee', 'client-sync' ); ?></button></p>
			</div>
			<!-- Template for JS to clone (script tags are not submitted by the browser) -->
			<script type="text/html" id="clisyc-addon-row-template">
				<?php $this->render_additional_product_row( '{{index}}' ); ?>
			</script>
			<!-- FIX: Only provide data - all event handlers are in clisyc-admin-wc-product-helper.js -->
			<script>
				window.clisycAddonStartIndex = <?php echo count( $additional ); ?>;
			</script>
		<?php endif; ?>

		<!-- Sync Price Button Handler -->
		<script>
			jQuery(document).ready(function($) {
				$('#clisyc-sync-price-btn').on('click', function() {
					var $btn = $(this);
					var productId = $('#clisyc_wc_product_id').val();
					
					if (!productId) {
						alert('<?php echo esc_js( __( 'Please select a linked product first.', 'client-sync' ) ); ?>');
						return;
					}
					
					$btn.prop('disabled', true).find('.dashicons').addClass('clisyc-spin');
					
					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'clisyc_get_product_price',
							product_id: productId,
							nonce: '<?php echo esc_js( wp_create_nonce( 'clisyc_sync_price_nonce' ) ); ?>'
						},
						success: function(response) {
							if (response.success && response.data.price !== undefined) {
								$('#clisyc_price').val(response.data.price);
							} else {
								alert(response.data.message || '<?php echo esc_js( __( 'Could not retrieve product price.', 'client-sync' ) ); ?>');
							}
						},
						error: function() {
							alert('<?php echo esc_js( __( 'An error occurred while syncing the price.', 'client-sync' ) ); ?>');
						},
						complete: function() {
							$btn.prop('disabled', false).find('.dashicons').removeClass('clisyc-spin');
						}
					});
				});

				// Enable/disable sync button based on product selection
				$('#clisyc_wc_product_id').on('change', function() {
					$('#clisyc-sync-price-btn').prop('disabled', !$(this).val());
				});
			});
		</script>
		<style>
			.dashicons.clisyc-spin {
				animation: clisyc-spin 1s linear infinite;
			}
			@keyframes clisyc-spin {
				from { transform: rotate(0deg); }
				to { transform: rotate(360deg); }
			}
		</style>
		<?php
	}
	/**
	 * Renders a single row for an additional required product.
	 */
	private function render_additional_product_row( $index, $data = [] ) {
		$product_id = absint( $data['product_id'] ?? 0 );
		$calc_type  = $data['calc_type'] ?? 'flat';
		
		// Use a unique name attribute for the array structure
		$name_base = "_clisyc_additional_products[{$index}]";
		?>
		<div class="clisyc-additional-product-row" style="display: flex; gap: 10px; align-items: flex-start; margin-bottom: 10px; padding: 10px; background: #fff; border: 1px solid #ddd; border-radius: 4px;">
			<div style="flex: 1;">
				<label style="display:block; margin-bottom:4px; font-weight:600;"><?php esc_html_e( 'Product', 'client-sync' ); ?></label>
				<select name="<?php echo esc_attr( $name_base . '[product_id]' ); ?>" class="wc-product-search" data-placeholder="<?php esc_attr_e( 'Search for a product…', 'client-sync' ); ?>" data-action="woocommerce_json_search_products_and_variations" style="width: 100%;">
					<?php if ( $product_id && ( $product = wc_get_product( $product_id ) ) ) : ?>
						<option value="<?php echo esc_attr( $product_id ); ?>" selected="selected"><?php echo wp_kses_post( $product->get_formatted_name() ); ?></option>
					<?php endif; ?>
				</select>
			</div>
			<div style="width: 200px;">
				<label style="display:block; margin-bottom:4px; font-weight:600;"><?php esc_html_e( 'Calculation', 'client-sync' ); ?></label>
				<select name="<?php echo esc_attr( $name_base . '[calc_type]' ); ?>" class="widefat">
					<option value="flat" <?php selected( $calc_type, 'flat' ); ?>><?php esc_html_e( 'Flat Fee (Once)', 'client-sync' ); ?></option>
					<option value="per_night" <?php selected( $calc_type, 'per_night' ); ?>><?php esc_html_e( 'Per Night/Day', 'client-sync' ); ?></option>
				</select>
			</div>
			<div style="padding-top: 24px;">
				<button type="button" class="button clisyc-remove-product-row" style="color: #d63638; border-color: #d63638;">
					<span class="dashicons dashicons-trash" style="vertical-align: text-bottom;"></span>
				</button>
			</div>
		</div>
		<?php
	}
	public function render_employee_user_link_meta_box( \WP_Post $post ) {
		wp_nonce_field( 'clisyc_save_employee_user_link_nonce_' . $post->ID, 'clisyc_employee_user_link_nonce' );
		$linked_user_id = get_post_meta( $post->ID, Constants::META_EMPLOYEE_USER_ID, true );
		$users = get_users( [ 'role__in' => [ 'administrator', 'editor', 'author' ] ] );
		echo '<p>' . esc_html__( 'Select the WordPress user account for this employee.', 'client-sync' ) . '</p>';
		echo '<select name="_clisyc_employee_user_id" style="width: 100%;">';
		echo '<option value="">' . esc_html__( '-- Not Linked --', 'client-sync' ) . '</option>';
		foreach ( $users as $user ) {
			echo '<option value="' . esc_attr( $user->ID ) . '" ' . selected( $linked_user_id, $user->ID, false ) . '>' . esc_html( $user->display_name ) . ' (' . esc_html( $user->user_email ) . ')</option>';
		}
		echo '</select>';
		echo '<p class="description">' . esc_html__( 'The selected user will be able to connect their own Google Calendar.', 'client-sync' ) . '</p>';
	}
	public function render_google_sync_meta_box( \WP_Post $post ) {
		$employee_user_id = (int) get_post_meta( $post->ID, Constants::META_EMPLOYEE_USER_ID, true );
		if ( ! $employee_user_id ) {
			echo '<p><em>' . esc_html__( 'Link this employee to a WordPress user account to enable calendar sync.', 'client-sync' ) . '</em></p>';
			return;
		}
		if ( ! current_user_can( 'edit_user', $employee_user_id ) && get_current_user_id() !== $employee_user_id ) {
			echo '<p><em>' . esc_html__( 'Only an administrator or the linked user can manage this connection.', 'client-sync' ) . '</em></p>';
			return;
		}
		$token_data = get_user_meta( $employee_user_id, \ClientSyncPro\Services\Google_Sync_Service::TOKEN_USER_META, true );
		if ( ! empty( $token_data['access_token'] ) ) {
			echo '<p>' . sprintf( '<strong>%s</strong> %s', esc_html__( 'Status:', 'client-sync' ), '<span style="color: #4CAF50;">' . esc_html__( 'Connected', 'client-sync' ) . '</span>' ) . '</p>';
			echo '<p>' . sprintf( '<strong>%s</strong> %s', esc_html__( 'Account:', 'client-sync' ), '<code>' . esc_html( $token_data['email'] ) . '</code>' ) . '</p>';
			$disconnect_url = wp_nonce_url( admin_url( 'admin-post.php?action=clisyc_google_sync_disconnect&user_id=' . $employee_user_id ), 'google_sync_disconnect_' . $employee_user_id );
			$sync_now_url = wp_nonce_url( admin_url( 'admin-post.php?action=clisyc_google_sync_now&user_id=' . $employee_user_id ), 'google_sync_now_' . $employee_user_id );
			echo '<div style="display: flex; gap: 5px; flex-wrap: wrap;">';
			echo '<a href="' . esc_url( $sync_now_url ) . '" class="button button-secondary">' . esc_html__( 'Sync Now', 'client-sync' ) . '</a>';
			echo '<a href="' . esc_url( $disconnect_url ) . '" class="button-link is-destructive" style="line-height: 2.2;">' . esc_html__( 'Disconnect', 'client-sync' ) . '</a>';
			echo '</div>';
		} else {
			echo '<p>' . sprintf( '<strong>%s</strong> %s', esc_html__( 'Status:', 'client-sync' ), '<span style="color: #d63638;">' . esc_html__( 'Not Connected', 'client-sync' ) . '</span>' ) . '</p>';
			$connect_url = wp_nonce_url( admin_url( 'admin-post.php?action=clisyc_google_sync_redirect&user_id=' . $employee_user_id ), 'google_sync_auth_' . $employee_user_id );
			echo '<a href="' . esc_url( $connect_url ) . '" class="button button-primary">' . esc_html__( 'Connect to Google Calendar', 'client-sync' ) . '</a>';
		}
	}
	public function add_pricing_rules_meta_box() {
		add_meta_box(
			'clisyc-pricing-rules-metabox',
			__( 'Client Sync: Dynamic Pricing Rules', 'client-sync' ),
			[ $this, 'render_pricing_rules_meta_box' ],
			'product',
			'normal',
			'default'
		);
	}
	public function render_pricing_rules_meta_box( \WP_Post $post ) {
		$product = wc_get_product( $post->ID );
		if ( ! $product || ! $product->is_type( 'simple' ) || ! $product->is_virtual() ) {
			echo '<p>' . esc_html__( 'Dynamic pricing rules are only available for "Simple" and "Virtual" products used for Client Sync bookings.', 'client-sync' ) . '</p>';
			return;
		}
		// --- START: THE LINKING BRIDGE (ROBUST VERSION) ---
		// We use a direct DB query to find ANY post that claims this product ID.
		// This bypasses potential WP_Query filtering issues in the admin context.
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$linking_post_id = $wpdb->get_var( $wpdb->prepare(
			"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_clisyc_wc_product_id' AND meta_value = %d LIMIT 1",
			$post->ID
		) );
		if ( $linking_post_id ) {
			$cs_post = get_post( $linking_post_id );
			// Verify this post exists and is actually one of our enabled dimensions
			if ( $cs_post ) {
				$registry = get_option( Constants::OPTION_DIMENSION_REGISTRY, [] );
				// Check if the post type exists in our registry and is enabled
				$is_dimension = ! empty( $registry['dimensions'][ $cs_post->post_type ]['enabled'] );
				if ( $is_dimension ) {
					$cpt_obj = get_post_type_object( $cs_post->post_type );
					$label   = $cpt_obj ? $cpt_obj->labels->singular_name : __( 'Item', 'client-sync' );
					
					echo '<div style="background: #f0f6fc; border: 1px solid #d1e9ff; padding: 10px; border-radius: 4px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center;">';
					
					printf( 
						'<span>' . wp_kses( 
							/* translators: 1: Dimension Label, 2: Post Title */
							__( 'Linked to %1$s: <strong>%2$s</strong>', 'client-sync' ), 
							array( 'strong' => array() ) 
						) . '</span>',
						esc_html( $label ),
						esc_html( $cs_post->post_title )
					);
					printf(
						'<a href="%s" class="button button-secondary">%s</a>',
						esc_url( get_edit_post_link( $cs_post->ID ) ),
						/* translators: %s: The singular label of a dimension type (e.g., "Service", "Practitioner"). */
						sprintf( esc_html__( 'Edit %s', 'client-sync' ), esc_html( $label ) )
					);
					echo '</div>';
				}
			}
		}
		// --- END: THE LINKING BRIDGE ---
		wp_nonce_field( 'clisyc_save_pricing_rules_nonce_' . $post->ID, 'clisyc_pricing_rules_nonce' );
		$rules = get_post_meta( $post->ID, Constants::META_PRICING_RULES, true );
		if ( ! is_array( $rules ) ) {
			$rules = [];
		}
		?>
		<div id="clisyc-pricing-rules-container">
			<p class="description"><?php esc_html_e( 'These rules apply to Multi-Day bookings. Rules are applied in the order they appear. The base price is taken from the "Regular price" field above.', 'client-sync' ); ?></p>
			<div id="clisyc-pricing-rules-list">
				<?php foreach ( $rules as $index => $rule ) : ?>
					<?php $this->render_pricing_rule_row( $index, $rule ); ?>
				<?php endforeach; ?>
			</div>
			<button type="button" class="button" id="clisyc-add-pricing-rule"><?php esc_html_e( 'Add Rule', 'client-sync' ); ?></button>
		</div>
		<!-- Template for new rows (script tags are not submitted by the browser) -->
		<script type="text/html" id="clisyc-pricing-rule-template">
			<?php $this->render_pricing_rule_row( '{{index}}' ); ?>
		</script>
		<script>
			jQuery(document).ready(function($) {
				let ruleIndex = <?php echo count( $rules ); ?>;
				$('#clisyc-add-pricing-rule').on('click', function() {
					const template = $('#clisyc-pricing-rule-template').html().replace(/{{index}}/g, ruleIndex);
					$('#clisyc-pricing-rules-list').append(template);
					ruleIndex++;
					toggleRuleFields();
				});
				$('#clisyc-pricing-rules-list').on('click', '.clisyc-remove-rule', function() {
					$(this).closest('.clisyc-pricing-rule').remove();
				});
				const toggleRuleFields = () => {
					$('.clisyc-pricing-rule').each(function() {
						const $rule = $(this);
						const type = $rule.find('.clisyc-rule-type').val();
						$rule.find('.clisyc-rule-field').hide();
						$rule.find('.clisyc-rule-field-' + type).show();
					});
				};
				$('#clisyc-pricing-rules-list').on('change', '.clisyc-rule-type', toggleRuleFields);
				toggleRuleFields();
			});
		</script>
		<?php
	}
	private function render_pricing_rule_row( $index, $rule = null ) {
		$type      = $rule['type'] ?? 'seasonal';
		$mode      = $rule['mode'] ?? 'set';
		$value     = $rule['value'] ?? '';
		$start     = $rule['start'] ?? '';
		$end       = $rule['end'] ?? '';
		$days      = $rule['days'] ?? [];
		$min_days  = $rule['min_days'] ?? '';
		$max_days  = $rule['max_days'] ?? '';
		?>
		<div class="clisyc-pricing-rule" style="border: 1px solid #ddd; padding: 10px; margin-bottom: 10px; background: #f9f9f9;">
			<button type="button" class="button button-small clisyc-remove-rule" style="float: right;"><?php esc_html_e( 'Remove', 'client-sync' ); ?></button>
			<table style="width: 100%;">
				<tr>
					<td><strong><?php esc_html_e( 'Type', 'client-sync' ); ?></strong></td>
					<td>
						<select name="_clisyc_pricing_rules[<?php echo esc_attr( $index ); ?>][type]" class="clisyc-rule-type">
							<option value="seasonal" <?php selected( $type, 'seasonal' ); ?>><?php esc_html_e( 'Seasonal/Date Range', 'client-sync' ); ?></option>
							<option value="dow" <?php selected( $type, 'dow' ); ?>><?php esc_html_e( 'Day of Week', 'client-sync' ); ?></option>
							<option value="los" <?php selected( $type, 'los' ); ?>><?php esc_html_e( 'Length of Stay', 'client-sync' ); ?></option>
						</select>
					</td>
				</tr>
				<tr class="clisyc-rule-field clisyc-rule-field-seasonal">
					<td><strong><?php esc_html_e( 'Date Range', 'client-sync' ); ?></strong></td>
					<td>
						<input type="date" name="_clisyc_pricing_rules[<?php echo esc_attr( $index ); ?>][start]" value="<?php echo esc_attr( $start ); ?>">
						<span>to</span>
						<input type="date" name="_clisyc_pricing_rules[<?php echo esc_attr( $index ); ?>][end]" value="<?php echo esc_attr( $end ); ?>">
					</td>
				</tr>
				<tr class="clisyc-rule-field clisyc-rule-field-dow">
					<td><strong><?php esc_html_e( 'Days', 'client-sync' ); ?></strong></td>
					<td>
						<?php foreach ( [ 1 => 'Mon', 2 => 'Tue', 3 => 'Wed', 4 => 'Thu', 5 => 'Fri', 6 => 'Sat', 0 => 'Sun' ] as $day_index => $day_abbr ) : ?>
							<label><input type="checkbox" name="_clisyc_pricing_rules[<?php echo esc_attr( $index ); ?>][days][]" value="<?php echo esc_attr( $day_index ); ?>" <?php checked( in_array( (string) $day_index, $days, true ) ); ?>> <?php echo esc_html( $day_abbr ); ?></label>
						<?php endforeach; ?>
					</td>
				</tr>
				<tr class="clisyc-rule-field clisyc-rule-field-los">
					<td><strong><?php esc_html_e( 'Duration (nights)', 'client-sync' ); ?></strong></td>
					<td>
						<input type="number" min="1" placeholder="<?php esc_attr_e( 'Min', 'client-sync' ); ?>" name="_clisyc_pricing_rules[<?php echo esc_attr( $index ); ?>][min_days]" value="<?php echo esc_attr( $min_days ); ?>" style="width: 80px;">
						<span>to</span>
						<input type="number" min="1" placeholder="<?php esc_attr_e( 'Max', 'client-sync' ); ?>" name="_clisyc_pricing_rules[<?php echo esc_attr( $index ); ?>][max_days]" value="<?php echo esc_attr( $max_days ); ?>" style="width: 80px;">
					</td>
				</tr>
				 <tr>
					<td><strong><?php esc_html_e( 'Adjustment', 'client-sync' ); ?></strong></td>
					<td>
						<select name="_clisyc_pricing_rules[<?php echo esc_attr( $index ); ?>][mode]">
							<option value="set" <?php selected( $mode, 'set' ); ?>><?php esc_html_e( 'Set new daily price to ($)', 'client-sync' ); ?></option>
							<option value="add" <?php selected( $mode, 'add' ); ?>><?php esc_html_e( 'Add to daily price (+ $)', 'client-sync' ); ?></option>
							<option value="subtract" <?php selected( $mode, 'subtract' ); ?>><?php esc_html_e( 'Subtract from daily price (- $)', 'client-sync' ); ?></option>
							<option value="add_percent" <?php selected( $mode, 'add_percent' ); ?>><?php esc_html_e( 'Increase daily price by (%)', 'client-sync' ); ?></option>
							<option value="subtract_percent" <?php selected( $mode, 'subtract_percent' ); ?>><?php esc_html_e( 'Decrease price by (%)', 'client-sync' ); ?></option>
						</select>
						<input type="number" step="0.01" name="_clisyc_pricing_rules[<?php echo esc_attr( $index ); ?>][value]" value="<?php echo esc_attr( $value ); ?>" style="width: 100px;">
					</td>
				</tr>
			</table>
		</div>
		<?php
	}
	public function save_pricing_rules_meta_data( int $post_id ) {
		if ( ! isset( $_POST['clisyc_pricing_rules_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['clisyc_pricing_rules_nonce'] ), 'clisyc_save_pricing_rules_nonce_' . $post_id ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_product', $post_id ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Array keys and values are sanitized in loop below.
		$raw_rules       = isset( $_POST['_clisyc_pricing_rules'] ) && is_array( $_POST['_clisyc_pricing_rules'] ) ? wp_unslash( $_POST['_clisyc_pricing_rules'] ) : [];
		$sanitized_rules = [];
		foreach ( $raw_rules as $rule ) {
			if ( empty( $rule['type'] ) ) {
				continue;
			}
			$sane_rule = [
				'type'  => sanitize_key( $rule['type'] ),
				'mode'  => sanitize_key( $rule['mode'] ?? 'set' ),
				'value' => sanitize_text_field( $rule['value'] ?? '' ),
			];
			switch ( $sane_rule['type'] ) {
				case 'seasonal':
					$sane_rule['start'] = sanitize_text_field( $rule['start'] ?? '' );
					$sane_rule['end']   = sanitize_text_field( $rule['end'] ?? '' );
					break;
				case 'dow':
					$sane_rule['days'] = isset( $rule['days'] ) && is_array( $rule['days'] ) ? array_map( 'absint', $rule['days'] ) : [];
					break;
				case 'los':
					$sane_rule['min_days'] = absint( $rule['min_days'] ?? 0 );
					$sane_rule['max_days'] = absint( $rule['max_days'] ?? 0 );
					break;
			}
			$sanitized_rules[] = $sane_rule;
		}
		update_post_meta( $post_id, Constants::META_PRICING_RULES, $sanitized_rules );
	}
}