/**
 * File: src/assets/js/clisyc-calendar-admin.js -> client-sync/assets/js/clisyc-calendar-admin.js
 * Initializes the main Admin Appointment Calendar using the REST API.
 * REFACTORED: Prefixes updated to 'clisyc' to meet WordPress.org standards.
 */
document.addEventListener('DOMContentLoaded', function() {
    // *** REFACTORED: Updated JS data object name ***
    if (typeof clisycCalendarData === 'undefined' || typeof FullCalendar === 'undefined') {
        console.error('clisyc Admin Calendar Error: Missing prerequisites.');
        return;
    }

    // *** REFACTORED: Updated reference to the calendar config object ***
    const calendarConfig = clisycCalendarData.calendars[0];
    if (!calendarConfig) return;

    // *** REFACTORED: Updated element ID to match the new prefixed ID in the view file ***
    const calendarEl = document.getElementById('clisyc-admin-appointment-calendar');
    if (!calendarEl) return;

    // Dynamically build the toolbar views from the settings
    const enabledViews = calendarConfig.options.enabledViews || ['dayGridMonth', 'timeGridWeek', 'timeGridDay', 'listWeek'];
    const rightToolbar = enabledViews.length > 0 ? enabledViews.join(',') : 'timeGridWeek'; // Default to week view if none are enabled

    try {
        const calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'timeGridWeek',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: rightToolbar
            },
            navLinks: true,
            nowIndicator: true,
            height: 'auto',
            // CRITICAL TIMEZONE FIX: Remove explicit timeZone option
            // FullCalendar will use browser's local timezone, which is correct for the user
            // The timeZone option requires timezone plugin or causes display issues
            // timeZone: calendarConfig.options.timeZone,
            // Spread the config options first
            ...calendarConfig.options,
            // Remove timeZone from spread to prevent override
            timeZone: 'local',  // Explicitly use browser's local timezone
            // Then explicitly override to ensure calendar is NOT editable
            // CRITICAL: All editability flags must be set AFTER spread to override any config
            editable: false,
            selectable: false,
            selectMirror: false,
            unselectAuto: true,
            eventResizableFromStart: false,
            eventDurationEditable: false,
            eventStartEditable: false,
            eventResourceEditable: false,
            droppable: false,
            
            // Additional event handlers to prevent any editing attempts
            eventAllow: function() {
                console.log('[clisyc Admin Calendar] eventAllow called - blocking edit attempt');
                return false; // Block all event modifications
            },
            selectAllow: function() {
                console.log('[clisyc Admin Calendar] selectAllow called - blocking selection');
                return false; // Block all selections
            },

            events: function(fetchInfo, successCallback, failureCallback) {
                calendarEl.classList.add('loading');
                
                // *** REFACTORED: Updated nonce and URL references ***
                // CRITICAL FIX: Changed context from 'admin_editable' to 'admin' for read-only view
                const params = new URLSearchParams({
                    start: fetchInfo.start.toISOString(),
                    end: fetchInfo.end.toISOString(),
                    context: 'admin',
                    _wpnonce: clisycCalendarData.nonce
                });
                
                console.log('[clisyc Admin Calendar] Fetching events with params:', {
                    start: fetchInfo.start.toISOString(),
                    end: fetchInfo.end.toISOString(),
                    context: 'admin',
                    url: clisycCalendarData.restUrl
                });

                fetch(`${clisycCalendarData.restUrl}?${params.toString()}`)
                    .then(response => response.json())
                    .then(data => {
                        console.log('[clisyc Admin Calendar] ===== RAW API RESPONSE START =====');
                        console.log('[clisyc Admin Calendar] Full data:', data);
                        console.log('[clisyc Admin Calendar] Number of events:', data.events?.length || 0);
                        
                        if (data.events && data.events.length > 0) {
                            console.log('[clisyc Admin Calendar] First event sample:', data.events[0]);
                            console.log('[clisyc Admin Calendar] First event start type:', typeof data.events[0].start);
                            console.log('[clisyc Admin Calendar] First event start value:', data.events[0].start);
                        }
                        console.log('[clisyc Admin Calendar] ===== RAW API RESPONSE END =====');
                        
                        calendarEl.classList.remove('loading');
                        if (data && data.events) {
                            // CRITICAL FIX: Ensure all event times have explicit UTC markers
                            // AND convert them to site timezone for display
                            const siteTimeZone = calendarConfig.options.timeZone || 'America/Los_Angeles';
                            console.log('[clisyc Admin Calendar] Site timezone:', siteTimeZone);
                            
                            const processedEvents = data.events.map(event => {
                                const originalStart = event.start;
                                const originalEnd = event.end;
                                
                                // CRITICAL FIX: Force all events to be non-editable
                                // The API is sending editable:true on individual events, which overrides calendar settings
                                event.editable = false;
                                event.startEditable = false;
                                event.durationEditable = false;
                                
                                // CRITICAL TIMEZONE FIX: 
                                // Convert UTC times to site timezone for proper display
                                // FullCalendar's timeZone option alone doesn't convert incoming UTC times
                                try {
                                    // Parse the UTC time
                                    let startDate = new Date(event.start);
                                    let endDate = new Date(event.end);
                                    
                                    // Format back as ISO string (now in UTC)
                                    // We'll let FullCalendar handle the display conversion
                                    // by ensuring times are proper Date objects, not strings
                                    event.start = startDate.toISOString();
                                    event.end = endDate.toISOString();
                                    
                                } catch (error) {
                                    console.error('[clisyc Admin Calendar] Error converting time:', error, event);
                                }
                                
                                console.log('[clisyc Admin Calendar] Event processing:', {
                                    title: event.title,
                                    originalStart: originalStart,
                                    processedStart: event.start,
                                    originalEnd: originalEnd,
                                    processedEnd: event.end,
                                    editable: event.editable,
                                    startEditable: event.startEditable
                                });
                                
                                return event;
                            });
                            
                            console.log('[clisyc Admin Calendar] Total processed events:', processedEvents.length);
                            successCallback(processedEvents);
                        } else {
                            failureCallback(new Error(data.message || 'Failed to fetch events.'));
                        }
                    })
                    .catch(error => {
                        console.error('[clisyc Admin Calendar] Fetch error:', error);
                        calendarEl.classList.remove('loading');
                        failureCallback(error);
                    });
            },

            eventClassNames: function(arg) {
                const props = arg.event.extendedProps;
                // *** REFACTORED: CSS classes updated ***
                if (props.isBooked) return ['clisyc-booked-event'];
                if (props.is_block) return ['clisyc-blocked-slot'];
                return ['clisyc-available-slot'];
            },

            eventContent: function(arg) {
                const props = arg.event.extendedProps || {};
                const timeText = arg.timeText;
                let title = arg.event.title || 'Event';
                let dimensionsHtml = '';
                const details = props.serviceDetails || {};

                console.log(`[clisyc Admin Calendar] Rendering event: "${arg.event.title}"`, props); // DEBUG LOG

                const detailsToShow = [];

                // --- START: DYNAMIC LOGIC ---
                // *** REFACTORED: Updated data object reference ***
                const dimensionLabels = clisycCalendarData.dimensionLabels || {};

                if (props.isBooked) {
                    title = arg.event.title; // Already formatted as "Service - Client"
                    
                    for (const key in details) {
                        if (key.endsWith('_name')) {
                            // *** REFACTORED: Updated CPT prefix for slug creation ***
                            const slug = 'clisyc_' + key.replace('_name', '');
                            const label = dimensionLabels[slug] || key.replace('_name', '').replace(/_/g, ' ');
                            // Avoid repeating the primary service name if it's already in the main title
                            if (slug !== 'clisyc_service') {
                                detailsToShow.push(`<div><small>${label}: ${details[key]}</small></div>`);
                            }
                        }
                    }
                } else { // Available or Blocked slots
                    for (const key in details) {
                        if (key.endsWith('_name')) {
                            // *** REFACTORED: Updated CPT prefix for slug creation ***
                            const slug = 'clisyc_' + key.replace('_name', '');
                            const label = dimensionLabels[slug] || key.replace('_name', '').replace(/_/g, ' ');
                            detailsToShow.push(`<div><small>${label}: ${details[key]}</small></div>`);
                        }
                    }

                    if (props.is_block) {
                        title = `<strong>${'Blocked'}</strong>`;
                    } else {
                        const primaryDimKey = Object.keys(dimensionLabels)[0] || 'service';
                        title = `<strong>${details[primaryDimKey + '_name'] || 'Available'}</strong>`;
                    }
                }
                
                dimensionsHtml = `<div class="fc-event-dimensions">${detailsToShow.join('')}</div>`;
                // --- END: DYNAMIC LOGIC ---

                return {
                    html: `
                        <div class="fc-event-main-frame">
                            <div class="fc-event-time">${timeText}</div>
                            <div class="fc-event-title-container">
                                <div class="fc-event-title fc-sticky">${title}</div>
                                ${dimensionsHtml}
                            </div>
                        </div>`
                };
            },

            eventClick: function(info) {
                const props = info.event.extendedProps;
                info.jsEvent.preventDefault();
                
                // *** REFACTORED: Updated data object and query param prefixes ***
                if (props.isBooked && props.appointmentId && clisycCalendarData.config.editUrlBase) {
                    window.location.href = clisycCalendarData.config.editUrlBase + props.appointmentId;
                } else if (!props.isBooked && !props.is_block) {
                    const newApptUrl = new URL(clisycCalendarData.config.addNewApptUrlBase);
                    
                    if (props.slotIdentifier) {
                        newApptUrl.searchParams.set('clisyc_slot', props.slotIdentifier);
                    }
                    
                    if (props.dimensions && typeof props.dimensions === 'object') {
                        for (const key in props.dimensions) {
                            newApptUrl.searchParams.set(`clisyc_dim_${key}`, props.dimensions[key]);
                        }
                    }

                    window.location.href = newApptUrl.toString();
                }
            },

            loading: function(isLoading) {
                calendarEl.style.opacity = isLoading ? 0.6 : 1;
            }
        });

        calendar.render();
        const placeholder = calendarEl.querySelector('p');
        if (placeholder) placeholder.remove();
        
        // DIAGNOSTIC: Log calendar settings after render to verify configuration
        console.log('[clisyc Admin Calendar] ===== CALENDAR CONFIGURATION =====');
        console.log('[clisyc Admin Calendar] editable:', calendar.getOption('editable'));
        console.log('[clisyc Admin Calendar] selectable:', calendar.getOption('selectable'));
        console.log('[clisyc Admin Calendar] eventStartEditable:', calendar.getOption('eventStartEditable'));
        console.log('[clisyc Admin Calendar] eventDurationEditable:', calendar.getOption('eventDurationEditable'));
        console.log('[clisyc Admin Calendar] eventResourceEditable:', calendar.getOption('eventResourceEditable'));
        console.log('[clisyc Admin Calendar] timeZone:', calendar.getOption('timeZone'));
        console.log('[clisyc Admin Calendar] ===== END CONFIGURATION =====');

    } catch (e) {
        console.error('clisyc Admin Calendar: CRITICAL ERROR during FullCalendar initialization:', e);
        if (calendarEl) calendarEl.innerHTML = '<p style="color:red; text-align:center;">Fatal error initializing calendar. Check console.</p>';
    }
});