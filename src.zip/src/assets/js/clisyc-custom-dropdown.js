/**
 * File: src/assets/js/clisyc-custom-dropdown.js
 * A simple, reusable module for creating custom dropdowns with color dots,
 * replacing the need for the TomSelect library on the frontend.
 */
(function($) {
    'use strict';

    function CustomDropdown(selectElement, options) {
        this.$originalSelect = $(selectElement);
        this.options = options || {};
        this.onChangeCallback = this.options.onChange || function() {};
        
        this._createUI();
        this._bindEvents();

        this.$originalSelect.hide();
    }

    CustomDropdown.prototype._createUI = function() {
        this.$container = $('<div class="clisyc-custom-dropdown"></div>');
        this.$selected = $('<div class="clisyc-custom-dropdown-selected"></div>');
        this.$optionsContainer = $('<div class="clisyc-custom-dropdown-options"><ul></ul></div>');
        
        this.$container.append(this.$selected).append(this.$optionsContainer);
        this.$originalSelect.after(this.$container);

        this.populateOptions();
        this.updateSelectedDisplay();
    };

    CustomDropdown.prototype.populateOptions = function(newOptions) {
        const $ul = this.$optionsContainer.find('ul');
        $ul.empty();
        
        const optionsSource = newOptions ? newOptions : this.$originalSelect.find('option');

        optionsSource.each((index, el) => {
            const $el = $(el);
            const value = $el.val();
            const label = $el.text();
            const color = $el.data('color') || 'transparent';
            
            const colorDot = `<span class="clisyc-filter-option-color-dot" style="background-color: ${color};"></span>`;
            const $li = $(`<li data-value="${value}">${colorDot}${label}</li>`);

            if (value === "") {
                $li.addClass('clisyc-custom-dropdown-placeholder');
            }

            $ul.append($li);
        });
        this.updateSelectedDisplay();
    };

    CustomDropdown.prototype.updateSelectedDisplay = function() {
        const selectedValue = this.$originalSelect.val();
        const $selectedOption = this.$originalSelect.find('option:selected');
        const label = $selectedOption.text();
        const color = $selectedOption.data('color') || 'transparent';

        const colorDot = `<span class="clisyc-filter-option-color-dot" style="background-color: ${color};"></span>`;
        this.$selected.html(`${colorDot}${label}`);

        if (selectedValue === "") {
            this.$selected.addClass('clisyc-custom-dropdown-placeholder');
        } else {
            this.$selected.removeClass('clisyc-custom-dropdown-placeholder');
        }
    };

    CustomDropdown.prototype._bindEvents = function() {
        this.$selected.on('click', (e) => {
            e.stopPropagation();
            this.$optionsContainer.toggle();
        });

        this.$optionsContainer.on('click', 'li', (e) => {
            const value = $(e.currentTarget).data('value');
            this.setValue(value);
            this.$optionsContainer.hide();
        });

        $(document).on('click', () => {
            this.$optionsContainer.hide();
        });
    };

    CustomDropdown.prototype.setValue = function(value) {
        if (this.$originalSelect.val() !== value) {
            this.$originalSelect.val(value);
            this.updateSelectedDisplay();
            this.onChangeCallback(value);
        }
    };
    
    CustomDropdown.prototype.clear = function() {
        this.setValue("");
    };

    // Expose the constructor on the jQuery object
    $.fn.clisycCustomDropdown = function(options) {
        return this.each(function() {
            if (!$(this).data('clisycCustomDropdown')) {
                $(this).data('clisycCustomDropdown', new CustomDropdown(this, options));
            }
        });
    };

})(jQuery);