/**
 * File: src/assets/src/faceted-booking/index.js
 * Entry point for the new Faceted Search Booking Form React application.
 *
 * @package    ClientSync
 * @subpackage ClientSync/Assets/JS/FacetedBooking
 */
import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './style.css';

console.log('[CLISYC FACETED DEBUG] JS: Step 1 - index.js script has been loaded and is running.');

function initReactApp() {
    console.log('[CLISYC FACETED DEBUG] JS: Step 3 - initReactApp() is being called.');
    
    const rootEl = document.getElementById('clisyc-faceted-booking-react-root');
    
    if (rootEl) {
        console.log('[CLISYC FACETED DEBUG] JS: Step 4 (SUCCESS) - Found the root element #clisyc-faceted-booking-react-root.');
        
        if (window.clisycFacetedBookingData) {
            console.log('[CLISYC FACETED DEBUG] JS: Step 5 (SUCCESS) - Found localized data from PHP:', window.clisycFacetedBookingData);
        } else {
            console.error('[CLISYC FACETED DEBUG] JS: Step 5 (ERROR) - Localized data window.clisycFacetedBookingData is MISSING.');
        }

        const root = createRoot(rootEl);
        root.render(<App />);
        console.log('[CLISYC FACETED DEBUG] JS: Step 6 - React root.render() has been called.');
    } else {
        console.error('[CLISYC FACETED DEBUG] JS: Step 4 (FATAL) - Could not find the root element #clisyc-faceted-booking-react-root in the DOM.');
    }
}

console.log(`[CLISYC FACETED DEBUG] JS: Step 2 - Script initially ran when document.readyState was "${document.readyState}".`);

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initReactApp);
} else {
    setTimeout(initReactApp, 0);
}