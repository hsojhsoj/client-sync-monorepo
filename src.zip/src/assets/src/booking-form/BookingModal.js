/**
 * File: src/assets/src/booking-form/BookingModal.js
 * Modal component for confirming and submitting bookings.
 * 
 * UPDATED: Now supports both booking modes:
 * - 'slot' mode: Time-based bookings
 * - 'date_range' mode: Date-based bookings (rentals, accommodations)
 * 
 * FIX: Enhanced close button handler with stopPropagation to ensure reliable closing.
 * FIX: Redirect URL now includes query params required by [clisyc_booking_confirmation] shortcode.
 * 
 * FIXED (2026-01-07): Success message now shows appropriate text based on WooCommerce payment status:
 * - When payment required: "Proceeding to Checkout" / "Your slot is reserved. Complete payment to confirm."
 * - When payment NOT required: "Booking Confirmed!" / "Your appointment has been successfully booked."
 * 
 * UPDATED: Added Detailed Invoice Breakdown with inline styles.
 */
import React, { useState, useEffect, useRef } from 'react';

const BookingModal = ({ 
    isOpen, 
    onClose, 
    selectedSlot,
    selectedDateRange,
    selectedFilters,
    selectedPrimaryItem,
    formNonce,
    isGuest,
    customFieldDefinitions,
    successPageUrl,
    bookingMode = 'slot',
    currencySymbol = '$',
    basket,
    isCalculatingPrice
}) => {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [submitStatus, setSubmitStatus] = useState(null);
    const [errorMessage, setErrorMessage] = useState('');
    const [customFieldValues, setCustomFieldValues] = useState({});
    const [guestEmail, setGuestEmail] = useState('');
    const [guestName, setGuestName] = useState('');
    const modalRef = useRef(null);

    const { availabilityDimensions, filterOrder, wc_integration_enabled } = window.clisycBookingFormData || {};
    const isDateRangeMode = bookingMode === 'date_range';
    
    // Determine if payment is required (WooCommerce integration enabled)
    const paymentRequired = Boolean(wc_integration_enabled);

    // Reset state when modal opens
    useEffect(() => {
        if (isOpen) {
            setSubmitStatus(null);
            setErrorMessage('');
            setIsSubmitting(false);
            document.body.classList.add('clisyc-modal-open');
        } else {
            document.body.classList.remove('clisyc-modal-open');
        }
        return () => document.body.classList.remove('clisyc-modal-open');
    }, [isOpen]);

    // Handle escape key
    useEffect(() => {
        const handleEscape = (e) => {
            if (e.key === 'Escape' && isOpen && !isSubmitting) {
                onClose();
            }
        };
        document.addEventListener('keydown', handleEscape);
        return () => document.removeEventListener('keydown', handleEscape);
    }, [isOpen, isSubmitting, onClose]);

    // Handle click outside modal
    const handleBackdropClick = (e) => {
        if (e.target === e.currentTarget && !isSubmitting) {
            onClose();
        }
    };

    // Handle custom field changes
    const handleCustomFieldChange = (fieldKey, value) => {
        setCustomFieldValues(prev => ({ ...prev, [fieldKey]: value }));
    };

    // Format date for display
    const formatDate = (dateStr) => {
        if (!dateStr) return '';
        const date = new Date(dateStr + 'T00:00:00');
        return date.toLocaleDateString(undefined, { 
            weekday: 'long',
            month: 'long', 
            day: 'numeric',
            year: 'numeric'
        });
    };

    /**
     * Build the redirect URL with required query parameters for the confirmation shortcode.
     * 
     * @param {string|null} baseUrl - The base URL (from server response or successPageUrl prop)
     * @param {number|string} appointmentId - The appointment ID from the server response
     * @returns {string} The complete redirect URL with confirmation params
     */
    const buildRedirectUrl = (baseUrl, appointmentId) => {
        if (!baseUrl) {
            return null;
        }

        try {
            // Handle both absolute and relative URLs
            const url = new URL(baseUrl, window.location.origin);
            
            // Add the parameters required by [clisyc_booking_confirmation] shortcode
            if (appointmentId) {
                url.searchParams.set('clisyc_booking_status', 'success');
                url.searchParams.set('appt_id', appointmentId);
            }
            
            return url.toString();
        } catch (e) {
            // If URL parsing fails, fall back to simple string concatenation
            console.warn('[CLISYC] URL parsing failed, using fallback:', e);
            const separator = baseUrl.includes('?') ? '&' : '?';
            return `${baseUrl}${separator}clisyc_booking_status=success&appt_id=${appointmentId}`;
        }
    };

    // Handle form submission via AJAX
    const handleSubmit = async (e) => {
        e.preventDefault();
        
        // Validate we have required data
        if (isDateRangeMode) {
            if (!selectedDateRange || !selectedPrimaryItem) return;
        } else {
            if (!selectedSlot) return;
        }

        setIsSubmitting(true);
        setErrorMessage('');

        // Build form data
        const formData = new FormData();
        formData.append('action', 'clisyc_submit_booking');
        formData.append('clisyc_appointment_nonce', formNonce);
        formData.append('_clisyc_frontend_booking_submit', '1');
        formData.append('booking_mode', bookingMode);
        formData.append('clisyc_timestamp', Math.floor(Date.now() / 1000));

        if (isDateRangeMode) {
            // Date range booking data
            formData.append('start_date', selectedDateRange.startDate);
            formData.append('end_date', selectedDateRange.endDate);
            formData.append('nights', selectedDateRange.nights);
            
            // Add the primary dimension (the item being booked)
            const primaryDimKey = filterOrder?.[0] || 'clisyc_service';
            formData.append(primaryDimKey, selectedPrimaryItem.value);

            // Add any other selected dimensions
            Object.entries(selectedFilters).forEach(([key, value]) => {
                if (key !== primaryDimKey && value) {
                    const val = Array.isArray(value) ? value[0] : value;
                    if (val) {
                        formData.append(key, val);
                    }
                }
            });

            console.log('[CLISYC] Submitting date range booking:', {
                start_date: selectedDateRange.startDate,
                end_date: selectedDateRange.endDate,
                nights: selectedDateRange.nights,
                primary_item: selectedPrimaryItem.value
            });

        } else {
            // Time slot booking data
            formData.append('time_slot', selectedSlot.identifier);
            formData.append('time_slot_iso', selectedSlot.event.start.toISOString());
            formData.append('appointment_duration_minutes', selectedSlot.durationMinutes || 30);
            formData.append('appointment_date', selectedSlot.event.start.toISOString().split('T')[0]);

            // FIXED: Use the slot's actual dimensions, not the filter selections
            const slotDimensions = selectedSlot.event?.extendedProps?.dimensions || {};
            
            Object.entries(slotDimensions).forEach(([key, value]) => {
                if (value) {
                    formData.append(key, value);
                }
            });

            console.log('[CLISYC] Submitting slot booking:', {
                time_slot: selectedSlot.identifier,
                time_slot_iso: selectedSlot.event.start.toISOString(),
                dimensions: slotDimensions
            });
        }

        // Add guest info if not logged in
        if (isGuest) {
            formData.append('guest_email', guestEmail);
            formData.append('guest_name', guestName);
        }

        // Add custom field values
        Object.entries(customFieldValues).forEach(([key, value]) => {
            formData.append(`clisyc_custom_field[${key}]`, value);
        });

        try {
            const response = await fetch(window.clisycBookingFormData?.ajaxUrl || '/wp-admin/admin-ajax.php', {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            });

            const result = await response.json();

            if (result.success) {
                setSubmitStatus('success');
                
                setTimeout(() => {
                    // Get the appointment ID from the response
                    const appointmentId = result.data?.appointment_id;
                    
                    // Determine base redirect URL - prioritize server response, fall back to prop
                    // The server response may already have some params, but we ensure confirmation params are added
                    let redirectUrl;
                    
                    if (result.data?.redirect_url) {
                        // Server provided a redirect URL - use it as base
                        redirectUrl = buildRedirectUrl(result.data.redirect_url, appointmentId);
                    } else if (successPageUrl) {
                        // Fall back to the prop-provided success page URL
                        redirectUrl = buildRedirectUrl(successPageUrl, appointmentId);
                    }
                    
                    if (redirectUrl) {
                        window.location.href = redirectUrl;
                    } else {
                        // Last resort: reload current page
                        window.location.reload();
                    }
                }, 1500);
            } else {
                setSubmitStatus('error');
                setErrorMessage(result.data?.message || 'An error occurred. Please try again.');
                setIsSubmitting(false);
            }
        } catch (error) {
            console.error('Booking submission error:', error);
            setSubmitStatus('error');
            setErrorMessage('Network error. Please check your connection and try again.');
            setIsSubmitting(false);
        }
    };

    // Don't render if not open or no data
    if (!isOpen) return null;
    if (isDateRangeMode && (!selectedDateRange || !selectedPrimaryItem)) return null;
    if (!isDateRangeMode && !selectedSlot) return null;

    const slotDetails = selectedSlot?.event?.extendedProps?.serviceDetails || {};

    return (
        <div className="clisyc-booking-modal-overlay" onClick={handleBackdropClick}>
            <div className="clisyc-booking-modal" ref={modalRef} role="dialog" aria-modal="true">
                {/* Close button - UPDATED with explicit handler */}
                <button 
                    type="button"
                    className="clisyc-booking-modal-close"
                    onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation(); // Prevents click from reaching the backdrop
                        onClose();           // Closes the modal
                    }}
                    disabled={isSubmitting}
                    aria-label="Close modal"
                >
                    <span className="dashicons dashicons-no-alt"></span>
                </button>

                {/* Success state - different messaging based on payment requirement */}
                {submitStatus === 'success' ? (
                    <div className="clisyc-booking-modal-success">
                        <div className="clisyc-success-icon">{paymentRequired ? '🛒' : '✓'}</div>
                        <h2>{paymentRequired 
                            ? 'Proceeding to Checkout' 
                            : 'Booking Confirmed!'
                        }</h2>
                        <p>{paymentRequired 
                            ? `Your ${isDateRangeMode ? 'reservation' : 'appointment'} slot is reserved. Complete payment to confirm your booking.`
                            : `Your ${isDateRangeMode ? 'reservation' : 'appointment'} has been successfully booked.`
                        }</p>
                        <p className="clisyc-redirect-notice">
                            {paymentRequired 
                                ? 'Redirecting to checkout...' 
                                : 'Redirecting you now...'
                            }
                        </p>
                    </div>
                ) : (
                    <>
                        {/* Header */}
                        <div className="clisyc-booking-modal-header">
                            <h2 className="clisyc-booking-modal-title">
                                {isDateRangeMode ? 'Confirm Your Reservation' : 'Confirm Your Booking'}
                            </h2>
                        </div>

                        {/* Booking summary */}
                        <div className="clisyc-booking-modal-summary">
                            {isDateRangeMode ? (
                                /* Date Range Summary */
                                <div className="clisyc-date-range-summary">
                                    <div className="clisyc-summary-item-name">
                                        {selectedPrimaryItem.label}
                                    </div>
                                    <div className="clisyc-date-range-details">
                                        <div className="clisyc-date-block">
                                            <span className="clisyc-date-label">Check-in</span>
                                            <span className="clisyc-date-value">{formatDate(selectedDateRange.startDate)}</span>
                                        </div>
                                        <div className="clisyc-date-arrow">→</div>
                                        <div className="clisyc-date-block">
                                            <span className="clisyc-date-label">Check-out</span>
                                            <span className="clisyc-date-value">{formatDate(selectedDateRange.endDate)}</span>
                                        </div>
                                    </div>
                                    <div className="clisyc-stay-summary">
                                        <span className="clisyc-nights-count">
                                            {selectedDateRange.nights} night{selectedDateRange.nights !== 1 ? 's' : ''}
                                        </span>
                                    </div>
                                </div>
                            ) : (
                                /* Time Slot Summary */
                                <div className="clisyc-slot-summary">
                                    <div className="clisyc-booking-modal-datetime">
                                        <div className="clisyc-booking-modal-date-icon">
                                            <span className="dashicons dashicons-calendar-alt"></span>
                                        </div>
                                        <div className="clisyc-booking-modal-datetime-text">
                                            <div className="clisyc-booking-modal-date">
                                                {selectedSlot.event.start.toLocaleDateString([], { 
                                                    weekday: 'long',
                                                    month: 'long', 
                                                    day: 'numeric', 
                                                    year: 'numeric' 
                                                })}
                                            </div>
                                            <div className="clisyc-booking-modal-time">
                                                {selectedSlot.event.start.toLocaleTimeString([], { 
                                                    hour: 'numeric', 
                                                    minute: '2-digit', 
                                                    hour12: true 
                                                })}
                                                {selectedSlot.durationMinutes && (
                                                    <span className="clisyc-booking-modal-duration">
                                                        {' '}· {selectedSlot.durationMinutes} min
                                                    </span>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* NEW: Invoice Table / Detailed Charges */}
                            {(basket?.items?.length > 0 || isCalculatingPrice) && (
                                <div className="clisyc-invoice-container" style={{ marginTop: '1rem', borderTop: '1px solid #eee', paddingTop: '1rem' }}>
                                    <h4>Charges</h4>
                                    
                                    {isCalculatingPrice ? (
                                        <p className="clisyc-calculating"><span className="spinner is-active"></span> Updating price...</p>
                                    ) : (
                                        <table className="clisyc-invoice-table" style={{ width: '100%', borderCollapse: 'collapse' }}>
                                            <tbody>
                                                {basket.items.map((item, idx) => (
                                                    <tr key={idx} style={{ borderBottom: '1px solid #f0f0f0' }}>
                                                        <td style={{ padding: '6px 0' }}>
                                                            <strong>{item.label}</strong>
                                                            {item.type === 'fee' && <small style={{ display: 'block', color: '#666' }}>{item.meta}</small>}
                                                        </td>
                                                        <td style={{ textAlign: 'right', padding: '6px 0' }}>
                                                            {basket.currency}{parseFloat(item.price).toFixed(2)}
                                                        </td>
                                                    </tr>
                                                ))}
                                                <tr className="clisyc-invoice-total" style={{ borderTop: '2px solid #ddd', fontSize: '1.1em' }}>
                                                    <td style={{ padding: '10px 0', fontWeight: 'bold' }}>Total Due</td>
                                                    <td style={{ padding: '10px 0', fontWeight: 'bold', textAlign: 'right', color: '#16a34a' }}>
                                                        {basket.formatted}
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    )}
                                </div>
                            )}
                        </div>

                        {/* Booking details (for slot mode) */}
                        {!isDateRangeMode && (
                            <div className="clisyc-booking-modal-details">
                                {filterOrder && filterOrder.map(slug => {
                                    const dim = availabilityDimensions?.[slug];
                                    const jsKey = slug.replace('clisyc_', '');
                                    const detailName = slotDetails[`${jsKey}_name`];
                                    const detailColor = slotDetails[`${jsKey}_color`];

                                    if (!detailName || !dim) return null;

                                    return (
                                        <div key={slug} className="clisyc-booking-modal-detail-row">
                                            {detailColor && (
                                                <span 
                                                    className="clisyc-booking-modal-color-dot" 
                                                    style={{ backgroundColor: detailColor }}
                                                ></span>
                                            )}
                                            <div className="clisyc-booking-modal-detail-content">
                                                <span className="clisyc-booking-modal-detail-label">{dim.label}</span>
                                                <span className="clisyc-booking-modal-detail-value">{detailName}</span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        )}

                        {/* Error message */}
                        {submitStatus === 'error' && (
                            <div className="clisyc-booking-modal-error">
                                <span className="dashicons dashicons-warning"></span>
                                {errorMessage}
                            </div>
                        )}

                        {/* Form fields */}
                        <form onSubmit={handleSubmit} className="clisyc-booking-modal-form">
                            {/* Guest fields */}
                            {isGuest && (
                                <div className="clisyc-booking-modal-guest-fields">
                                    <div className="clisyc-booking-modal-field">
                                        <label htmlFor="guest_name">Your Name</label>
                                        <input
                                            type="text"
                                            id="guest_name"
                                            value={guestName}
                                            onChange={(e) => setGuestName(e.target.value)}
                                            required
                                            placeholder="Enter your name"
                                        />
                                    </div>
                                    <div className="clisyc-booking-modal-field">
                                        <label htmlFor="guest_email">Email Address</label>
                                        <input
                                            type="email"
                                            id="guest_email"
                                            value={guestEmail}
                                            onChange={(e) => setGuestEmail(e.target.value)}
                                            required
                                            placeholder="you@example.com"
                                        />
                                    </div>
                                </div>
                            )}

                            {/* Custom fields */}
                            {customFieldDefinitions && customFieldDefinitions.length > 0 && (
                                <div className="clisyc-booking-modal-custom-fields">
                                    {customFieldDefinitions.map(field => (
                                        <div key={field.key} className="clisyc-booking-modal-field">
                                            <label htmlFor={`custom_${field.key}`}>
                                                {field.label}
                                                {field.required && <span className="required">*</span>}
                                            </label>
                                            {field.type === 'textarea' ? (
                                                <textarea
                                                    id={`custom_${field.key}`}
                                                    value={customFieldValues[field.key] || ''}
                                                    onChange={(e) => handleCustomFieldChange(field.key, e.target.value)}
                                                    required={field.required}
                                                    placeholder={field.placeholder || ''}
                                                    rows={3}
                                                />
                                            ) : field.type === 'select' ? (
                                                <select
                                                    id={`custom_${field.key}`}
                                                    value={customFieldValues[field.key] || ''}
                                                    onChange={(e) => handleCustomFieldChange(field.key, e.target.value)}
                                                    required={field.required}
                                                >
                                                    <option value="">Select...</option>
                                                    {field.options?.map(opt => (
                                                        <option key={opt} value={opt}>{opt}</option>
                                                    ))}
                                                </select>
                                            ) : (
                                                <input
                                                    type={field.type || 'text'}
                                                    id={`custom_${field.key}`}
                                                    value={customFieldValues[field.key] || ''}
                                                    onChange={(e) => handleCustomFieldChange(field.key, e.target.value)}
                                                    required={field.required}
                                                    placeholder={field.placeholder || ''}
                                                />
                                            )}
                                        </div>
                                    ))}
                                </div>
                            )}

                            {/* Notes field */}
                            <div className="clisyc-booking-modal-field">
                                <label htmlFor="booking_notes">
                                    {isDateRangeMode ? 'Special Requests (optional)' : 'Notes (optional)'}
                                </label>
                                <textarea
                                    id="booking_notes"
                                    value={customFieldValues['notes'] || ''}
                                    onChange={(e) => handleCustomFieldChange('notes', e.target.value)}
                                    placeholder={isDateRangeMode 
                                        ? "Any special requests for your stay..." 
                                        : "Any special requests or information..."}
                                    rows={2}
                                />
                            </div>

                            {/* Action buttons */}
                            <div className="clisyc-booking-modal-actions">
                                <button
                                    type="button"
                                    className="clisyc-booking-modal-btn-cancel"
                                    onClick={onClose}
                                    disabled={isSubmitting}
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    className="clisyc-booking-modal-btn-confirm"
                                    disabled={isSubmitting || (isGuest && (!guestEmail || !guestName))}
                                >
                                    {isSubmitting ? (
                                        <>
                                            <span className="clisyc-btn-spinner"></span>
                                            {paymentRequired 
                                                ? 'Processing...' 
                                                : (isDateRangeMode ? 'Reserving...' : 'Booking...')
                                            }
                                        </>
                                    ) : (
                                        paymentRequired 
                                            ? 'Proceed to Checkout'
                                            : (isDateRangeMode ? 'Confirm Reservation' : 'Confirm Booking')
                                    )}
                                </button>
                            </div>
                        </form>
                    </>
                )}
            </div>
        </div>
    );
};

export default BookingModal;