/**
 * File: src/assets/src/booking-form/App.js
 * The main React component for the Frontend Booking Form.
 * 
 * UPDATED: 
 * - Supports both 'slot' and 'date_range' booking modes
 * - Handles preselectedServiceId for single CPT pages
 * - Auto-initializes calendar when service is pre-selected
 * - Added showBooked toggle support via shortcode attributes
 * - Added CalendarNotice for admin-only availability alerts
 * - Added CalendarLegend for better UX
 * - Added state-driven live clock responding to selected timezone
 * - Integrated TimezoneMap component for visual timezone feedback
 * - UPDATED Timezone Selection: Added offset badges, larger map, and improved layout.
 * - Added AnalogClock component with animated clock hands
 * - Added clock icon to "Current Time" label
 * - ADDED: Centralized Basket/Price Calculation Logic with API integration
 * 
 * FIXED (2026-01-01):
 * - "Heads Up" modal now shows VERIFIED first available date from API
 * - Previously used potentially stale cached date from PHP
 */
import React, { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import FilterPanel from './FilterPanel';
import CalendarView from './CalendarView';
import DateRangeCalendar from './DateRangeCalendar';
import BookingModal from './BookingModal';
import apiFetch from '@wordpress/api-fetch';

// Integrated Components
import CalendarLegend from './CalendarLegend';
import CalendarNotice from './CalendarNotice';
import TimezoneMap, { getTimezoneOffsetLabel } from './TimezoneMap';

/**
 * Helper to decode HTML entities (e.g., &#039; -> ')
 * Used for strings from wp_localize_script that may be double-encoded
 */
const decodeHTMLEntities = (text) => {
    if (!text) return text;
    const textarea = document.createElement('textarea');
    textarea.innerHTML = text;
    return textarea.value;
};

/**
 * Simple analog clock face with animated hands
 */
const AnalogClock = () => {
    const [time, setTime] = useState(new Date());
    
    useEffect(() => {
        const timer = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);
    
    const hours = time.getHours() % 12;
    const minutes = time.getMinutes();
    
    // Calculate rotation angles
    const hourDeg = (hours * 30) + (minutes * 0.5); // 30 deg per hour + adjustment for minutes
    const minuteDeg = minutes * 6; // 6 deg per minute
    
    return (
        <div className="clisyc-clock-icon-container">
            <div 
                className="clisyc-clock-hand clisyc-clock-hand-hour"
                style={{ transform: `rotate(${hourDeg}deg)` }}
            />
            <div 
                className="clisyc-clock-hand clisyc-clock-hand-minute"
                style={{ transform: `rotate(${minuteDeg}deg)` }}
            />
            <div className="clisyc-clock-center-dot" />
        </div>
    );
};

/**
 * Event Tooltip Component
 * Displays event details in a floating tooltip on hover
 */
const EventTooltip = ({ visible, x, y, content }) => {
    if (!visible || !content) return null;
    
    // Adjust Y position to not go off screen
    const adjustedY = Math.max(10, Math.min(y - 60, window.innerHeight - 180));
    
    return (
        <div 
            className="clisyc-event-tooltip"
            style={{
                left: `${x}px`,
                top: `${adjustedY}px`,
                opacity: visible ? 1 : 0,
                visibility: visible ? 'visible' : 'hidden'
            }}
        >
            <div className="clisyc-event-tooltip-arrow" />
            <div className="clisyc-event-tooltip-content">
                {/* Service/Title */}
                {content.title && (
                    <div className="clisyc-event-tooltip-title">
                        {content.service && (
                            <span 
                                className="clisyc-event-tooltip-dot"
                                style={{ backgroundColor: content.serviceColor }}
                            />
                        )}
                        {content.title}
                    </div>
                )}
                
                {/* Practitioner */}
                {content.practitioner && (
                    <div className="clisyc-event-tooltip-row">
                        <span 
                            className="clisyc-event-tooltip-dot"
                            style={{ backgroundColor: content.practitionerColor }}
                        />
                        <span className="clisyc-event-tooltip-label">{content.practitioner}</span>
                    </div>
                )}
                
                {/* Room */}
                {content.room && (
                    <div className="clisyc-event-tooltip-row">
                        <span 
                            className="clisyc-event-tooltip-dot"
                            style={{ backgroundColor: content.roomColor }}
                        />
                        <span className="clisyc-event-tooltip-label">{content.room}</span>
                    </div>
                )}
                
                {/* Time */}
                {content.time && (
                    <div className="clisyc-event-tooltip-time">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <circle cx="12" cy="12" r="10"/>
                            <polyline points="12 6 12 12 16 14"/>
                        </svg>
                        {content.time}
                    </div>
                )}
            </div>
        </div>
    );
};

/**
 * Mini Calendar Component - Google Calendar style month picker
 * Allows quick navigation to any date
 */
const MiniCalendar = ({ currentDate, onDateSelect }) => {
    const [displayMonth, setDisplayMonth] = useState(() => {
        const d = currentDate ? new Date(currentDate) : new Date();
        return new Date(d.getFullYear(), d.getMonth(), 1);
    });

    // Update display month when currentDate changes significantly
    useEffect(() => {
        if (currentDate) {
            const current = new Date(currentDate);
            const displayed = displayMonth;
            if (current.getMonth() !== displayed.getMonth() || 
                current.getFullYear() !== displayed.getFullYear()) {
                setDisplayMonth(new Date(current.getFullYear(), current.getMonth(), 1));
            }
        }
    }, [currentDate]);

    const goToPrevMonth = () => {
        setDisplayMonth(prev => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
    };

    const goToNextMonth = () => {
        setDisplayMonth(prev => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
    };

    const generateCalendarDays = () => {
        const year = displayMonth.getFullYear();
        const month = displayMonth.getMonth();
        
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const startDayOfWeek = firstDay.getDay();
        const daysInMonth = lastDay.getDate();
        
        const days = [];
        
        const prevMonthLastDay = new Date(year, month, 0).getDate();
        for (let i = startDayOfWeek - 1; i >= 0; i--) {
            days.push({
                date: new Date(year, month - 1, prevMonthLastDay - i),
                isCurrentMonth: false,
                day: prevMonthLastDay - i
            });
        }
        
        for (let day = 1; day <= daysInMonth; day++) {
            days.push({
                date: new Date(year, month, day),
                isCurrentMonth: true,
                day
            });
        }
        
        const remainingDays = 42 - days.length;
        for (let day = 1; day <= remainingDays; day++) {
            days.push({
                date: new Date(year, month + 1, day),
                isCurrentMonth: false,
                day
            });
        }
        
        return days;
    };

    const days = generateCalendarDays();
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const selectedDate = currentDate ? new Date(currentDate) : null;
    if (selectedDate) selectedDate.setHours(0, 0, 0, 0);

    const monthNames = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
    ];

    const dayNames = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

    const handleDayClick = (dayInfo) => {
        if (onDateSelect) {
            onDateSelect(dayInfo.date);
        }
        if (!dayInfo.isCurrentMonth) {
            setDisplayMonth(new Date(dayInfo.date.getFullYear(), dayInfo.date.getMonth(), 1));
        }
    };

    return (
        <div className="clisyc-mini-calendar">
            <div className="clisyc-mini-cal-header">
                <button 
                    type="button" 
                    className="clisyc-mini-cal-nav" 
                    onClick={goToPrevMonth}
                    aria-label="Previous month"
                >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <polyline points="15 18 9 12 15 6"></polyline>
                    </svg>
                </button>
                <span className="clisyc-mini-cal-title">
                    {monthNames[displayMonth.getMonth()]} {displayMonth.getFullYear()}
                </span>
                <button 
                    type="button" 
                    className="clisyc-mini-cal-nav" 
                    onClick={goToNextMonth}
                    aria-label="Next month"
                >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <polyline points="9 18 15 12 9 6"></polyline>
                    </svg>
                </button>
            </div>

            <div className="clisyc-mini-cal-weekdays">
                {dayNames.map((name, i) => (
                    <span key={i} className="clisyc-mini-cal-weekday">{name}</span>
                ))}
            </div>

            <div className="clisyc-mini-cal-grid">
                {days.map((dayInfo, index) => {
                    const dayDate = new Date(dayInfo.date);
                    dayDate.setHours(0, 0, 0, 0);
                    
                    const isToday = dayDate.getTime() === today.getTime();
                    const isSelected = selectedDate && dayDate.getTime() === selectedDate.getTime();
                    
                    return (
                        <button
                            key={index}
                            type="button"
                            className={`clisyc-mini-cal-day ${!dayInfo.isCurrentMonth ? 'clisyc-mini-cal-day--other' : ''} ${isToday ? 'clisyc-mini-cal-day--today' : ''} ${isSelected ? 'clisyc-mini-cal-day--selected' : ''}`}
                            onClick={() => handleDayClick(dayInfo)}
                        >
                            {dayInfo.day}
                        </button>
                    );
                })}
            </div>
        </div>
    );
};

const App = () => {
    // State management
    const [selectedSlot, setSelectedSlot] = useState(null);
    const [selectedDateRange, setSelectedDateRange] = useState(null);
    const [isLoadingFilters, setIsLoadingFilters] = useState(true);
    const [allFilterOptions, setAllFilterOptions] = useState({});
    const [selectedFilters, setSelectedFilters] = useState({});
    const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
    const [isSmartDateModalOpen, setIsSmartDateModalOpen] = useState(false);
    const [isNoAvailabilityModalOpen, setIsNoAvailabilityModalOpen] = useState(false);
    const [smartDateModalMessage, setSmartDateModalMessage] = useState('');
    const [timezone, setTimezone] = useState('local');
    const [currentTime, setCurrentTime] = useState('--:--:-- --');
    const [selectedPrimaryItem, setSelectedPrimaryItem] = useState(null);
    
    // Basket / Calculation State
    const [basket, setBasket] = useState({ total: 0, formatted: '', items: [] });
    const [isCalculatingPrice, setIsCalculatingPrice] = useState(false);

    // Event Tooltip State
    const [tooltip, setTooltip] = useState({
        visible: false,
        x: 0,
        y: 0,
        content: null
    });

    // Sidebar collapse state (persisted in localStorage)
    const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(() => {
        try {
            const saved = localStorage.getItem('clisyc_sidebar_collapsed');
            return saved === 'true';
        } catch {
            return false;
        }
    });

    // Header collapse state (persisted in localStorage) - collapsed by default for cleaner UI
    const [isHeaderCollapsed, setIsHeaderCollapsed] = useState(() => {
        try {
            const saved = localStorage.getItem('clisyc_header_collapsed');
            // Default to collapsed (true) if no saved preference
            return saved === null ? true : saved === 'true';
        } catch {
            return true;
        }
    });

    // Track the main calendar's current displayed date for mini calendar sync
    const [mainCalendarDate, setMainCalendarDate] = useState(new Date());

    // Ref to communicate with CalendarView for navigation
    const calendarNavigateRef = useRef(null);

    // Get config from PHP
    const { 
        restUrl, 
        restNonce, 
        filterOrder, 
        formNonce,
        isGuest,
        customFieldDefinitions,
        successPageUrl,
        bookingMode,
        dateRangeSettings,
        currencySymbol,
        availabilityDimensions,
        preselectedServiceId,  // ID passed from PHP for single CPT pages
        primaryItemName,       // Name of pre-selected item
        showBookedToggle,      // Whether to show the toggle (from shortcode)
        showBookedDefault,     // Default state of toggle (from shortcode)
        isAdmin,               // Whether current user has admin capabilities
        calendarOptions,       // Global calendar settings (min/max time, etc)
        contactPageUrl,        // URL to contact page for "no availability" fallback
        colorSettings = {},    // Color and text size settings from Appearance
        l10n = {},             // Localized strings
        smartStartDateEnabled = false  // Whether Smart Start Date feature is enabled
    } = window.clisycBookingFormData || {};

    // Get text size class for modal styling
    const textSizeClass = colorSettings?.text_size ? `clisyc-text-${colorSettings.text_size}` : 'clisyc-text-medium';

    // 1. Initialize state for showing booked slots from PHP provided defaults
    const [showBooked, setShowBooked] = useState(showBookedDefault || false);

    const isDateRangeMode = bookingMode === 'date_range';

    const primaryDimKey = useMemo(() => (
        filterOrder && filterOrder.length > 0 ? filterOrder[0] : 'clisyc_service'
    ), [filterOrder]);

    // Persist sidebar state to localStorage
    useEffect(() => {
        try {
            localStorage.setItem('clisyc_sidebar_collapsed', isSidebarCollapsed.toString());
        } catch {
            // localStorage not available
        }
    }, [isSidebarCollapsed]);

    // Persist header state to localStorage
    useEffect(() => {
        try {
            localStorage.setItem('clisyc_header_collapsed', isHeaderCollapsed.toString());
        } catch {
            // localStorage not available
        }
    }, [isHeaderCollapsed]);

    // Toggle sidebar collapsed/expanded
    const handleToggleSidebar = useCallback(() => {
        setIsSidebarCollapsed(prev => !prev);
    }, []);

    // Toggle header collapsed/expanded
    const handleToggleHeader = useCallback(() => {
        setIsHeaderCollapsed(prev => !prev);
    }, []);

    // Handle mini calendar date selection - navigate main calendar
    const handleMiniCalendarDateSelect = useCallback((date) => {
        setMainCalendarDate(date);
        // Tell CalendarView to navigate to this date
        if (calendarNavigateRef.current) {
            calendarNavigateRef.current(date);
        }
    }, []);

    // Callback for CalendarView to report its current date
    const handleMainCalendarDateChange = useCallback((date) => {
        setMainCalendarDate(date);
    }, []);

    // Clock Logic
    useEffect(() => {
        const timer = setInterval(() => {
            try {
                const now = new Date();
                const options = {
                    timeZone: timezone === 'local' ? undefined : timezone,
                    hour: '2-digit', 
                    minute: '2-digit', 
                    second: '2-digit', 
                    hour12: true
                };
                setCurrentTime(now.toLocaleTimeString('en-US', options));
            } catch (e) {
                setCurrentTime('Invalid TZ');
            }
        }, 1000);
        return () => clearInterval(timer);
    }, [timezone]);

    // Fetch filter options on mount
    const fetchAllFilterOptions = useCallback(async () => {
        setIsLoadingFilters(true);
        try {
            const response = await apiFetch({ path: `/clisyc/v1/filter-options?_wpnonce=${restNonce}` });
            setAllFilterOptions(response);
            
            const initiallySelected = {};

            // Handle pre-selection from PHP (single CPT page)
            if (preselectedServiceId) {
                // Pre-select the specific item
                initiallySelected[primaryDimKey] = [preselectedServiceId.toString()];
                
                // For date_range mode, also set the selectedPrimaryItem state
                if (isDateRangeMode && response[primaryDimKey]) {
                    const item = response[primaryDimKey].find(
                        opt => opt.value.toString() === preselectedServiceId.toString()
                    );
                    if (item) {
                        setSelectedPrimaryItem(item);
                    } else {
                        // Item not in filter options - create a minimal object
                        setSelectedPrimaryItem({
                            value: preselectedServiceId,
                            label: primaryItemName || 'Selected Item',
                            price: dateRangeSettings?.pricePerNight || 0
                        });
                    }
                }
            } else if (!isDateRangeMode) {
                // Default slot mode behavior: select all options
                filterOrder.forEach(key => {
                    if (response[key] && Array.isArray(response[key])) {
                        initiallySelected[key] = response[key].map(opt => opt.value.toString());
                    }
                });
            }
            
            setSelectedFilters(initiallySelected);
        } catch (error) {
            console.error("Failed to fetch filter options:", error);
        } finally {
            setIsLoadingFilters(false);
        }
    }, [restNonce, filterOrder, isDateRangeMode, preselectedServiceId, primaryDimKey, primaryItemName, dateRangeSettings]);

    useEffect(() => {
        fetchAllFilterOptions();
    }, [fetchAllFilterOptions]);

    // Price Calculation Effect
    useEffect(() => {
        // Only calculate if we have a primary item selected
        const primaryId = selectedPrimaryItem?.value || (isDateRangeMode && selectedFilters[primaryDimKey]?.[0]) || preselectedServiceId;
        
        // If in slot mode and no slot selected, we can't calc duration accurately yet, 
        // but we can estimate base price if primary is selected.
        if (!primaryId) {
            setBasket({ total: 0, formatted: '', items: [] });
            return;
        }
        
        // Don't calculate if just browsing slots (optimization), 
        // wait for slot select OR date range select
        if (!isDateRangeMode && !selectedSlot) return; 

        const calculateTotal = async () => {
            setIsCalculatingPrice(true);
            
            // Gather all other selected IDs (exclude primary)
            const dimIds = [];
            Object.entries(selectedFilters).forEach(([key, val]) => {
                if (key !== primaryDimKey && val) {
                    const id = Array.isArray(val) ? val[0] : val;
                    if(id) dimIds.push(id);
                }
            });
            
            // Collect dimensions from selected slot if available (overrides filters)
            if (selectedSlot?.dimensions) {
                Object.entries(selectedSlot.dimensions).forEach(([key, val]) => {
                     if (key !== primaryDimKey && val) dimIds.push(val);
                });
            }

            const params = new URLSearchParams({
                primary_id: primaryId,
                dimension_ids: dimIds.join(','),
                _wpnonce: restNonce
            });

            if (isDateRangeMode && selectedDateRange) {
                params.append('start_date', selectedDateRange.startDate);
                params.append('end_date', selectedDateRange.endDate);
            } else if (selectedSlot) {
                params.append('duration', selectedSlot.durationMinutes || 60);
                params.append('start_date', selectedSlot.event.start.toISOString()); // For seasonal check
            }

            // Attendees handling if applicable
            const attendeesInput = document.getElementById('clisyc_attendees');
            if (attendeesInput) {
                params.append('attendees', attendeesInput.value);
            }

            try {
                const response = await apiFetch({ 
                    path: `/clisyc/v1/price/calculate-basket?${params.toString()}` 
                });
                
                if (response.success) {
                    setBasket({
                        total: response.total,
                        formatted: response.formatted_total,
                        items: response.line_items,
                        currency: response.currency
                    });
                }
            } catch (e) {
                console.error('Price calculation failed', e);
            } finally {
                setIsCalculatingPrice(false);
            }
        };

        // Debounce calculation
        const timer = setTimeout(calculateTotal, 250);
        return () => clearTimeout(timer);

    }, [
        selectedFilters, 
        selectedDateRange, 
        selectedSlot, 
        selectedPrimaryItem, 
        preselectedServiceId, 
        isDateRangeMode, 
        primaryDimKey, 
        restNonce
    ]);

    // Handle filter changes
    const handleFilterSelection = useCallback((key, value) => {
        setSelectedFilters(prev => ({ ...prev, [key]: value }));
        
        // Clear selections when filters change
        setSelectedSlot(null);
        setSelectedDateRange(null);
        
        // For date_range mode, track the selected primary item
        if (isDateRangeMode && key === primaryDimKey && value) {
            const selectedValue = Array.isArray(value) ? value[0] : value;
            const options = allFilterOptions[primaryDimKey] || [];
            const item = options.find(opt => opt.value.toString() === selectedValue.toString());
            setSelectedPrimaryItem(item || null);
        }
    }, [isDateRangeMode, primaryDimKey, allFilterOptions]);

    const handleResetFilters = useCallback(() => {
        // If pre-selected, don't fully reset - keep the pre-selection
        if (preselectedServiceId) {
            setSelectedDateRange(null);
            setSelectedSlot(null);
            return;
        }
        
        fetchAllFilterOptions();
        setSelectedSlot(null);
        setSelectedDateRange(null);
        setSelectedPrimaryItem(null);
        // Reset basket
        setBasket({ total: 0, formatted: '', items: [] });
    }, [fetchAllFilterOptions, preselectedServiceId]);

    // Handle slot selection (time-based bookings)
    const handleSlotSelect = useCallback((event) => {
        const props = event.extendedProps;
        
        if (!props.isBookable) {
            return;
        }

        const startTimeLocal = event.start.toLocaleTimeString([], { 
            hour: 'numeric', 
            minute: '2-digit', 
            hour12: true 
        });
        const dateLocal = event.start.toLocaleDateString([], { 
            month: 'long', 
            day: 'numeric', 
            year: 'numeric' 
        });
        
        setSelectedSlot({
            event,
            identifier: props.slotIdentifier,
            durationMinutes: props.durationMinutes,
            displayTime: `${dateLocal} at ${startTimeLocal}`,
            dimensions: props.dimensions // Included to support advanced pricing logic
        });
        
        setIsBookingModalOpen(true);
    }, []);

    // Handle date range selection (date-based bookings)
    const handleDateRangeSelect = useCallback((rangeData) => {
        if (!rangeData) {
            setSelectedDateRange(null);
            return;
        }

        setSelectedDateRange({
            startDate: rangeData.start,
            endDate: rangeData.end,
            nights: rangeData.nights,
            total: rangeData.total,
            displayText: `${rangeData.nights} night${rangeData.nights !== 1 ? 's' : ''}`
        });
    }, []);

    // Handle slot/date deselection
    const handleDeselect = useCallback(() => {
        setSelectedSlot(null);
        setSelectedDateRange(null);
        setIsBookingModalOpen(false);
    }, []);

    // Close booking modal
    const handleCloseBookingModal = useCallback(() => {
        setIsBookingModalOpen(false);
    }, []);

    // Open booking modal for date range
    const handleOpenDateRangeBooking = useCallback(() => {
        if (selectedDateRange && selectedPrimaryItem) {
            setIsBookingModalOpen(true);
        }
    }, [selectedDateRange, selectedPrimaryItem]);

    // =========================================================================
    // FIXED: Smart Start Date Modal - Now uses VERIFIED date from CalendarView
    // =========================================================================
    // Instead of showing the modal based on potentially stale PHP cached data,
    // we now wait for CalendarView to report the actual first available date
    // after it fetches slots from the API.
    //
    // This callback is passed to CalendarView and called once after initial load.
    // It receives:
    // - A Date object if slots are available (may trigger "jumped ahead" modal)
    // - null if NO slots are available (triggers "no availability" modal)
    // =========================================================================
    const handleFirstAvailableDate = useCallback((verifiedDate) => {
        // Only applies to slot mode (not date_range mode)
        if (isDateRangeMode) return;
        
        // Handle "no availability" case (always show this regardless of Smart Start Date setting)
        if (verifiedDate === null) {
            setIsNoAvailabilityModalOpen(true);
            return;
        }
        
        // CRITICAL: Only show "Heads Up" modal if Smart Start Date feature is ENABLED
        // If the setting is off in WP Admin > ClientSync > Behavior, skip the modal
        if (!smartStartDateEnabled) return;
        
        // Validate we received a valid date
        if (!verifiedDate || !(verifiedDate instanceof Date)) return;
        
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        // Only show modal if first available date is in the future
        const verifiedDateOnly = new Date(verifiedDate);
        verifiedDateOnly.setHours(0, 0, 0, 0);
        
        if (verifiedDateOnly.getTime() > today.getTime()) {
            const formattedDate = verifiedDate.toLocaleDateString(undefined, {
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric'
            });
            
            // Store just the formatted date for the modal date box
            setSmartDateModalMessage(formattedDate);
            setIsSmartDateModalOpen(true);
        }
    }, [isDateRangeMode, smartStartDateEnabled]);

    // =========================================================================
    // EVENT TOOLTIP HANDLERS
    // These are passed to CalendarView and triggered on event mouse enter/leave
    // =========================================================================
    const handleEventMouseEnter = useCallback((info) => {
        const { event, el } = info;
        
        // Get event data
        const extendedProps = event.extendedProps || {};
        const startTime = event.start ? event.start.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
        const endTime = event.end ? event.end.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
        
        // Build tooltip content
        const content = {
            title: event.title || extendedProps.serviceName || 'Available',
            time: startTime && endTime ? `${startTime} - ${endTime}` : '',
            practitioner: extendedProps.practitionerName || extendedProps.practitioner || '',
            practitionerColor: extendedProps.practitionerColor || '#4285f4',
            room: extendedProps.roomName || extendedProps.room || '',
            roomColor: extendedProps.roomColor || '#34a853',
            service: extendedProps.serviceName || '',
            serviceColor: extendedProps.serviceColor || '#1a73e8'
        };
        
        // Calculate position - to the right of the event, or left if near edge
        const rect = el.getBoundingClientRect();
        const viewportWidth = window.innerWidth;
        const tooltipWidth = 220; // Approximate tooltip width
        
        let x, y;
        
        // Position to the right by default, left if not enough space
        if (rect.right + tooltipWidth + 20 < viewportWidth) {
            x = rect.right + 8;
        } else {
            x = rect.left - tooltipWidth - 8;
        }
        
        // Vertically center on the event
        y = rect.top + (rect.height / 2);
        
        setTooltip({
            visible: true,
            x,
            y,
            content
        });
    }, []);
    
    const handleEventMouseLeave = useCallback(() => {
        setTooltip(prev => ({ ...prev, visible: false }));
    }, []);

    // Body scroll lock for modals
    useEffect(() => {
        if (isSmartDateModalOpen || isNoAvailabilityModalOpen) {
            document.body.classList.add('clisyc-modal-open');
        } else {
            document.body.classList.remove('clisyc-modal-open');
        }
        return () => document.body.classList.remove('clisyc-modal-open');
    }, [isSmartDateModalOpen, isNoAvailabilityModalOpen]);

    const isReady = !isLoadingFilters;
    
    // Determine if we should show the filter panel
    const showFilters = filterOrder && filterOrder.length > 0 && !(isDateRangeMode && preselectedServiceId);
    
    const hasValidDateRangeSelection = isDateRangeMode && selectedDateRange && selectedPrimaryItem;
    const primaryDimValue = selectedFilters[primaryDimKey]?.[0] || selectedFilters[primaryDimKey];

    return (
        <div className={`clisyc-booking-form-app ${isDateRangeMode ? 'clisyc-date-range-mode' : 'clisyc-slot-mode'} ${preselectedServiceId ? 'clisyc-preselected' : ''}`}>
            {/* Smart Date Modal (slot mode only) */}
            {isSmartDateModalOpen && !isDateRangeMode && (
                <div className={`clisyc-modal-overlay ${textSizeClass}`} onClick={() => setIsSmartDateModalOpen(false)}>
                    <div className="clisyc-modal-content" onClick={e => e.stopPropagation()}>
                        <div className="clisyc-modal-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                <line x1="16" y1="2" x2="16" y2="6"></line>
                                <line x1="8" y1="2" x2="8" y2="6"></line>
                                <line x1="3" y1="10" x2="21" y2="10"></line>
                                <path d="M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01M16 18h.01"></path>
                            </svg>
                        </div>
                        <h2>{decodeHTMLEntities(l10n?.headsUp) || 'Heads Up!'}</h2>
                        <p>{decodeHTMLEntities(l10n?.jumpedAheadMessage) || "We've jumped ahead to the first available date for you."}</p>
                        {smartDateModalMessage && (
                            <span className="clisyc-modal-date">
                                {smartDateModalMessage}
                            </span>
                        )}
                        <button 
                            type="button" 
                            className="clisyc-modal-ok-button" 
                            onClick={() => setIsSmartDateModalOpen(false)}
                        >
                            {decodeHTMLEntities(l10n?.gotIt) || 'Got it'}
                        </button>
                    </div>
                </div>
            )}

            {/* No Availability Modal (slot mode only) */}
            {isNoAvailabilityModalOpen && !isDateRangeMode && (
                <div className={`clisyc-modal-overlay ${textSizeClass}`} onClick={() => setIsNoAvailabilityModalOpen(false)}>
                    <div className="clisyc-modal-content" onClick={e => e.stopPropagation()}>
                        <div className="clisyc-modal-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                <line x1="16" y1="2" x2="16" y2="6"></line>
                                <line x1="8" y1="2" x2="8" y2="6"></line>
                                <line x1="3" y1="10" x2="21" y2="10"></line>
                                <path d="M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01M16 18h.01"></path>
                            </svg>
                        </div>
                        <h2>{decodeHTMLEntities(l10n?.noAvailabilityTitle) || 'No Availability'}</h2>
                        <p>
                            {decodeHTMLEntities(l10n?.noAvailabilityMessage) || 'There are currently no available appointment times. Please check back later or contact us for assistance.'}
                        </p>
                        <div className="clisyc-modal-buttons">
                            {contactPageUrl && (
                                <a 
                                    href={contactPageUrl} 
                                    className="clisyc-modal-ok-button"
                                >
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ width: '18px', height: '18px' }}>
                                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                                        <polyline points="22,6 12,13 2,6"></polyline>
                                    </svg>
                                    {decodeHTMLEntities(l10n?.contactUs) || 'Contact Us'}
                                </a>
                            )}
                            <button 
                                type="button" 
                                className={contactPageUrl ? 'clisyc-modal-button--secondary' : 'clisyc-modal-ok-button'}
                                onClick={() => setIsNoAvailabilityModalOpen(false)}
                            >
                                {decodeHTMLEntities(l10n?.close) || 'Close'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Booking Confirmation Modal */}
            <BookingModal
                isOpen={isBookingModalOpen}
                onClose={handleCloseBookingModal}
                selectedSlot={selectedSlot}
                selectedDateRange={selectedDateRange}
                selectedFilters={selectedFilters}
                selectedPrimaryItem={selectedPrimaryItem}
                formNonce={formNonce}
                isGuest={isGuest}
                customFieldDefinitions={customFieldDefinitions}
                successPageUrl={successPageUrl}
                bookingMode={bookingMode}
                currencySymbol={currencySymbol}
                basket={basket}
                isCalculatingPrice={isCalculatingPrice}
            />

            {/* Main Layout */}
            <div className={`clisyc-faceted-search-layout ${!showFilters ? 'clisyc-no-sidebar' : ''} ${isSidebarCollapsed ? 'clisyc-sidebar-collapsed' : ''}`}>
                {/* Filter Panel */}
                {showFilters && (
                    <FilterPanel
                        isLoading={isLoadingFilters}
                        options={allFilterOptions}
                        selections={selectedFilters}
                        onSelect={handleFilterSelection}
                        onReset={handleResetFilters}
                        bookingMode={bookingMode}
                        showBooked={showBooked}
                        onToggleShowBooked={showBookedToggle ? setShowBooked : null}
                        isSidebarCollapsed={isSidebarCollapsed}
                        onToggleSidebar={handleToggleSidebar}
                        miniCalendar={!isDateRangeMode ? (
                            <MiniCalendar 
                                currentDate={mainCalendarDate}
                                onDateSelect={handleMiniCalendarDateSelect}
                            />
                        ) : null}
                    />
                )}

                {/* Main Content Area */}
                <div className="clisyc-main-content-area">
                    {/* Timezone, Map, and Clock Section (slot mode only) */}
                    {!isDateRangeMode && (
                        <div className={`clisyc-time-selection-wrapper ${isHeaderCollapsed ? 'clisyc-header-collapsed' : 'clisyc-header-expanded'}`}>
                            {/* Collapsed Header - Compact Bar */}
                            {isHeaderCollapsed && (
                                <div className="clisyc-header-compact">
                                    <div className="clisyc-header-compact-info">
                                        <span className="dashicons dashicons-admin-site" aria-hidden="true"></span>
                                        <span className="clisyc-header-compact-timezone">
                                            {timezone === 'local' ? 'Local Time' : timezone.split('/').pop().replace('_', ' ')}
                                        </span>
                                        <span className="clisyc-timezone-offset-badge">
                                            {getTimezoneOffsetLabel(timezone)}
                                        </span>
                                        <span className="clisyc-header-compact-divider">|</span>
                                        <span className="clisyc-header-compact-time">
                                            {currentTime}
                                        </span>
                                    </div>
                                    <button 
                                        type="button"
                                        className="clisyc-header-toggle-btn"
                                        onClick={handleToggleHeader}
                                        aria-label="Expand timezone settings"
                                        title="Click to change timezone"
                                    >
                                        <span className="dashicons dashicons-arrow-down-alt2"></span>
                                        <span className="clisyc-header-toggle-text">Change Timezone</span>
                                    </button>
                                </div>
                            )}
                            
                            {/* Expanded Header - Full Controls */}
                            {!isHeaderCollapsed && (
                                <div className="clisyc-header-expanded-content">
                                    {/* Top Row: Timezone Selector + Clock + Collapse Button */}
                                    <div className="clisyc-header-top-row">
                                        {/* Timezone Selector - Left */}
                                        <div className="clisyc-timezone-filter-wrapper">
                                            <label className="clisyc-timezone-label" htmlFor="clisyc-timezone-select">
                                                <span className="dashicons dashicons-admin-site" aria-hidden="true"></span>
                                                <span>Timezone Selection</span>
                                                <span className="clisyc-timezone-offset-badge">
                                                    {getTimezoneOffsetLabel(timezone)}
                                                </span>
                                            </label>
                                            <div className="clisyc-timezone-selector">
                                                <select 
                                                    id="clisyc-timezone-select"
                                                    value={timezone} 
                                                    onChange={(e) => setTimezone(e.target.value)}
                                                    aria-label="Select timezone"
                                                >
                                                    <option value="local">My Local Time</option>
                                                    <option value="UTC">UTC</option>
                                                    <option value="America/New_York">New York (ET)</option>
                                                    <option value="America/Chicago">Chicago (CT)</option>
                                                    <option value="America/Denver">Denver (MT)</option>
                                                    <option value="America/Los_Angeles">Los Angeles (PT)</option>
                                                    <option value="Europe/London">London (GMT/BST)</option>
                                                    <option value="Europe/Paris">Paris (CET)</option>
                                                    <option value="Asia/Tokyo">Tokyo (JST)</option>
                                                    <option value="Australia/Sydney">Sydney (AEST)</option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        {/* Live Clock - Center/Right */}
                                        <div className="clisyc-live-clock-wrapper">
                                            <label className="clisyc-clock-label">
                                                <span>Current Time</span>
                                            </label>
                                            <div className="clisyc-clock-display">
                                                <AnalogClock />
                                                <div className="clisyc-live-clock">
                                                    {currentTime}
                                                </div>
                                            </div>
                                        </div>
                                        
                                        {/* Collapse Button - Right */}
                                        <button 
                                            type="button"
                                            className="clisyc-header-collapse-btn"
                                            onClick={handleToggleHeader}
                                            aria-label="Collapse timezone settings"
                                            title="Collapse"
                                        >
                                            <span className="dashicons dashicons-arrow-up-alt2"></span>
                                        </button>
                                    </div>
                                    
                                    {/* Bottom Row: Full-Width Map */}
                                    <div className="clisyc-header-map-row">
                                        <TimezoneMap 
                                            selectedTimezone={timezone}
                                            size="large"
                                            showLabel={false}
                                        />
                                    </div>
                                </div>
                            )}
                        </div>
                    )}

                    {/* Selected slot indicator (slot mode) */}
                    {!isDateRangeMode && selectedSlot && (
                        <div className="clisyc-selected-slot-banner">
                            <div className="clisyc-selected-slot-info">
                                <span className="clisyc-selected-slot-icon">✓</span>
                                <span className="clisyc-selected-slot-text">
                                    Selected: <strong>{selectedSlot.displayTime}</strong>
                                </span>
                            </div>
                            <button 
                                type="button"
                                className="clisyc-selected-slot-book-btn"
                                onClick={() => setIsBookingModalOpen(true)}
                            >
                                Complete Booking
                            </button>
                        </div>
                    )}

                    {/* Date Range Mode Content */}
                    {isDateRangeMode && isReady && (
                        <>
                            {!primaryDimValue && !preselectedServiceId && (
                                <div className="clisyc-empty-state">
                                    <div className="clisyc-empty-state-icon">📅</div>
                                    <div className="clisyc-empty-state-message">
                                        Select a {availabilityDimensions?.[primaryDimKey]?.label || 'service'}
                                    </div>
                                    <div className="clisyc-empty-state-description">
                                        Choose from the options on the left to see availability.
                                    </div>
                                </div>
                            )}

                            {(primaryDimValue || preselectedServiceId) && (
                                <DateRangeCalendar
                                    dimensionId={primaryDimValue || preselectedServiceId}
                                    dimensionName={selectedPrimaryItem?.label || primaryItemName}
                                    restNonce={restNonce}
                                    onDateRangeSelect={handleDateRangeSelect}
                                    minStay={dateRangeSettings?.minStay || 1}
                                    maxStay={dateRangeSettings?.maxStay || 365}
                                    bufferDays={dateRangeSettings?.bufferDays || 0}
                                    pricePerNight={selectedPrimaryItem?.price || dateRangeSettings?.pricePerNight || 0}
                                    currencySymbol={currencySymbol || '$'}
                                />
                            )}

                            {hasValidDateRangeSelection && (
                                <div className="clisyc-date-range-booking-cta">
                                    <button 
                                        type="button"
                                        className="clisyc-date-range-book-btn"
                                        onClick={handleOpenDateRangeBooking}
                                    >
                                        Book Now - {selectedDateRange.nights} Night{selectedDateRange.nights !== 1 ? 's' : ''}
                                        {selectedDateRange.total && (
                                            <span className="clisyc-btn-price">
                                                {currencySymbol}{selectedDateRange.total}
                                            </span>
                                        )}
                                    </button>
                                </div>
                            )}
                        </>
                    )}

                    {/* Slot Mode Calendar */}
                    {!isDateRangeMode && isReady && (
                        <>
                            {/* Admin Notice for slots outside visible range */}
                            <CalendarNotice 
                                selectedFilters={selectedFilters}
                                restNonce={restNonce}
                                calendarStartTime={calendarOptions?.slotMinTime || '08:00'}
                                calendarEndTime={calendarOptions?.slotMaxTime || '18:00'}
                            />
                            
                            <CalendarView 
                                selectedFilters={selectedFilters}
                                restUrl={restUrl}
                                restNonce={restNonce}
                                onSlotSelect={handleSlotSelect}
                                onSlotDeselect={handleDeselect}
                                primaryDimKey={primaryDimKey}
                                timezone={timezone}
                                selectedSlotId={selectedSlot?.identifier}
                                showBooked={showBooked}
                                onFirstAvailableDate={handleFirstAvailableDate}
                                onEventMouseEnter={handleEventMouseEnter}
                                onEventMouseLeave={handleEventMouseLeave}
                                onDateChange={handleMainCalendarDateChange}
                                setNavigateCallback={(fn) => { calendarNavigateRef.current = fn; }}
                            />
                            
                            {/* Calendar Legend */}
                            <CalendarLegend showBooked={showBooked} />
                        </>
                    )}

                    {/* Loading state */}
                    {!isReady && (
                        <div className="clisyc-empty-state">
                            <div className="clisyc-empty-state-icon">⚙️</div>
                            <div className="clisyc-empty-state-message">Loading...</div>
                            <div className="clisyc-empty-state-description">
                                Please wait while we load available times.
                            </div>
                        </div>
                    )}

                    {/* Help text */}
                    <div className="clisyc-calendar-help-text">
                        {isDateRangeMode ? (
                            <p>Select your check-in and check-out dates on the calendar above.</p>
                        ) : (
                            <p>Click on an available time slot to book your appointment.</p>
                        )}
                    </div>
                </div>
            </div>
            
            {/* Event Tooltip - rendered at root level for proper positioning */}
            <EventTooltip 
                visible={tooltip.visible}
                x={tooltip.x}
                y={tooltip.y}
                content={tooltip.content}
            />
        </div>
    );
};

export default App;