/**
 * File: src/assets/src/hybrid-booking/index.js
 * Entry point for the Hybrid Booking React application.
 * Supports multiple shortcode instances on the same page.
 */
import { createRoot } from '@wordpress/element';
import HybridApp from './HybridApp';
import './style.css';

console.log('[CLISYC HYBRID DEBUG] index.js loaded - searching for container elements...');

/**
 * Initialize all hybrid booking instances on the page.
 * Each shortcode renders a <div class="clisyc-hybrid-booking-root" data-display-options="...">
 * We find all of them and render a React app for each.
 */
function initializeHybridBooking() {
    // Find all container elements (supports multiple shortcodes on same page)
    const containers = document.querySelectorAll('.clisyc-hybrid-booking-root');
    
    console.log(`[CLISYC HYBRID DEBUG] Found ${containers.length} hybrid booking container(s)`);
    
    if (containers.length === 0) {
        // Fallback: try the old single-instance ID
        const legacyContainer = document.getElementById('clisyc-hybrid-booking-root');
        if (legacyContainer) {
            console.log('[CLISYC HYBRID DEBUG] Found legacy container by ID');
            renderInstance(legacyContainer);
        } else {
            console.warn('[CLISYC HYBRID DEBUG] No hybrid booking containers found on page');
        }
        return;
    }
    
    // Render a React app for each container
    containers.forEach((container, index) => {
        console.log(`[CLISYC HYBRID DEBUG] Initializing instance ${index + 1}/${containers.length}`);
        renderInstance(container);
    });
}

/**
 * Render a single HybridApp instance into a container.
 * 
 * @param {HTMLElement} container The container element to render into.
 */
function renderInstance(container) {
    // Read display options from data attribute
    const dataAttr = container.getAttribute('data-display-options');
    let displayOptions = {};
    
    if (dataAttr) {
        try {
            displayOptions = JSON.parse(dataAttr);
            console.log('[CLISYC HYBRID DEBUG] Parsed displayOptions from data attribute:', displayOptions);
        } catch (e) {
            console.error('[CLISYC HYBRID DEBUG] Failed to parse data-display-options:', e);
            displayOptions = {};
        }
    } else {
        console.log('[CLISYC HYBRID DEBUG] No data-display-options attribute found, using defaults');
    }
    
    // Log the final options being passed to the component
    console.log('[CLISYC HYBRID DEBUG] Rendering HybridApp with displayOptions:', displayOptions);
    
    // Create React root and render
    const root = createRoot(container);
    root.render(<HybridApp displayOptions={displayOptions} />);
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeHybridBooking);
} else {
    // DOM already loaded
    initializeHybridBooking();
}