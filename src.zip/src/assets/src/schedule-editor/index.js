/**
 * File: src/assets/src/schedule-editor/index.js
 * Entry point for the new Schedule Editor React application.
 * DEBUGGING V2: Added extensive logging to trace initialization sequence.
 */
import React from 'react';
import { createRoot } from '@wordpress/element';
import App from './App';

// --- START: DEBUGGING LOGS ---
console.log('[CLISYC-SCHEDULE-EDITOR-DEBUG] 1. The index.js script file has been loaded and is executing.');

function initReactApp() {
    // Prevent multiple initializations, which can happen in the block editor.
    if (window.clisycScheduleEditorInitialized) {
        console.log('[CLISYC-SCHEDULE-EDITOR-DEBUG] 4a. App already initialized. Skipping subsequent call.');
        return;
    }
    console.log('[CLISYC-SCHEDULE-EDITOR-DEBUG] 4b. `initReactApp` function has been called.');

    const rootEl = document.getElementById('clisyc-schedule-editor-root');
    
    if (rootEl) {
        console.log('[CLISYC-SCHEDULE-EDITOR-DEBUG] 5. SUCCESS: Root element #clisyc-schedule-editor-root was found in the DOM.');
        
        // Check if the localized data object is available.
        if (typeof window.clisycScheduleEditorData === 'undefined') {
            console.error('[CLISYC-SCHEDULE-EDITOR-DEBUG] 6a. FATAL: Root element found, but `clisycScheduleEditorData` is MISSING. Check wp_localize_script in PHP.');
            rootEl.innerHTML = '<p style="color: red; text-align: center;"><strong>Error:</strong> Missing required configuration data. Cannot load editor.</p>';
            return;
        }
        console.log('[CLISYC-SCHEDULE-EDITOR-DEBUG] 6b. SUCCESS: Localized data `clisycScheduleEditorData` was found.');

        try {
            window.clisycScheduleEditorInitialized = true; // Set flag to prevent re-initialization
            const root = createRoot(rootEl);
            root.render(<App />);
            console.log('[CLISYC-SCHEDULE-EDITOR-DEBUG] 7. SUCCESS: React root.render() was called.');
        } catch (error) {
            console.error('[CLISYC-SCHEDULE-EDITOR-DEBUG] 8a. CRITICAL ERROR during React render:', error);
            rootEl.innerHTML = '<p style="color: red;">A critical error occurred while rendering the editor. Check the browser console for details.</p>';
        }
    } else {
        console.error('[CLISYC-SCHEDULE-EDITOR-DEBUG] 8b. FATAL: Root element #clisyc-schedule-editor-root was NOT found in the DOM when `initReactApp` was called.');
    }
}

// Gutenberg/Block editor can be tricky. It doesn't always fire DOMContentLoaded reliably for meta boxes.
// We need a more robust way to initialize.
if (document.readyState === 'loading') {
    // Standard browser behavior
    console.log('[CLISYC-SCHEDULE-EDITOR-DEBUG] 2. DOM is loading. Attaching listener for DOMContentLoaded.');
    document.addEventListener('DOMContentLoaded', initReactApp);
} else {
    // DOM is already ready ('interactive' or 'complete'). This is common in the block editor.
    console.log('[CLISYC-SCHEDULE-EDITOR-DEBUG] 3. DOM was already ready. Calling initReactApp() directly.');
    // A small timeout can sometimes help with race conditions in the block editor where the DOM is ready but React meta boxes haven't been added yet.
    setTimeout(initReactApp, 100);
}
// --- END: DEBUGGING LOGS ---