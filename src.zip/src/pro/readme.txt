=== Client Sync Pro ===
Contributors: hsojhsoj
Tags: add-on, client sync, pro features, resource scheduling, license
Requires at least: 5.8
Tested up to: 6.9
Stable tag: 1.1.1
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Client Sync Pro is an add-on that unlocks advanced features for the free Client Sync plugin.

== Description ==

Client Sync Pro is an add-on for the free Client Sync plugin and requires the core Client Sync plugin to be installed and active. It unlocks a suite of powerful features designed for professionals and growing businesses by activating a valid license key.

Supercharge your booking system with advanced capabilities.

= Pro Features Unlocked =

*   **Resource Scheduling:** Create intersecting schedules for dimensions like "Rooms" or "Equipment". A time slot is only bookable if the service, practitioner, AND the required resource are all available at the same time.
*   **Advanced Custom Fields:** Access premium field types, such as the **Image Map** field, which allows clients to click on an image to mark specific points (e.g., pain points on a body diagram).
*   **And more coming soon...**

== Installation ==

1.  Ensure you have the free **Client Sync** plugin installed and activated from the WordPress.org repository.
2.  In your WordPress dashboard, navigate to **Plugins > Add New > Upload Plugin**.
3.  Upload the `client-sync-pro.zip` file you received after purchase.
4.  Click **Install Now**, then **Activate Plugin**.
5.  Navigate to **Client Sync > License** in your admin menu and enter your license key to unlock the Pro features.

== Frequently Asked Questions ==

= Where do I find my license key? =
You can find your license key in the purchase confirmation email you received or by logging into your account on our website.

= How do I know the Pro features are working? =
After activating your license, navigate to areas like **Client Sync > Dimensions > System Setup**. You will see that the "(Pro)" labels are gone and features like the "Is Resource" checkbox are now enabled. Similarly, the "Image Map" field type will become available under **Booking Fields**.

= Do I need to keep the free Client Sync plugin active? =
Yes. Client Sync Pro is an add-on and is not a standalone plugin. It relies on the core functionality provided by the free version. Both plugins must be active for the Pro features to work.

== Changelog ==

= 1.0.0 =
*   Initial release.
*   Adds the license management system for feature activation.
*   Unlocks Resource Scheduling capabilities.
*   Unlocks the "Image Map" custom field type for booking forms.