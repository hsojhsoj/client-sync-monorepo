<?php
/**
 * File: src/pro/includes/services/class-webhook-service.php -> client-sync-pro/includes/services/class-webhook-service.php
 * A service class for sending secure, signed webhook payloads to external URLs.
 *
 * @package    ClientSyncPro
 * @subpackage ClientSyncPro/Services
 */
namespace ClientSyncPro\Services;

if ( ! defined( 'ABSPATH' ) ) exit;

class Webhook_Service {

    /**
     * Sends a JSON payload to a specified URL with a security signature.
     *
     * @param string $url The destination URL for the webhook.
     * @param string $event The event being triggered (e.g., 'appointment_reminder').
     * @param array $data The data payload to send.
     */
    public static function send_payload(string $url, string $event, array $data) {
        $secret = get_option('clisyc_webhook_secret');
        if (empty($secret)) {
            // Generate a strong, random secret on the first use and save it.
            $secret = wp_generate_password(64, true, true);
            update_option('clisyc_webhook_secret', $secret);
        }

        $payload = ['event' => $event, 'data' => $data, 'timestamp' => time()];
        $signature = hash_hmac('sha256', wp_json_encode($payload), $secret);
        
        $response = wp_remote_post($url, [
            'method' => 'POST',
            'headers' => [
                'Content-Type' => 'application/json; charset=utf-8',
                'X-ClientSync-Signature' => $signature,
                'User-Agent' => 'ClientSync-Webhook/' . CLISYC_VERSION,
            ],
            'body' => wp_json_encode($payload),
            'timeout' => 10,
        ]);
        
        // Log errors only if debugging is enabled.
        if ( ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) >= 400 ) && defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            $error_message = is_wp_error( $response ) ? $response->get_error_message() : wp_remote_retrieve_body( $response );
            
            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Legitimate production error logging for webhook failures.
            error_log( '[Client Sync Pro] Webhook failed for event ' . $event . ' to URL ' . $url . '. Reason: ' . $error_message );
        }
    }
}