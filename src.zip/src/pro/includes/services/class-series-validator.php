<?php
/**
 * File: src/pro/includes/services/class-series-validator.php -> client-sync-pro/includes/services/class-series-validator.php 
 * A Pro service class for validating and creating recurring appointment series.
 *
 * @package    ClientSyncPro
 * @subpackage ClientSyncPro/Services
 */

namespace ClientSyncPro\Services;

use DependentMedia\ClientSync\Core\Database_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Series_Validator {

	/**
	 * A reference to the database manager.
	 *
	 * @var \DependentMedia\ClientSync\Core\Database_Manager
	 */
	private $db_manager;

	public function __construct() {
		$this->db_manager = new Database_Manager();
	}

	/**
	 * Validates the availability of an entire series of appointments.
	 *
	 * @param string $initial_slot_utc The starting slot identifier (Y-m-d H:i:s).
	 * @param array  $dimensions       The dimensions for the booking.
	 * @param string $frequency        'weekly' or 'biweekly'.
	 * @param int    $count            The number of occurrences.
	 * @return true|\WP_Error True on success, WP_Error on failure.
	 */
	public function validate_series_availability( string $initial_slot_utc, array $dimensions, string $frequency, int $count ) {
		$occurrences = $this->calculate_occurrence_dates( $initial_slot_utc, $frequency, $count );
		if ( is_wp_error( $occurrences ) ) {
			return $occurrences;
		}

		$primary_dim_slug = $this->get_primary_dimension_slug();
		if ( ! $primary_dim_slug || ! isset( $dimensions[ $primary_dim_slug ] ) ) {
			return new \WP_Error( 'invalid_data', __( 'Primary dimension is missing from the request.', 'client-sync-pro' ) );
		}
		$primary_dim_id = $dimensions[ $primary_dim_slug ];

		foreach ( $occurrences as $occurrence_utc ) {
			$slot_id = $this->db_manager->find_slot_id_by_start_time_and_dimensions( $occurrence_utc->format( 'Y-m-d H:i:s' ), $dimensions );

			if ( ! $slot_id ) {
				$site_timezone = wp_timezone();
				$occurrence_site = ( clone $occurrence_utc )->setTimezone( $site_timezone );
				$formatted_date  = $occurrence_site->format( get_option( 'date_format' ) . ' @ ' . get_option( 'time_format' ) );

				/* translators: %s: The formatted date and time of the unavailable slot. */
				return new \WP_Error( 'slot_unavailable', sprintf( __( 'The slot on %1$s is not available.', 'client-sync-pro' ), $formatted_date ) );
			}

			// Check capacity for this specific slot.
			if ( $this->is_slot_at_capacity( $slot_id, $primary_dim_id ) ) {
				$site_timezone = wp_timezone();
				$occurrence_site = ( clone $occurrence_utc )->setTimezone( $site_timezone );
				$formatted_date  = $occurrence_site->format( get_option( 'date_format' ) . ' @ ' . get_option( 'time_format' ) );

				/* translators: %s: The formatted date and time of the full slot. */
				return new \WP_Error( 'slot_full', sprintf( __( 'The slot on %1$s is full.', 'client-sync-pro' ), $formatted_date ) );
			}
		}

		return true;
	}

	/**
	 * Creates all appointments for a validated series.
	 *
	 * @param string $initial_slot_utc The starting slot identifier.
	 * @param array  $dimensions       The dimensions for the booking.
	 * @param string $frequency        'weekly' or 'biweekly'.
	 * @param int    $count            The number of occurrences.
	 * @param int    $user_id          The ID of the user booking the series.
	 * @param array  $custom_fields    Sanitized custom field data.
	 * @return array|\WP_Error An array of new appointment IDs, or a WP_Error.
	 */
	public function create_appointment_series( string $initial_slot_utc, array $dimensions, string $frequency, int $count, int $user_id, array $custom_fields ): array|\WP_Error {
		$occurrences = $this->calculate_occurrence_dates( $initial_slot_utc, $frequency, $count );
		if ( is_wp_error( $occurrences ) ) {
			return $occurrences;
		}

		$primary_dim_slug = $this->get_primary_dimension_slug();
		$primary_dim_id   = $dimensions[ $primary_dim_slug ] ?? 0;
		$primary_item_post = get_post( $primary_dim_id );

		if ( ! $primary_item_post ) {
			return new \WP_Error( 'invalid_primary_item', 'The primary booking item does not exist.' );
		}

		$series_id      = time() . '-' . wp_rand( 100, 999 );
		$new_post_ids   = [];
		$duration       = (int) get_post_meta( $primary_dim_id, '_clisyc_duration_minutes', true ) ?: 30;

		foreach ( $occurrences as $index => $occurrence_utc ) {
			$slot_utc_str = $occurrence_utc->format( 'Y-m-d H:i:s' );
			$appointment_title = sprintf( '%s (Booking %d of %d)', $primary_item_post->post_title, $index + 1, $count );

			$appointment_data = [
				'post_title'  => $appointment_title,
				'post_status' => 'publish',
				'post_author' => $user_id,
				'post_type'   => 'clisyc_appointment',
			];

			$appointment_id = wp_insert_post( $appointment_data, true );

			if ( is_wp_error( $appointment_id ) ) {
				// If one fails, we should ideally roll back previous ones, but for now we'll just error out.
				return $appointment_id;
			}

			update_post_meta( $appointment_id, '_clisyc_series_id', $series_id );
			update_post_meta( $appointment_id, '_clisyc_time_slot', $slot_utc_str );
			update_post_meta( $appointment_id, '_clisyc_appointment_date', $occurrence_utc->format( 'Y-m-d' ) );
			update_post_meta( $appointment_id, '_clisyc_appointment_duration', $duration );
			update_post_meta( $appointment_id, '_clisyc_slot_dimensions', $dimensions );

			if ( ! empty( $custom_fields ) ) {
				foreach ( $custom_fields as $key => $value ) {
					update_post_meta( $appointment_id, $key, $value );
				}
			}

			$new_post_ids[] = $appointment_id;
		}

		// Future: Trigger notifications for the series here.
		return $new_post_ids;
	}

	/**
	 * Calculates an array of DateTime objects for each occurrence in a series.
	 *
	 * @param string $initial_slot_utc The starting slot identifier (Y-m-d H:i:s).
	 * @param string $frequency        'weekly' or 'biweekly'.
	 * @param int    $count            The number of occurrences.
	 * @return array|\WP_Error An array of DateTime objects in UTC, or a WP_Error.
	 */
	private function calculate_occurrence_dates( string $initial_slot_utc, string $frequency, int $count ) {
		if ( $count < 2 || $count > 52 ) {
			return new \WP_Error( 'invalid_count', __( 'Recurring count must be between 2 and 52.', 'client-sync-pro' ) );
		}

		$utc_timezone = new \DateTimeZone( 'UTC' );
		try {
			$start_date = new \DateTime( $initial_slot_utc, $utc_timezone );
		} catch ( \Exception $e ) {
			return new \WP_Error( 'invalid_date', __( 'Invalid start date provided for series.', 'client-sync-pro' ) );
		}

		$occurrences   = [ $start_date ];
		$interval_string = ( 'biweekly' === $frequency ) ? '+2 weeks' : '+1 week';

		for ( $i = 1; $i < $count; $i++ ) {
			$next_date     = ( clone $occurrences[ $i - 1 ] )->modify( $interval_string );
			$occurrences[] = $next_date;
		}

		return $occurrences;
	}

	/**
	 * Checks if a specific slot ID is at full capacity.
	 *
	 * @param int $slot_id        The ID of the slot to check.
	 * @param int $primary_dim_id The ID of the primary dimension item (e.g., service).
	 * @return bool True if full, false otherwise.
	 */
	private function is_slot_at_capacity( int $slot_id, int $primary_dim_id ): bool {
		global $wpdb;
		$capacity = (int) get_post_meta( $primary_dim_id, '_clisyc_capacity', true ) ?: 1;

		$bookings_table = $this->db_manager->get_bookings_table_name();

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Table name is safely constructed from internal Database_Manager. Direct query and no-caching required for real-time capacity validation.
		$booked_count = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(booking_id) FROM {$bookings_table} WHERE slot_id = %d", $slot_id ) );

		return ( (int) $booked_count >= $capacity );
	}

	/**
	 * Gets the slug of the currently configured primary dimension.
	 *
	 * @return string|null The slug or null if not found.
	 */
	private function get_primary_dimension_slug(): ?string {
		$registry = get_option( 'clisyc_dimension_registry', [] );
		if ( ! empty( $registry['dimensions'] ) ) {
			foreach ( $registry['dimensions'] as $slug => $settings ) {
				if ( ! empty( $settings['primary'] ) ) {
					return $slug;
				}
			}
		}
		return null;
	}
}