<?php
/**
 * File: src/pro/includes/modules/packages/class-package-manager.php -> /client-sync-pro/includes/modules/packages/class-package-manager.php
 * Handles granting credits upon WooCommerce order completion. 
 *
 * @package    ClientSyncPro
 * @subpackage ClientSyncPro/Modules/Packages
 */

namespace ClientSyncPro\Modules\Packages;

if ( ! defined( 'ABSPATH' ) ) exit;

class Package_Manager {

    public function register_hooks() {
        add_action( 'woocommerce_order_status_completed', [ $this, 'grant_credits_on_purchase' ], 10, 1 );
    }

    public function grant_credits_on_purchase( int $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order ) return;

        $user_id = $order->get_user_id();
        if ( ! $user_id ) return;

        foreach ( $order->get_items() as $item ) {
            $product_id = $item->get_product_id();

            // Find if this product is linked to a package
            $package_query = new \WP_Query([
                'post_type' => 'clisyc_package',
                'posts_per_page' => 1,
                'post_status' => 'publish',
                'fields' => 'ids',
                'meta_query' => [
                    ['key' => '_clisyc_linked_product_id', 'value' => $product_id]
                ]
            ]);

            if ( $package_query->have_posts() ) {
                $package_id = $package_query->posts[0];
                $rules = get_post_meta( $package_id, '_clisyc_package_rules', true );

                if ( is_array($rules) && !empty($rules['service_id']) && !empty($rules['credits']) ) {
                    $service_id = $rules['service_id'];
                    $credits_to_add = $rules['credits'] * $item->get_quantity(); // Account for quantity
                    $expires_days = $rules['expires_days'];
                    
                    $this->add_credits_to_user( $user_id, $service_id, $credits_to_add, $expires_days );
                }
            }
        }
    }

    private function add_credits_to_user( int $user_id, int $service_id, int $credits_to_add, int $expires_days ) {
        $user_credits = get_user_meta( $user_id, '_clisyc_credits', true );
        $user_credits = is_array($user_credits) ? $user_credits : [];
        
        $service_key = 'service_' . $service_id;
        $existing_credits = $user_credits[$service_key]['credits_remaining'] ?? 0;
        $new_total = $existing_credits + $credits_to_add;

        $user_credits[$service_key] = [
            'credits_remaining' => $new_total,
            'expires_at' => ($expires_days > 0) ? (time() + ($expires_days * DAY_IN_SECONDS)) : 0,
        ];

        update_user_meta( $user_id, '_clisyc_credits', $user_credits );
    }
}