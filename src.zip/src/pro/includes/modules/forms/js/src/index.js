/**
 * File: src/pro/includes/modules/forms/js/src/index.js -> src/pro/includes/modules/forms/js/dist/index.js
 * Entry point for the Client Sync Pro Form Builder React application.
 *
 * This version includes debugging logs to diagnose initialization failures.
 *
 * @package    ClientSyncPro
 * @subpackage ClientSyncPro/Modules/Forms/JS
 */
import React from 'react';
import { createRoot } from '@wordpress/element';
import App from './App';
import './style.css';

// --- START: DEBUGGING LOGS ---
console.log('[CLISYC-FORM-BUILDER-DEBUG] index.js script has been executed.');

document.addEventListener('DOMContentLoaded', () => {
    console.log('[CLISYC-FORM-BUILDER-DEBUG] DOMContentLoaded event fired.');
    initReactApp();
});

if (document.readyState === 'interactive' || document.readyState === 'complete') {
    console.log('[CLISYC-FORM-BUILDER-DEBUG] DOM already ready, initializing immediately.');
    initReactApp();
}

function initReactApp() {
    // Prevent multiple initializations
    if (window.clisycFormBuilderInitialized) {
        console.log('[CLISYC-FORM-BUILDER-DEBUG] App already initialized. Skipping.');
        return;
    }
    window.clisycFormBuilderInitialized = true;

    const rootEl = document.getElementById('clisyc-form-builder-app-root');
    
    if (rootEl) {
        console.log('[CLISYC-FORM-BUILDER-DEBUG] Root element #clisyc-form-builder-app-root found. Attempting to render React app.');
        try {
            const root = createRoot(rootEl);
            root.render(<App />);
            console.log('[CLISYC-FORM-BUILDER-DEBUG] React root.render() called successfully.');
        } catch (error) {
            console.error('[CLISYC-FORM-BUILDER-DEBUG] CRITICAL ERROR during React render:', error);
            rootEl.innerHTML = '<p style="color: red;">A critical error occurred while loading the form builder. Check the browser console for details.</p>';
        }
    } else {
        console.error('[CLISYC-FORM-BUILDER-DEBUG] FATAL: Root element #clisyc-form-builder-app-root was NOT found in the DOM.');
    }
}
// --- END: DEBUGGING LOGS ---