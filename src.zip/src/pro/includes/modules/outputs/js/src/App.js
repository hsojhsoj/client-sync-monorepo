/**
 * File: src/pro/includes/modules/outputs/js/src/App.js -> (compiled)
 * The main React component for the Output Template Builder UI.
 *
 * Adapted from Forms Builder; supports sections like text/tables with placeholders.
 * Includes debugging logs for data loading.
 *
 * @package    ClientSyncPro
 * @subpackage ClientSyncPro/Modules/Outputs/JS
 */
import React, { useState, useEffect } from 'react';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';

const FieldPalette = ({ onAddField }) => {
    const { fieldTypes } = window.clisycOutputBuilderData;
    return (
        <div className="clisyc-field-palette">
            <h4>Add a Field</h4>
            {Object.entries(fieldTypes).map(([type, { label, icon }]) => (
                <button
                    key={type}
                    type="button"
                    className="button clisyc-field-palette-btn"
                    onClick={() => onAddField(type)}
                >
                    <span className={`dashicons ${icon}`}></span>
                    {label}
                </button>
            ))}
        </div>
    );
};

const OutputSection = ({ section, index, onUpdate, onDelete }) => {
    // Similar to FormField, but for sections (e.g., type: 'text', content: '{placeholder}')
    const handleChange = (prop, value) => {
        onUpdate(section.id, { ...section, [prop]: value });
    };

    return (
        <Draggable draggableId={section.id} index={index}>
            {(provided, snapshot) => (
                <div ref={provided.innerRef} {...provided.draggableProps} className={`clisyc-output-section ${snapshot.isDragging ? 'is-dragging' : ''}`}>
                    <div className="clisyc-section-header" {...provided.dragHandleProps}>
                        <span className="clisyc-section-drag-icon dashicons dashicons-move"></span>
                        <span className="clisyc-section-type">{section.type}</span>
                        <button type="button" className="clisyc-section-delete" onClick={() => onDelete(section.id)}>
                            <span className="dashicons dashicons-trash"></span>
                        </button>
                    </div>
                    {section.type === 'text' && (
                        <input type="text" value={section.content || ''} onChange={(e) => handleChange('content', e.target.value)} placeholder="Enter text with {placeholders}" />
                    )}
                    {section.type === 'table' && (
                        <textarea value={section.fields?.join('\n') || ''} onChange={(e) => handleChange('fields', e.target.value.split('\n'))} placeholder="One field per line" />
                    )}
                </div>
            )}
        </Draggable>
    );
};

const App = () => {
    console.log('[CLISYC-OUTPUT-BUILDER-DEBUG] App component is rendering.');

    const [sections, setSections] = useState(() => {
        console.log('[CLISYC-OUTPUT-BUILDER-DEBUG] Initializing from localized data...');
        if (window.clisycOutputBuilderData && window.clisycOutputBuilderData.formJson) {
            try {
                const initialSections = JSON.parse(window.clisycOutputBuilderData.formJson);
                console.log('[CLISYC-OUTPUT-BUILDER-DEBUG] Parsed JSON with', initialSections.length, 'sections.');
                return initialSections || [];
            } catch (e) {
                console.error('[CLISYC-OUTPUT-BUILDER-DEBUG] Parse error:', e);
            }
        }
        return [];
    });

    const outputTextarea = document.getElementById('clisyc-output-json-output');

    useEffect(() => {
        if (outputTextarea) {
            const json = { sections };
            outputTextarea.value = JSON.stringify(json, null, 2);
        }
    }, [sections]);

    const handleAddSection = (type) => {
        const newSection = {
            id: `section_${Date.now()}`,
            type,
            content: type === 'text' ? '{client_name} Welcome!' : '',
            fields: type === 'table' ? ['Field 1', 'Field 2'] : [],
        };
        setSections([...sections, newSection]);
    };

    const handleUpdateSection = (id, updatedSection) => {
        setSections(sections.map(s => (s.id === id ? updatedSection : s)));
    };

    const handleDeleteSection = (id) => {
        if (window.confirm('Delete this section?')) {
            setSections(sections.filter(s => s.id !== id));
        }
    };

    const onDragEnd = (result) => {
        if (!result.destination) return;
        const items = Array.from(sections);
        const [reorderedItem] = items.splice(result.source.index, 1);
        items.splice(result.destination.index, 0, reorderedItem);
        setSections(items);
    };

    return (
        <div className="clisyc-output-builder">
            <FieldPalette onAddField={handleAddSection} /> {/* Palette now adds sections/types */}
            <DragDropContext onDragEnd={onDragEnd}>
                <Droppable droppableId="output-canvas">
                    {(provided) => (
                        <div {...provided.droppableProps} ref={provided.innerRef} className="clisyc-output-canvas">
                            {sections.length > 0 ? (
                                sections.map((section, index) => (
                                    <OutputSection
                                        key={section.id}
                                        section={section}
                                        index={index}
                                        onUpdate={handleUpdateSection}
                                        onDelete={handleDeleteSection}
                                    />
                                ))
                            ) : (
                                <p style={{ textAlign: 'center', marginTop: '50px', color: '#787c82' }}>
                                    Drag section types from the left to build your output template.
                                </p>
                            )}
                            {provided.placeholder}
                        </div>
                    )}
                </Droppable>
            </DragDropContext>
        </div>
    );
};

export default App;