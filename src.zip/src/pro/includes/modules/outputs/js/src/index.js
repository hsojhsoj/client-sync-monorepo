/**
 * File: src/pro/includes/modules/outputs/js/src/index.js -> src/pro/includes/modules/outputs/js/dist/index.js
 * Entry point for the Client Sync Pro Output Template Builder React application.
 *
 * This version includes debugging logs to diagnose initialization failures.
 *
 * @package    ClientSyncPro
 * @subpackage ClientSyncPro/Modules/Outputs/JS
 */
import React from 'react';
import { createRoot } from '@wordpress/element';
import App from './App';
import './style.css';

// --- START: DEBUGGING LOGS ---
console.log('[CLISYC-OUTPUT-BUILDER-DEBUG] index.js script has been executed.');

document.addEventListener('DOMContentLoaded', () => {
    console.log('[CLISYC-OUTPUT-BUILDER-DEBUG] DOMContentLoaded event fired.');
    initReactApp();
});

if (document.readyState === 'interactive' || document.readyState === 'complete') {
    console.log('[CLISYC-OUTPUT-BUILDER-DEBUG] DOM already ready, initializing immediately.');
    initReactApp();
}

function initReactApp() {
    // Prevent multiple initializations
    if (window.clisycOutputBuilderInitialized) {
        console.log('[CLISYC-OUTPUT-BUILDER-DEBUG] App already initialized. Skipping.');
        return;
    }
    window.clisycOutputBuilderInitialized = true;

    const rootEl = document.getElementById('clisyc-output-builder-root');
    
    if (rootEl) {
        console.log('[CLISYC-OUTPUT-BUILDER-DEBUG] Root element #clisyc-output-builder-root found. Attempting to render React app.');
        try {
            const root = createRoot(rootEl);
            root.render(<App />);
            console.log('[CLISYC-OUTPUT-BUILDER-DEBUG] React root.render() called successfully.');
        } catch (error) {
            console.error('[CLISYC-OUTPUT-BUILDER-DEBUG] CRITICAL ERROR during React render:', error);
            rootEl.innerHTML = '<p style="color: red;">A critical error occurred while loading the output builder. Check the browser console for details.</p>';
        }
    } else {
        console.error('[CLISYC-OUTPUT-BUILDER-DEBUG] FATAL: Root element #clisyc-output-builder-root was NOT found in the DOM.');
    }
}
// --- END: DEBUGGING LOGS ---