<?php
/**
 * File: src/pro/includes/modules/outputs/class-outputs-module.php
 * Outputs Module: Manages dynamic output templates for post-booking communications.
 *
 * Registers the Output Templates CPT, admin UI, metaboxes, and integrates with notifications.
 * Pro-only; gated by license.
 *
 * @package    ClientSyncPro
 * @subpackage ClientSyncPro/Modules/Outputs
 */

namespace ClientSyncPro\Modules\Outputs;

use ClientSyncPro\Module_Interface;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Outputs_Module implements Module_Interface {

	/**
	 * Initializes the module by loading its components and registering their hooks.
	 * This method is called by the Module_Manager.
	 * {@inheritdoc}
	 */
	public function initialize() {
		require_once __DIR__ . '/class-output-renderer.php';
		require_once __DIR__ . '/class-output-template-channel.php';

		add_action( 'init', [ $this, 'register_cpt' ] );
		
		// HOOK INTO FREE VERSION MENU MANAGER
		add_action( 'clisyc_register_extra_submenu_items', [ $this, 'add_menu_items' ] );

		add_action( 'add_meta_boxes_clisyc_output_tmpl', [ $this, 'add_metaboxes' ] );
		add_action( 'save_post_clisyc_output_tmpl', [ $this, 'save_template' ] );
		add_filter( 'clisyc_notification_channels', [ $this, 'register_output_channel' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
	}

	/**
	 * Callback to register the Output Templates submenu item.
	 * This runs on the 'clisyc_register_extra_submenu_items' action.
	 *
	 * @param string $main_page_slug The slug of the parent menu page.
	 */
	public function add_menu_items( $main_page_slug ) {
		add_submenu_page(
			$main_page_slug,
			__( 'Output Templates', 'client-sync-pro' ),
			__( 'Output Templates', 'client-sync-pro' ),
			'manage_options',
			'edit.php?post_type=clisyc_output_tmpl'
		);
	}

	/**
	 * Register CPT for output templates.
	 */
	public function register_cpt() {
		$labels = [
			'name'          => __( 'Output Templates', 'client-sync-pro' ),
			'singular_name' => __( 'Output Template', 'client-sync-pro' ),
			'add_new'       => __( 'Add New Template', 'client-sync-pro' ),
			'add_new_item'  => __( 'Add New Output Template', 'client-sync-pro' ),
			'edit_item'     => __( 'Edit Output Template', 'client-sync-pro' ),
			'new_item'      => __( 'New Output Template', 'client-sync-pro' ),
			'view_item'     => __( 'View Output Template', 'client-sync-pro' ),
			'menu_name'     => __( 'Output Templates', 'client-sync-pro' ),
		];

		$args = [
			'labels'          => $labels,
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => false, // We manually add the submenu item via the hook above
			'rewrite'         => [ 'slug' => 'clisyc-output-tmpl' ],
			'capability_type' => 'post',
			'has_archive'     => false,
			'hierarchical'    => false,
			'supports'        => [ 'title' ],
			'menu_icon'       => 'dashicons-media-document',
		];

		register_post_type( 'clisyc_output_tmpl', $args );
	}

	/**
	 * Add JSON metabox for template layout.
	 */
	public function add_metaboxes() {
		if ( ! function_exists( 'clisyc_pro_is_license_active' ) || ! \clisyc_pro_is_license_active() ) {
			add_meta_box( 'clisyc-output-builder-locked', __( 'Template Builder', 'client-sync-pro' ), [ $this, 'render_locked_metabox' ], 'clisyc_output_tmpl', 'normal', 'high' );
			return;
		}

		add_meta_box(
			'clisyc_output_template_json',
			__( 'Template Builder', 'client-sync-pro' ),
			[ $this, 'render_metabox' ],
			'clisyc_output_tmpl',
			'normal',
			'high'
		);

		add_meta_box(
			'clisyc_output_triggers',
			__( 'Triggers & Channels', 'client-sync-pro' ),
			[ $this, 'render_triggers_metabox' ],
			'clisyc_output_tmpl',
			'side'
		);
	}

	/**
	 * Render main builder metabox (placeholder for React).
	 */
	public function render_metabox( $post ) {
		wp_nonce_field( 'clisyc_save_output_template', 'clisyc_output_nonce' );
		$json = get_post_meta( $post->ID, 'clisyc_template_json', true );
		?>
		<div id="clisyc-output-builder-root"></div> <!-- React mounts here -->
		<textarea id="clisyc-output-json-output" style="display:none;" name="clisyc_template_json"><?php echo esc_textarea( $json ); ?></textarea>
		<p><?php esc_html_e( 'Drag fields to build your layout. Preview updates live.', 'client-sync-pro' ); ?></p>
		<?php
	}

	/**
	 * Render triggers/channels metabox.
	 */
	public function render_triggers_metabox( $post ) {
		$triggers = get_post_meta( $post->ID, 'clisyc_triggers', true ) ?: [ 'appointment_complete' ];
		$channels = get_post_meta( $post->ID, 'clisyc_channels', true ) ?: [ 'email', 'pdf' ];
		$all_notification_events = ( new \DependentMedia\ClientSync\Core\Notifications() )->get_event_types();
		?>
		<p><label><strong><?php esc_html_e( 'Trigger Events:', 'client-sync-pro' ); ?></strong></label></p>
		<div style="max-height: 150px; overflow-y: auto; border: 1px solid #ddd; padding: 5px; background: #fff;">
			<?php foreach ( $all_notification_events as $event_key => $event_data ) : ?>
				<label style="display: block; margin-bottom: 5px;">
					<input type="checkbox" name="clisyc_triggers[]" value="<?php echo esc_attr( $event_key ); ?>" <?php checked( in_array( $event_key, $triggers, true ) ); ?>> 
					<?php echo esc_html( $event_data['label'] ); ?>
				</label>
			<?php endforeach; ?>
		</div>
		<p><label><strong><?php esc_html_e( 'Delivery Channels:', 'client-sync-pro' ); ?></strong></label></p>
		<ul>
			<li><label><input type="checkbox" name="clisyc_channels[]" value="email" <?php checked( in_array( 'email', $channels, true ) ); ?>> <?php esc_html_e( 'Send as Email Body', 'client-sync-pro' ); ?></label></li>
			<li><label><input type="checkbox" name="clisyc_channels[]" value="pdf" <?php checked( in_array( 'pdf', $channels, true ) ); ?>> <?php esc_html_e( 'Attach as PDF to Email', 'client-sync-pro' ); ?></label></li>
			<li><label><input type="checkbox" name="clisyc_channels[]" value="sms" <?php checked( in_array( 'sms', $channels, true ) ); ?>> <?php esc_html_e( 'Send as SMS (Summary)', 'client-sync-pro' ); ?></label></li>
		</ul>
		<?php
	}

	/**
	 * Save template data.
	 */
	public function save_template( $post_id ) {
		if ( ! isset( $_POST['clisyc_output_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['clisyc_output_nonce'] ), 'clisyc_save_output_template' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Save JSON
		if ( isset( $_POST['clisyc_template_json'] ) ) {
			update_post_meta( $post_id, 'clisyc_template_json', sanitize_textarea_field( wp_unslash( $_POST['clisyc_template_json'] ) ) );
		}

		// Save triggers/channels
		$triggers = isset( $_POST['clisyc_triggers'] ) && is_array( $_POST['clisyc_triggers'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['clisyc_triggers'] ) ) : [];
		update_post_meta( $post_id, 'clisyc_triggers', $triggers );

		$channels = isset( $_POST['clisyc_channels'] ) && is_array( $_POST['clisyc_channels'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['clisyc_channels'] ) ) : [];
		update_post_meta( $post_id, 'clisyc_channels', $channels );
	}

	/**
	 * Register as notification channel.
	 */
	public function register_output_channel( $channels ) {
		$channels['output_template'] = new Output_Template_Channel();
		return $channels;
	}

	/**
	 * Enqueue React builder assets.
	 */
	public function enqueue_assets( $hook_suffix ) {
		if ( ! in_array( $hook_suffix, [ 'post.php', 'post-new.php' ], true ) ) {
			return;
		}

		$screen = get_current_screen();
		if ( ! is_object( $screen ) || 'clisyc_output_tmpl' !== $screen->post_type ) {
			return;
		}
		
		$asset_file_path = clisyc_PLUGIN_DIR . 'assets/dist/pro-outputs/index.asset.php';
		if ( ! file_exists( $asset_file_path ) ) {
			return;
		}

		$asset_file = include $asset_file_path;
		$dependencies = $asset_file['dependencies'] ?? [];
		if ( ! in_array( 'wp-element', $dependencies, true ) ) {
			$dependencies[] = 'wp-element';
		}

		wp_enqueue_script(
			'clisyc-output-builder',
			clisyc_PLUGIN_URL . 'assets/dist/pro-outputs/index.js',
			$dependencies,
			$asset_file['version'],
			true
		);

		wp_localize_script( 'clisyc-output-builder', 'clisycOutputBuilderData', [
			'formJson'    => get_post_meta( get_the_ID(), 'clisyc_template_json', true ) ?: '[]',
			'fieldTypes'  => $this->get_available_fields(),
		] );

		wp_enqueue_style(
			'clisyc-output-builder-style',
			clisyc_PLUGIN_URL . 'assets/dist/style-pro-outputs/style-index.css',
			['wp-components'],
			$asset_file['version'] 
		);
	}

	/**
	 * Get available fields for the builder.
	 */
	private function get_available_fields() {
		$fields = [
			'client_name'      => [ 'label' => __( 'Client Name', 'client-sync-pro' ), 'icon' => 'dashicons-admin-users' ],
			'appointment_date' => [ 'label' => __( 'Appointment Date', 'client-sync-pro' ), 'icon' => 'dashicons-calendar' ],
			'service_type'     => [ 'label' => __( 'Service Type (Dimension)', 'client-sync-pro' ), 'icon' => 'dashicons-tag' ],
		];

		$custom_fields = get_option( 'clisyc_appointment_custom_fields', [] );
		foreach ( $custom_fields as $key => $field ) {
			$fields[ $key ] = [ 'label' => $field['label'], 'icon' => 'dashicons-text' ];
		}

		return $fields;
	}

	/**
	 * Render the locked meta box if license is inactive.
	 */
	public function render_locked_metabox() {
		$license_url = admin_url( 'admin.php?page=clisyc-pro-license' );
		/* translators: %s: URL to the license activation page. */
		$message = sprintf( __( 'The Output Template Builder is a Pro feature. Please <a href="%s">activate your license</a> to use this functionality.', 'client-sync-pro' ), esc_url( $license_url ) );
		echo '<p>' . wp_kses_post( $message ) . '</p>';
	}
}